import json
from pathlib import Path


class AuditLogger:
    """
    Records agent operations in an append-only JSONL file.
    """

    def __init__(self):
        project_root = Path(__file__).resolve().parents[2]

        self.log_file = (
            project_root / "data" / "agent_audit.jsonl"
        )

    def log_event(self, event):

        try:
            with open(
                self.log_file,
                "a",
                encoding="utf-8"
            ) as file:

                file.write(
                    json.dumps(
                        event,
                        ensure_ascii=False
                    ) + "\n"
                )

            return {
                "status": "success",
                "message": "Audit event recorded."
            }

        except OSError as error:

            return {
                "status": "error",
                "message": str(error)
            }