"""ط§ط®طھط¨ط§ط±ط§طھ ط´ط§ظ…ظ„ط© ظ„ظ…ط­ط±ظƒ ط§ظ„ظˆظƒظٹظ„: ط§ظ„ط¹ظ‚ظˆط¯طŒ ط§ظ„طھط´ط؛ظٹظ„طŒ ط§ظ„طµظ„ط§ط­ظٹط§طھطŒ ط§ظ„ط°ط§ظƒط±ط©."""

import pytest

from zeroone_agent.contracts.models import (
    AgentRequest,
    ExecutionContext,
    ResponseStatus,
    ToolInvocation,
)
from zeroone_agent.audit.logger import AuditLogger
from zeroone_agent.security.policy import PermissionEngine
from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.tools.registry import ToolRegistry
from zeroone_agent.tools.executor import ToolExecutor
from zeroone_agent.domains.clinic.tools import register_clinic_tools
from zeroone_agent.domains.clinic.policy import capabilities_for_role
from zeroone_agent.runtime.agent import AgentRuntime
from zeroone_agent.memory.store import MemoryStore


def make_context(capabilities=("clinic.appointments.read",)):
    return ExecutionContext(
        request_id="r",
        execution_id="e",
        trace_id="t",
        tenant_id="tenant1",
        agent_id="agent1",
        agent_version="1.0",
        domain="clinic",
        principal_id="user1",
        capabilities=capabilities,
    )


def make_runtime():
    registry = ToolRegistry()
    register_clinic_tools(registry)
    audit = AuditLogger()
    approvals = ApprovalService()
    executor = ToolExecutor(registry, PermissionEngine(), audit)
    runtime = AgentRuntime(registry, executor, audit, approvals)
    return runtime, audit, approvals


# ============================================================
# ط§ظ„ط¹ظ‚ظˆط¯
# ============================================================

def test_request_context_is_immutable_copy():
    original = {"x": {"y": 1}}
    request = AgentRequest("r", "a", "hi", context=original)
    original["x"]["y"] = 2
    assert request.context["x"]["y"] == 1


def test_execution_context_requires_timezone_aware_created_at():
    from datetime import datetime
    with pytest.raises(ValueError):
        ExecutionContext(
            request_id="r", execution_id="e", trace_id="t",
            tenant_id="t1", agent_id="a1", agent_version="1",
            domain="clinic", principal_id="u1",
            created_at=datetime.now(),  # naive â€” ظٹط¬ط¨ ط£ظ† ظٹظڈط±ظپط¶
        )


# ============================================================
# ط§ظ„طھط´ط؛ظٹظ„ ط§ظ„ظƒط§ظ…ظ„ (end-to-end)
# ============================================================

def test_run_clinic_view_appointments():
    runtime, _, _ = make_runtime()
    request = AgentRequest("r", "agent1", "show appointments", context={"date": "2026-11-08"})
    response = runtime.handle(request, make_context())

    assert response.status == ResponseStatus.COMPLETED
    assert response.data["total"] == 3


def test_missing_capability_is_denied_without_approval():
    runtime, _, _ = make_runtime()
    request = AgentRequest(
        "r", "agent1", "اعرض المواعيد",
        context={"date": "2026-11-08"},
    )
    response = runtime.handle(request, make_context(capabilities=()))

    assert response.status == ResponseStatus.DENIED
    assert response.approval_id is None
    assert response.data["error"]["code"] == "PERMISSION_DENIED"

def test_unregistered_tool_returns_controlled_failure():
    from zeroone_agent.runtime.analyzer import Analysis

    class UnknownToolAnalyzer:
        def analyze(self, message, context):
            return Analysis(
                intent="action",
                tool_id="clinic.unknown_tool",
                arguments={},
            )

    registry = ToolRegistry()
    audit = AuditLogger()
    approvals = ApprovalService()
    executor = ToolExecutor(registry, PermissionEngine(), audit)

    runtime = AgentRuntime(
        registry,
        executor,
        audit,
        approvals,
        analyzer=UnknownToolAnalyzer(),
    )

    request = AgentRequest("r", "agent1", "ظ†ظپط° ط§ظ„ط¥ط¬ط±ط§ط،")
    response = runtime.handle(request, make_context())

    assert response.status == ResponseStatus.FAILED
    assert response.error["code"] == "UNKNOWN_TOOL"
    assert approvals.list_pending("tenant1") == []

def test_unknown_request_does_not_crash():
    runtime, _, _ = make_runtime()
    request = AgentRequest("r", "agent1", "unrecognized request", context={})
    response = runtime.handle(request, make_context())

    assert response.status == ResponseStatus.COMPLETED
    assert response.message


# ============================================================
# ط§ظ„طµظ„ط§ط­ظٹط§طھ ظˆط§ظ„ط§ط¹طھظ…ط§ط¯ط§طھ
# ============================================================

def test_approval_is_tenant_scoped_and_single_use():
    _, _, approvals = make_runtime()
    record = approvals.request(make_context(()), "action", {})

    with pytest.raises(KeyError):
        approvals.decide(record.approval_id, "other-tenant", "boss", True)

    approvals.decide(record.approval_id, "tenant1", "boss", True)

    with pytest.raises(ValueError):
        approvals.decide(record.approval_id, "tenant1", "boss", True)


def test_clinic_role_capabilities_mapping():
    assert "clinic.appointments.read" in capabilities_for_role("receptionist")
    assert "clinic.reports.revenue" in capabilities_for_role("clinic_manager")
    assert capabilities_for_role("unknown_role") == ()


# ============================================================
# ظ…ظ†ظپط° ط§ظ„ط£ط¯ظˆط§طھ ظ…ط¨ط§ط´ط±ط©
# ============================================================

def test_invalid_arguments_are_blocked_before_execution():
    registry = ToolRegistry()
    register_clinic_tools(registry)
    executor = ToolExecutor(registry, PermissionEngine(), AuditLogger())

    invocation = ToolInvocation(
        "i", "clinic.view_appointments", make_context(), {"bad_field": 1}
    )
    result = executor.execute(invocation)

    assert not result.success
    assert result.error["code"] == "INVALID_ARGUMENTS"


def test_duplicate_tool_registration_raises():
    registry = ToolRegistry()
    register_clinic_tools(registry)
    with pytest.raises(ValueError):
        register_clinic_tools(registry)


# ============================================================
# ط§ظ„ط°ط§ظƒط±ط© ط·ظˆظٹظ„ط© ط§ظ„ظ…ط¯ظ‰ (ظ…ظˆط§ظپظ‚ط© ط¨ط´ط±ظٹط©)
# ============================================================

def test_memory_is_isolated_per_tenant_and_agent():
    store = MemoryStore()
    store.add("t", "a", "ط§ظ„ط¹ظٹط§ط¯ط© طھط¹ظ…ظ„ ظ…ظ† 8 ط¥ظ„ظ‰ 4", source="test")
    store.add("t", "b", "ظ…ظ†طھط¬ ط¬ط¯ظٹط¯ ظ…طھط§ط­", source="test")

    # ظ„ظ… طھظڈط¹طھظ…ط¯ ط¨ط¹ط¯طŒ ظپظ„ط§ طھط¸ظ‡ط± ظپظٹ ط§ظ„ط¨ط­ط« ط§ظ„ط§ظپطھط±ط§ط¶ظٹ (approved_only=True)
    assert store.search("t", "a") == []


def test_memory_requires_approval_before_use():
    store = MemoryStore()
    item = store.add("t", "a", "ظ‚ط§ط¹ط¯ط© ط¹ظ…ظ„ طھط¬ط±ظٹط¨ظٹط©", source="test")

    assert item["status"] == "pending"
    assert store.search("t", "a", query="طھط¬ط±ظٹط¨ظٹط©") == []

    store.review(item["memory_id"], "approved", reviewed_by="ADMIN-001")

    results = store.search("t", "a", query="طھط¬ط±ظٹط¨ظٹط©")
    assert len(results) == 1
    assert results[0]["status"] == "approved"


def test_memory_review_rejects_already_decided_items():
    store = MemoryStore()
    item = store.add("t", "a", "ط­ظ‚ظٹظ‚ط© ط£ط®ط±ظ‰", source="test")
    store.review(item["memory_id"], "approved", reviewed_by="ADMIN-001")

    with pytest.raises(ValueError):
        store.review(item["memory_id"], "rejected", reviewed_by="ADMIN-001")

