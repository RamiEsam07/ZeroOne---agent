
class PermissionEngine:
    """
    Reusable permission engine for different business systems.
    """

    def __init__(
        self,
        role_permissions=None,
        approval_required_actions=None,
        human_only_actions=None
    ):
        self.role_permissions = role_permissions or {}

        self.approval_required_actions = (
            approval_required_actions or set()
        )

        self.human_only_actions = human_only_actions or set()

    def check_permission(
        self,
        user_role,
        action,
        approval_verified=False
    ):
        """
        Check whether a user role can perform an action.
        """

        if action in self.human_only_actions:
            return False, "This action requires an authorized human."

        if action in self.approval_required_actions:
            if not approval_verified:
                return False, "Verified human approval is required."

        allowed_actions = self.role_permissions.get(user_role, set())

        if action in allowed_actions:
            return True, "Action is permitted."

        return False, "Permission denied for this user role."
