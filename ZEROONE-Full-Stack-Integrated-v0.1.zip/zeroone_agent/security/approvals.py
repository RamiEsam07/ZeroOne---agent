"""
Human approval lifecycle with optional durable SQLite persistence.

The default remains in-memory for backwards-compatible tests and local use.
Pass SQLiteApprovalRepository for restart recovery and atomic cross-process decisions.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from threading import RLock
from uuid import uuid4


@dataclass
class ApprovalRecord:
    approval_id: str
    tenant_id: str
    agent_id: str
    principal_id: str
    action: str
    payload: dict
    status: str = "pending"
    created_at: str = ""
    expires_at: str = ""
    decided_by: str | None = None
    decided_at: str | None = None
    decision_reason: str | None = None


class ApprovalService:
    def __init__(self, default_ttl_minutes: int = 1440, repository=None):
        if isinstance(default_ttl_minutes, bool) or not isinstance(default_ttl_minutes, int):
            raise TypeError("default_ttl_minutes must be an integer")
        if default_ttl_minutes <= 0:
            raise ValueError("default_ttl_minutes must be positive")
        self._records: dict[str, ApprovalRecord] = {}
        self._lock = RLock()
        self.default_ttl_minutes = default_ttl_minutes
        self._repository = repository

    @staticmethod
    def _from_data(data: dict) -> ApprovalRecord:
        return ApprovalRecord(**data)

    def request(self, context, action: str, payload: dict) -> ApprovalRecord:
        if not isinstance(action, str) or not action.strip():
            raise ValueError("action is required")
        if not isinstance(payload, dict):
            raise TypeError("payload must be a dict")
        with self._lock:
            now = datetime.now(timezone.utc)
            record = ApprovalRecord(
                approval_id="APR-" + uuid4().hex,
                tenant_id=context.tenant_id,
                agent_id=context.agent_id,
                principal_id=context.principal_id,
                action=action,
                payload=dict(payload),
                created_at=now.isoformat(),
                expires_at=(now + timedelta(minutes=self.default_ttl_minutes)).isoformat(),
            )
            if self._repository is not None:
                self._repository.create(record)
            self._records[record.approval_id] = record
            return record

    def _load_record(self, approval_id: str, tenant_id: str) -> ApprovalRecord:
        if self._repository is not None:
            data = self._repository.get(approval_id, tenant_id)
            if data is None:
                raise KeyError("Approval not found")
            record = self._from_data(data)
            self._records[approval_id] = record
            return record

        record = self._records.get(approval_id)
        if record is None or record.tenant_id != tenant_id:
            raise KeyError("Approval not found")
        return record

    def _expire_if_needed(self, record: ApprovalRecord) -> ApprovalRecord:
        if record.status != "pending":
            return record

        expires_at = datetime.fromisoformat(record.expires_at)
        if datetime.now(timezone.utc) < expires_at:
            return record

        now = datetime.now(timezone.utc).isoformat()
        if self._repository is not None:
            changed = self._repository.transition(
                record.approval_id, record.tenant_id, "pending", "expired",
                reason="Approval request expired", decided_at=now, event_type="expired",
            )
            latest = self._repository.get(record.approval_id, record.tenant_id)
            if latest is not None:
                record = self._from_data(latest)
            return record

        record.status = "expired"
        record.decided_at = now
        record.decision_reason = "Approval request expired"
        return record

    def get(self, approval_id: str, tenant_id: str) -> ApprovalRecord:
        with self._lock:
            return self._expire_if_needed(self._load_record(approval_id, tenant_id))

    def decide(
        self,
        approval_id: str,
        tenant_id: str,
        decided_by: str,
        approved: bool,
        reason: str | None = None,
    ) -> ApprovalRecord:
        if not isinstance(decided_by, str) or not decided_by.strip():
            raise ValueError("decided_by is required")
        if not isinstance(approved, bool):
            raise TypeError("approved must be a bool")

        with self._lock:
            record = self._expire_if_needed(self._load_record(approval_id, tenant_id))
            if record.status != "pending":
                raise ValueError(f"Approval already {record.status}")

            # لا يجوز لصاحب الطلب اعتماد طلبه بنفسه افتراضياً.
            # الرفض يظل متاحاً؛ المنع يخص منح الموافقة فقط.
            if approved and decided_by.strip() == record.principal_id:
                raise PermissionError("Self-approval is not permitted.")

            new_status = "approved" if approved else "rejected"
            now = datetime.now(timezone.utc).isoformat()

            if self._repository is not None:
                changed = self._repository.transition(
                    approval_id, tenant_id, "pending", new_status,
                    actor_id=decided_by.strip(), reason=reason,
                    decided_at=now, event_type=new_status,
                    must_be_unexpired_at=now,
                )
                latest = self._repository.get(approval_id, tenant_id)
                if latest is None:
                    raise KeyError("Approval not found")
                record = self._from_data(latest)
                self._records[approval_id] = record
                if not changed:
                    raise ValueError(f"Approval already {record.status}")
                return record

            record.status = new_status
            record.decided_by = decided_by.strip()
            record.decided_at = now
            record.decision_reason = reason
            return record

    def list_pending(self, tenant_id: str) -> list[ApprovalRecord]:
        with self._lock:
            if self._repository is not None:
                records = [
                    self._from_data(data)
                    for data in self._repository.list_pending(tenant_id)
                ]
                self._records.update({r.approval_id: r for r in records})
            else:
                records = [
                    record for record in self._records.values()
                    if record.tenant_id == tenant_id and record.status == "pending"
                ]

            active = []
            for record in records:
                current = self._expire_if_needed(record)
                if current.status == "pending":
                    active.append(current)
            return active
