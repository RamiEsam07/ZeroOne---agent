
import unittest
from dataclasses import FrozenInstanceError
from datetime import datetime, timezone

from agent.contracts.agent_request import AgentRequest


class TestAgentRequest(unittest.TestCase):

    def setUp(self):
        self.request = AgentRequest(
            request_id="REQ-001",
            agent_id="AGENT-001",
            message="اعرض مواعيد اليوم",
            received_at=datetime.now(timezone.utc),
            context={"language": "ar"},
        )

    def test_valid_request_creation(self):
        self.assertEqual(self.request.request_id, "REQ-001")
        self.assertEqual(self.request.message, "اعرض مواعيد اليوم")

    def test_empty_required_field_is_rejected(self):
        with self.assertRaises(ValueError):
            AgentRequest(
                request_id="",
                agent_id="AGENT-001",
                message="اعرض مواعيد اليوم",
                received_at=datetime.now(timezone.utc),
            )

    def test_naive_datetime_is_rejected(self):
        with self.assertRaises(ValueError):
            AgentRequest(
                request_id="REQ-001",
                agent_id="AGENT-001",
                message="اعرض مواعيد اليوم",
                received_at=datetime.now(),
            )

    def test_invalid_context_type_is_rejected(self):
        with self.assertRaises(TypeError):
            AgentRequest(
                request_id="REQ-001",
                agent_id="AGENT-001",
                message="اعرض مواعيد اليوم",
                received_at=datetime.now(timezone.utc),
                context="invalid",
            )

    def test_request_is_immutable(self):
        with self.assertRaises(FrozenInstanceError):
            self.request.message = "طلب آخر"

    def test_nested_context_is_immutable(self):
        request = AgentRequest(
            request_id="REQ-002",
            agent_id="AGENT-001",
            message="Test request",
            received_at=datetime.now(timezone.utc),
            context={
                "user": {
                    "role": "receptionist"
                }
            },
        )

        with self.assertRaises(TypeError):
            request.context["user"]["role"] = "admin"

    def test_context_is_defensively_copied(self):
        original_context = {
            "user": {
                "role": "receptionist"
            }
        }

        request = AgentRequest(
            request_id="REQ-003",
            agent_id="AGENT-001",
            message="Test request",
            received_at=datetime.now(timezone.utc),
            context=original_context,
        )

        original_context["user"]["role"] = "admin"

        self.assertEqual(
            request.context["user"]["role"],
            "receptionist"
        )


if __name__ == "__main__":
    unittest.main()
