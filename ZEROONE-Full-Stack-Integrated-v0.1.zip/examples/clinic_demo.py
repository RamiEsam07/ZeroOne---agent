"""
مثال تشغيلي كامل: وكيل عيادة يستقبل طلبًا بالعربية ويرد عليه.

شغّله بـ: python examples/clinic_demo.py
"""

from zeroone_agent.audit.logger import AuditLogger
from zeroone_agent.contracts.models import AgentRequest, ExecutionContext
from zeroone_agent.domains.clinic.policy import capabilities_for_role
from zeroone_agent.domains.clinic.tools import register_clinic_tools
from zeroone_agent.runtime.agent import AgentRuntime
from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.security.approval_repository import SQLiteApprovalRepository
from zeroone_agent.security.policy import PermissionEngine
from zeroone_agent.tools.executor import ToolExecutor
from zeroone_agent.tools.registry import ToolRegistry


def main():
    registry = ToolRegistry()
    register_clinic_tools(registry)

    audit = AuditLogger()
    approval_repository = SQLiteApprovalRepository("data/zeroone.db")
    approvals = ApprovalService(repository=approval_repository)
    executor = ToolExecutor(registry, PermissionEngine(), audit)
    runtime = AgentRuntime(registry, executor, audit, approvals)

    # موظف استقبال يسأل عن مواعيد اليوم
    context = ExecutionContext(
        request_id="REQ-1",
        execution_id="EX-1",
        trace_id="TR-1",
        tenant_id="clinic-demo",
        agent_id="clinic-agent",
        agent_version="1.0",
        domain="clinic",
        principal_id="receptionist-1",
        capabilities=capabilities_for_role("receptionist"),
    )

    request = AgentRequest(
        request_id="REQ-1",
        agent_id="clinic-agent",
        message="اعرض المواعيد",
        context={"date": "2026-11-08"},
    )

    response = runtime.handle(request, context)

    print("=" * 50)
    print(f"الحالة: {response.status.value}")
    print(f"الرسالة: {response.message}")
    print(f"البيانات: {dict(response.data)}")
    print("=" * 50)

    # نفس الطلب، لكن بدون صلاحية — يجب أن يحتاج اعتماد بشري
    unauthorized_context = ExecutionContext(
        request_id="REQ-2",
        execution_id="EX-2",
        trace_id="TR-2",
        tenant_id="clinic-demo",
        agent_id="clinic-agent",
        agent_version="1.0",
        domain="clinic",
        principal_id="visitor-1",
        capabilities=(),  # لا يملك أي صلاحية
    )

    request2 = AgentRequest(
        request_id="REQ-2",
        agent_id="clinic-agent",
        message="اعرض المواعيد",
        context={"date": "2026-11-08"},
    )

    response2 = runtime.handle(request2, unauthorized_context)

    print(f"\nمحاولة بدون صلاحية → الحالة: {response2.status.value}")
    print(f"الرسالة: {response2.message}")
    if response2.approval_id:
        print(f"معرّف طلب الاعتماد: {response2.approval_id}")


if __name__ == "__main__":
    main()
