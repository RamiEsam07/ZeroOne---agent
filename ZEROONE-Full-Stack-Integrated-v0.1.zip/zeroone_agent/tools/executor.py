"""
منفذ الأدوات (Tool Executor).

يمثل الخط النهائي قبل التنفيذ الفعلي: يتحقق من الصلاحية، يتحقق من صحة
المدخلات مقابل مخطط JSON Schema، ينفذ الأداة، يتحقق من صحة المخرجات،
ثم يسجل الحدث في سجل التدقيق. أي خطوة فاشلة توقف العملية فورًا.
"""

from jsonschema import Draft202012Validator

from zeroone_agent.contracts.models import ToolResult, thaw_json_value


class ToolExecutor:
    """ينفذ الأدوات المسجلة عبر واجهة موحدة، مع تحقق صارم في كل خطوة."""

    def __init__(self, registry, permissions, audit):
        self.registry = registry
        self.permissions = permissions
        self.audit = audit

    def execute(self, invocation) -> ToolResult:
        tool = self.registry.get(invocation.tool_id)

        decision = self.permissions.authorize(invocation.context, tool.definition)

        if not decision.allowed:
            self.audit.record(
                invocation.context,
                "tool.denied",
                {"tool_id": invocation.tool_id, "reason": decision.reason},
            )
            return ToolResult(
                invocation.invocation_id,
                success=False,
                error={"code": "PERMISSION_DENIED", "message": decision.reason},
            )

        arguments = thaw_json_value(invocation.arguments)

        input_errors = list(
            Draft202012Validator(tool.definition.input_schema).iter_errors(arguments)
        )
        if input_errors:
            self.audit.record(
                invocation.context,
                "tool.invalid_arguments",
                {"tool_id": invocation.tool_id, "error": input_errors[0].message},
            )
            return ToolResult(
                invocation.invocation_id,
                success=False,
                error={"code": "INVALID_ARGUMENTS", "message": input_errors[0].message},
            )

        try:
            output = tool.handler(arguments, invocation.context)

            if not isinstance(output, dict):
                raise TypeError("Tool handler must return a dict.")

            Draft202012Validator(tool.definition.output_schema).validate(output)

            self.audit.record(
                invocation.context,
                "tool.completed",
                {"tool_id": invocation.tool_id},
            )
            return ToolResult(invocation.invocation_id, success=True, data=output)

        except Exception as error:
            self.audit.record(
                invocation.context,
                "tool.failed",
                {"tool_id": invocation.tool_id, "error_type": type(error).__name__},
            )
            return ToolResult(
                invocation.invocation_id,
                success=False,
                error={
                    "code": "TOOL_EXECUTION_FAILED",
                    "message": "Tool execution failed.",
                },
            )
