
import unittest
from dataclasses import FrozenInstanceError
from datetime import datetime, timedelta, timezone

from agent.contracts.execution_context import ExecutionContext


class TestExecutionContext(unittest.TestCase):

    def setUp(self):
        self.created_at = datetime.now(timezone.utc)

        self.context = ExecutionContext(
            request_id="REQ-001",
            execution_id="EXEC-001",
            trace_id="TRACE-001",
            tenant_id="TENANT-001",
            agent_id="AGENT-001",
            agent_version="1.0.0",
            domain="clinic",
            principal_id="USER-001",
            authentication_method="verified_session",
            created_at=self.created_at,
            deadline=self.created_at + timedelta(minutes=1),
            locale="ar",
            timezone="Africa/Khartoum",
        )

    def test_valid_context_creation(self):
        self.assertEqual(self.context.tenant_id, "TENANT-001")
        self.assertEqual(self.context.domain, "clinic")

    def test_empty_required_field_is_rejected(self):
        with self.assertRaises(ValueError):
            ExecutionContext(
                request_id="",
                execution_id="EXEC-001",
                trace_id="TRACE-001",
                tenant_id="TENANT-001",
                agent_id="AGENT-001",
                agent_version="1.0.0",
                domain="clinic",
                principal_id="USER-001",
                authentication_method="verified_session",
                created_at=self.created_at,
                deadline=self.created_at + timedelta(minutes=1),
                locale="ar",
                timezone="Africa/Khartoum",
            )

    def test_naive_datetime_is_rejected(self):
        with self.assertRaises(ValueError):
            ExecutionContext(
                request_id="REQ-001",
                execution_id="EXEC-001",
                trace_id="TRACE-001",
                tenant_id="TENANT-001",
                agent_id="AGENT-001",
                agent_version="1.0.0",
                domain="clinic",
                principal_id="USER-001",
                authentication_method="verified_session",
                created_at=datetime.now(),
                deadline=datetime.now() + timedelta(minutes=1),
                locale="ar",
                timezone="Africa/Khartoum",
            )

    def test_invalid_deadline_is_rejected(self):
        with self.assertRaises(ValueError):
            ExecutionContext(
                request_id="REQ-001",
                execution_id="EXEC-001",
                trace_id="TRACE-001",
                tenant_id="TENANT-001",
                agent_id="AGENT-001",
                agent_version="1.0.0",
                domain="clinic",
                principal_id="USER-001",
                authentication_method="verified_session",
                created_at=self.created_at,
                deadline=self.created_at,
                locale="ar",
                timezone="Africa/Khartoum",
            )

    def test_context_is_immutable(self):
        with self.assertRaises(FrozenInstanceError):
            self.context.tenant_id = "TENANT-002"


if __name__ == "__main__":
    unittest.main()
