import math
from types import MappingProxyType
from collections.abc import Mapping


def freeze_json_value(value):
    """
    Recursively convert JSON-compatible values
    into immutable structures.
    """

    if value is None:
        return None

    if isinstance(value, (str, bool, int)):
        return value

    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Float values must be finite.")
        return value

    if isinstance(value, Mapping):
        frozen_dict = {}

        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("Mapping keys must be strings.")

            frozen_dict[key] = freeze_json_value(item)

        return MappingProxyType(frozen_dict)

    if isinstance(value, (list, tuple)):
        return tuple(
            freeze_json_value(item)
            for item in value
        )

    raise TypeError(
        f"Unsupported value type: {type(value).__name__}"
    )