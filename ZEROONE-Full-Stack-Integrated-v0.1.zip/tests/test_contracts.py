"""
اختبارات تفصيلية لطبقة العقود (contracts/models.py).

منقولة ومُحسّنة من نسخة unittest الأصلية — تغطي حالات حافة (edge cases)
مهمة لم تكن مغطاة في test_engine.py: النسخ الدفاعي، الحماية من التعديل
المتداخل، القيم غير المدعومة، إلخ.
"""

from datetime import datetime, timezone

import pytest

from zeroone_agent.contracts.models import (
    AgentRequest,
    AgentResponse,
    ExecutionContext,
    ResponseStatus,
    ToolDefinition,
    freeze_json_value,
)


# ============================================================
# AgentRequest
# ============================================================

def test_agent_request_valid_creation():
    request = AgentRequest(
        request_id="REQ-001",
        agent_id="AGENT-001",
        message="اعرض مواعيد اليوم",
        received_at=datetime.now(timezone.utc),
        context={"language": "ar"},
    )
    assert request.request_id == "REQ-001"
    assert request.message == "اعرض مواعيد اليوم"


def test_agent_request_empty_required_field_rejected():
    with pytest.raises(ValueError):
        AgentRequest(
            request_id="",
            agent_id="AGENT-001",
            message="اعرض مواعيد اليوم",
            received_at=datetime.now(timezone.utc),
        )


def test_agent_request_naive_datetime_rejected():
    with pytest.raises(ValueError):
        AgentRequest(
            request_id="REQ-001",
            agent_id="AGENT-001",
            message="اعرض مواعيد اليوم",
            received_at=datetime.now(),  # بدون timezone
        )


def test_agent_request_invalid_context_type_rejected():
    with pytest.raises(TypeError):
        AgentRequest(
            request_id="REQ-001",
            agent_id="AGENT-001",
            message="اعرض مواعيد اليوم",
            received_at=datetime.now(timezone.utc),
            context="invalid",
        )


def test_agent_request_is_immutable():
    request = AgentRequest(
        request_id="REQ-001", agent_id="AGENT-001", message="test",
        received_at=datetime.now(timezone.utc),
    )
    with pytest.raises(Exception):  # FrozenInstanceError
        request.message = "طلب آخر"


def test_agent_request_nested_context_is_immutable():
    request = AgentRequest(
        request_id="REQ-002", agent_id="AGENT-001", message="test",
        received_at=datetime.now(timezone.utc),
        context={"user": {"role": "receptionist"}},
    )
    with pytest.raises(TypeError):
        request.context["user"]["role"] = "admin"


def test_agent_request_context_is_defensively_copied():
    original_context = {"user": {"role": "receptionist"}}
    request = AgentRequest(
        request_id="REQ-003", agent_id="AGENT-001", message="test",
        received_at=datetime.now(timezone.utc),
        context=original_context,
    )
    original_context["user"]["role"] = "admin"
    assert request.context["user"]["role"] == "receptionist"


# ============================================================
# freeze_json_value
# ============================================================

def test_freeze_nested_mapping_is_immutable():
    frozen = freeze_json_value({"user": {"role": "receptionist"}})
    with pytest.raises(TypeError):
        frozen["user"]["role"] = "admin"


def test_freeze_nested_list_becomes_tuple():
    frozen = freeze_json_value({"permissions": ["view_appointments"]})
    assert isinstance(frozen["permissions"], tuple)
    with pytest.raises(AttributeError):
        frozen["permissions"].append("delete_records")


def test_freeze_does_not_mutate_original():
    original = {"settings": {"language": "ar"}}
    freeze_json_value(original)
    original["settings"]["language"] = "en"
    assert original["settings"]["language"] == "en"  # الأصل حر في التغيير


def test_freeze_rejects_unsupported_type():
    with pytest.raises(TypeError):
        freeze_json_value({"value": {1, 2, 3}})  # set غير مدعوم


def test_freeze_rejects_non_finite_float():
    with pytest.raises(ValueError):
        freeze_json_value({"value": float("nan")})


def test_freeze_preserves_valid_json_values():
    frozen = freeze_json_value({
        "name": "ZEROONE", "active": True, "version": 1,
        "score": 9.5, "metadata": None,
    })
    assert frozen["name"] == "ZEROONE"
    assert frozen["active"] is True
    assert frozen["version"] == 1
    assert frozen["score"] == 9.5
    assert frozen["metadata"] is None


# ============================================================
# AgentResponse
# ============================================================

def test_response_failed_requires_error():
    now = datetime.now(timezone.utc)
    with pytest.raises(ValueError):
        AgentResponse(
            request_id="r", agent_id="a", status=ResponseStatus.FAILED,
            message="فشل", responded_at=now, finished_at=now, error=None,
        )


def test_response_approval_required_needs_approval_id():
    now = datetime.now(timezone.utc)
    with pytest.raises(ValueError):
        AgentResponse(
            request_id="r", agent_id="a", status=ResponseStatus.APPROVAL_REQUIRED,
            message="يحتاج موافقة", responded_at=now, finished_at=now,
            approval_id=None,
        )


def test_response_finished_at_cannot_be_after_responded_at():
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    with pytest.raises(ValueError):
        AgentResponse(
            request_id="r", agent_id="a", status=ResponseStatus.COMPLETED,
            message="تم", responded_at=now, finished_at=now + timedelta(seconds=5),
        )


# ============================================================
# ToolDefinition
# ============================================================

def test_tool_definition_rejects_invalid_json_schema():
    with pytest.raises(Exception):
        ToolDefinition(
            tool_id="t1", name="test", version="1.0", description="desc",
            domain="clinic",
            input_schema={"type": "not_a_real_type"},
            output_schema={"type": "object"},
        )


def test_tool_definition_rejects_duplicate_capabilities():
    with pytest.raises(ValueError):
        ToolDefinition(
            tool_id="t1", name="test", version="1.0", description="desc",
            domain="clinic",
            input_schema={"type": "object"},
            output_schema={"type": "object"},
            required_capabilities=("read", "read"),
        )


def test_response_default_timestamps_are_consistent():
    response = AgentResponse(
        request_id="r-default",
        agent_id="a-default",
        status=ResponseStatus.COMPLETED,
        message="تم",
    )
    assert response.finished_at == response.responded_at
    assert response.finished_at.tzinfo is not None


def test_response_allows_explicit_finished_at_before_response_time():
    from datetime import timedelta
    responded_at = datetime.now(timezone.utc)
    response = AgentResponse(
        request_id="r-explicit",
        agent_id="a-explicit",
        status=ResponseStatus.COMPLETED,
        message="تم",
        responded_at=responded_at,
        finished_at=responded_at - timedelta(seconds=1),
    )
    assert response.finished_at < response.responded_at


def _valid_execution_context(**overrides):
    values = {
        "request_id": "REQ-CTX",
        "execution_id": "EXEC-CTX",
        "trace_id": "TRACE-CTX",
        "tenant_id": "TENANT-1",
        "agent_id": "AGENT-1",
        "agent_version": "0.3.1",
        "domain": "clinic",
        "principal_id": "USER-1",
    }
    values.update(overrides)
    return ExecutionContext(**values)


def test_execution_context_accepts_valid_capabilities():
    context = _valid_execution_context(capabilities=["clinic.read", "clinic.write"])
    assert context.capabilities == ("clinic.read", "clinic.write")


@pytest.mark.parametrize("invalid", ["clinic.read", b"clinic.read", {"clinic.read"}, {"capability": "clinic.read"}, 42])
def test_execution_context_rejects_invalid_capability_container(invalid):
    with pytest.raises(TypeError):
        _valid_execution_context(capabilities=invalid)


def test_execution_context_rejects_duplicate_capabilities():
    with pytest.raises(ValueError):
        _valid_execution_context(capabilities=("clinic.read", "clinic.read"))


def _valid_tool_definition(**overrides):
    values = {
        "tool_id": "tool.test",
        "name": "test",
        "version": "1.0.0",
        "description": "Test tool",
        "domain": "clinic",
        "input_schema": {"type": "object"},
        "output_schema": {"type": "object"},
    }
    values.update(overrides)
    return ToolDefinition(**values)


def test_tool_definition_accepts_valid_capability_list():
    definition = _valid_tool_definition(required_capabilities=["clinic.read"])
    assert definition.required_capabilities == ("clinic.read",)


@pytest.mark.parametrize("invalid", ["clinic.read", b"clinic.read", {"clinic.read"}, {"capability": "clinic.read"}, 42])
def test_tool_definition_rejects_invalid_capability_container(invalid):
    with pytest.raises(TypeError):
        _valid_tool_definition(required_capabilities=invalid)


def test_tool_definition_rejects_duplicate_capabilities():
    with pytest.raises(ValueError):
        _valid_tool_definition(required_capabilities=("clinic.read", "clinic.read"))
