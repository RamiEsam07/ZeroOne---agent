from fastapi.testclient import TestClient
from pathlib import Path
import json
import zeroone_agent.application.app as api


def test_fullstack_routes_are_served_and_actions_persist(tmp_path, monkeypatch):
    appointments = tmp_path / "appointments.json"
    patients = tmp_path / "patients.json"
    appointments.write_text(json.dumps({"appointments": []}), encoding="utf-8")
    patients.write_text(json.dumps({"patients": []}), encoding="utf-8")
    monkeypatch.setattr(api, "APPOINTMENTS_FILE", appointments)
    import zeroone_agent.domains.clinic.tools as clinic_tools
    monkeypatch.setattr(clinic_tools, "DATA_FILE", appointments)
    monkeypatch.setattr(api, "PATIENTS_FILE", patients)
    client = TestClient(api.app)

    root = client.get("/")
    assert root.status_code == 200
    assert "ZEROONE" in root.text

    login = client.post("/auth/login", json={"username": "receptionist", "password": "reception123"})
    assert login.status_code == 200
    token = login.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    patient = client.post("/actions/register-patient", headers=headers, json={
        "name": "Test Patient", "phone": "0999999999", "age": 25, "notes": ""
    })
    assert patient.status_code == 200
    assert len(client.get("/patients", headers=headers).json()["patients"]) == 1

    booked = client.post("/actions/book-appointment", headers=headers, json={
        "patient_name": "Test Patient", "doctor": "Dr Test", "date": "2026-11-20", "time": "09:30"
    })
    assert booked.status_code == 200
    appointment_id = booked.json()["data"]["id"]
    assert client.get("/appointments?date=2026-11-20", headers=headers).json()["total"] == 1

    cancelled = client.post("/actions/cancel-appointment", headers=headers, json={"appointment_id": appointment_id})
    assert cancelled.status_code == 200

    assert client.post("/actions/register-patient", headers=headers, json={
        "name": "Other Patient", "phone": "0999999998"
    }).status_code == 200


def test_receptionist_cannot_read_revenue_report():
    client = TestClient(api.app)
    login = client.post("/auth/login", json={"username": "receptionist", "password": "reception123"})
    headers = {"Authorization": f"Bearer {login.json()['token']}"}
    response = client.post("/actions/revenue-report", headers=headers, json={
        "date_from": "2026-11-01", "date_to": "2026-11-30"
    })
    assert response.status_code == 403
