"""
دستور الوكيل (Agent Constitution).

يحمّل المبادئ التأسيسية للوكيل من data/agent_constitution.json ويجعلها
متاحة برمجيًا. هذا ليس مجرد توثيق — المبادئ هنا تعكس القرارات المعمارية
الفعلية في الكود (مثلاً: "تحقق من الصلاحيات قبل التنفيذ" = PermissionEngine،
"سجل العمليات المهمة" = AuditLogger).
"""

import json
from pathlib import Path
from functools import lru_cache

CONSTITUTION_FILE = Path(__file__).resolve().parents[1] / "data" / "agent_constitution.json"


@lru_cache(maxsize=1)
def load_constitution() -> dict:
    """يحمّل الدستور من القرص (مع تخزين مؤقت — الملف لا يتغير أثناء التشغيل)."""
    with open(CONSTITUTION_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def mission() -> str:
    return load_constitution()["mission"]


def principles() -> list[str]:
    return load_constitution()["principles"]


def authority_for(role: str) -> str | None:
    """يرجع وصف صلاحية دور معين (general_manager, agent, إلخ) حسب الدستور."""
    return load_constitution().get("authority", {}).get(role)
