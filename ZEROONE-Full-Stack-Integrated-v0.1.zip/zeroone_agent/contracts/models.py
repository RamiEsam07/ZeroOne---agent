
"""
العقود الأساسية (Data Contracts) لمحرك وكيل ZEROONE.

كل كائن هنا immutable (frozen dataclass) ومتحقق من صحته عند الإنشاء.
الهدف: أي خطأ في البيانات يظهر فورًا عند الإنشاء، مش بعد كده في منتصف التنفيذ.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from collections.abc import Mapping
from types import MappingProxyType
from typing import Any
import math
import hashlib
import json

from jsonschema import Draft202012Validator


# ============================================================
# أدوات مساعدة: تجميد وفك تجميد قيم JSON
# ============================================================

def freeze_json_value(value):
    """تحويل قيم JSON إلى بنية غير قابلة للتعديل بشكل متكرر."""
    if value is None or isinstance(value, (str, bool, int)):
        return value

    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Float values must be finite.")
        return value

    if isinstance(value, Mapping):
        if not all(isinstance(k, str) for k in value):
            raise TypeError("Mapping keys must be strings.")

        return MappingProxyType(
            {k: freeze_json_value(v) for k, v in value.items()}
        )

    if isinstance(value, (list, tuple)):
        return tuple(freeze_json_value(item) for item in value)

    raise TypeError(
        f"Unsupported JSON value type: {type(value).__name__}"
    )


def thaw_json_value(value):
    """تحويل القيمة المجمدة إلى dict/list عادية."""
    if isinstance(value, Mapping):
        return {
            k: thaw_json_value(v)
            for k, v in value.items()
        }

    if isinstance(value, tuple):
        return [
            thaw_json_value(v)
            for v in value
        ]

    return value


def _require_timezone_aware(value, field_name):
    if not isinstance(value, datetime):
        raise TypeError(f"{field_name} must be a datetime.")

    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(
            f"{field_name} must be timezone-aware."
        )


def _require_nonempty_str(value, field_name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"{field_name} must be a non-empty string."
        )


def calculate_operation_hash(
    operation_data: Mapping[str, Any],
) -> str:
    """حساب بصمة ثابتة لنية العملية باستخدام SHA-256."""

    if not isinstance(operation_data, Mapping):
        raise TypeError(
            "operation_data must be a mapping."
        )

    frozen_data = freeze_json_value(operation_data)
    plain_data = thaw_json_value(frozen_data)

    canonical_data = json.dumps(
        plain_data,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )

    return hashlib.sha256(
        canonical_data.encode("utf-8")
    ).hexdigest()


# ============================================================
# حالة الاستجابة
# ============================================================

class ResponseStatus(str, Enum):
    COMPLETED = "completed"
    REJECTED = "rejected"
    DENIED = "denied"
    APPROVAL_REQUIRED = "approval_required"
    FAILED = "failed"
    UNSUPPORTED = "unsupported"


# ============================================================
# سياسة تنفيذ الأدوات
# ============================================================

class ExecutionPolicy(str, Enum):
    """تحدد مستوى الاستقلالية المسموح به عند تنفيذ الأداة."""

    STANDARD = "standard"
    APPROVAL_REQUIRED = "approval_required"
    HUMAN_ONLY = "human_only"


# ============================================================
# حالات التنفيذ
# ============================================================

class ExecutionStatus(str, Enum):
    """تحدد المرحلة الحالية لتنفيذ العملية المعتمدة."""

    NOT_STARTED = "not_started"
    EXECUTING = "executing"
    EXECUTED = "executed"
    FAILED = "failed"
    OUTCOME_UNKNOWN = "outcome_unknown"
    UNDER_REVIEW = "under_review"


# ============================================================
# ExecutionRecord
# ============================================================

@dataclass(frozen=True, slots=True)
class ExecutionRecord:
    """سجل ثابت للعملية التي تنتظر التنفيذ أو يجري تنفيذها."""

    execution_id: str
    approval_id: str

    tenant_id: str
    agent_id: str
    domain: str
    principal_id: str

    tool_id: str
    tool_version: str
    schema_version: str

    arguments: Mapping[str, Any]
    idempotency_key: str

    status: ExecutionStatus

    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    operation_hash: str = ""

    def __post_init__(self):
        required_fields = (
            "execution_id",
            "approval_id",
            "tenant_id",
            "agent_id",
            "domain",
            "principal_id",
            "tool_id",
            "tool_version",
            "schema_version",
            "idempotency_key",
        )

        for name in required_fields:
            _require_nonempty_str(
                getattr(self, name),
                name,
            )

        if not isinstance(self.status, ExecutionStatus):
            raise TypeError(
                "status must be an ExecutionStatus value."
            )

        _require_timezone_aware(
            self.created_at,
            "created_at",
        )

        if not isinstance(self.arguments, Mapping):
            raise TypeError(
                "arguments must be a mapping."
            )

        frozen_arguments = freeze_json_value(
            self.arguments
        )

        object.__setattr__(
            self,
            "arguments",
            frozen_arguments,
        )

        operation_data = {
            "approval_id": self.approval_id,
            "tenant_id": self.tenant_id,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "principal_id": self.principal_id,
            "tool_id": self.tool_id,
            "tool_version": self.tool_version,
            "schema_version": self.schema_version,
            "arguments": thaw_json_value(
                frozen_arguments
            ),
        }

        expected_hash = calculate_operation_hash(
            operation_data
        )

        # التحقق من نوع البصمة
        if not isinstance(self.operation_hash, str):
            raise TypeError(
                "operation_hash must be a string."
            )

        # النص الفارغ فقط يعني أن النظام يحسب البصمة تلقائياً
        if self.operation_hash == "":
            object.__setattr__(
                self,
                "operation_hash",
                expected_hash,
            )
            return

        # التحقق من طول البصمة
        if len(self.operation_hash) != 64:
            raise ValueError(
                "operation_hash must be a SHA-256 digest."
            )

        # التحقق من صيغة SHA-256
        if any(
            char not in "0123456789abcdef"
            for char in self.operation_hash
        ):
            raise ValueError(
                "operation_hash must be lowercase hexadecimal."
            )

        # التأكد من أن البصمة تطابق بيانات العملية
        if self.operation_hash != expected_hash:
            raise ValueError(
                "operation_hash does not match operation data."
            )


# ============================================================
# AgentRequest
# ============================================================

@dataclass(frozen=True, slots=True)
class AgentRequest:
    """طلب وارد من عميل نهائي، وبياناته غير موثوقة."""

    request_id: str
    agent_id: str
    message: str

    received_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    context: Mapping[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self):
        for name in (
            "request_id",
            "agent_id",
            "message",
        ):
            _require_nonempty_str(
                getattr(self, name),
                name,
            )

        _require_timezone_aware(
            self.received_at,
            "received_at",
        )

        if not isinstance(self.context, Mapping):
            raise TypeError(
                "context must be a mapping."
            )

        object.__setattr__(
            self,
            "context",
            freeze_json_value(self.context),
        )


# ============================================================
# ExecutionContext
# ============================================================

@dataclass(frozen=True, slots=True)
class ExecutionContext:
    """سياق تنفيذ موثوق يُنشأ بعد التحقق من الهوية."""

    request_id: str
    execution_id: str
    trace_id: str

    tenant_id: str
    agent_id: str
    agent_version: str
    domain: str

    principal_id: str

    capabilities: tuple[str, ...] = ()

    locale: str = "ar"
    timezone_name: str = "Africa/Khartoum"

    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def __post_init__(self):
        required = (
            "request_id",
            "execution_id",
            "trace_id",
            "tenant_id",
            "agent_id",
            "agent_version",
            "domain",
            "principal_id",
        )

        for name in required:
            _require_nonempty_str(
                getattr(self, name),
                name,
            )

        _require_timezone_aware(
            self.created_at,
            "created_at",
        )

        if not isinstance(self.capabilities, (tuple, list)):
            raise TypeError(
                "capabilities must be a tuple or list of strings."
            )

        capabilities = tuple(self.capabilities)

        for capability in capabilities:
            _require_nonempty_str(
                capability,
                "each capability",
            )

        if len(capabilities) != len(set(capabilities)):
            raise ValueError(
                "capabilities must not contain duplicates."
            )

        object.__setattr__(
            self,
            "capabilities",
            capabilities,
        )


# ============================================================
# AgentResponse
# ============================================================

@dataclass(frozen=True, slots=True)
class AgentResponse:
    """استجابة موحدة ومتحقق منها."""

    request_id: str
    agent_id: str
    status: ResponseStatus
    message: str

    responded_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    finished_at: datetime | None = None

    data: Mapping[str, Any] = field(
        default_factory=dict
    )

    error: Mapping[str, Any] | None = None
    approval_id: str | None = None

    def __post_init__(self):
        for name in (
            "request_id",
            "agent_id",
            "message",
        ):
            _require_nonempty_str(
                getattr(self, name),
                name,
            )

        if not isinstance(self.status, ResponseStatus):
            raise TypeError(
                "status must be a ResponseStatus value."
            )

        _require_timezone_aware(
            self.responded_at,
            "responded_at",
        )

        # عند عدم تمرير finished_at، نستخدم responded_at نفسه
        # حتى لا يؤدي اختلاف لحظتي default_factory إلى رفض الإنشاء.
        if self.finished_at is None:
            object.__setattr__(
                self,
                "finished_at",
                self.responded_at,
            )

        _require_timezone_aware(
            self.finished_at,
            "finished_at",
        )

        if self.finished_at > self.responded_at:
            raise ValueError(
                "finished_at cannot be later than responded_at."
            )

        if not isinstance(self.data, Mapping):
            raise TypeError(
                "data must be a mapping."
            )

        if (
            self.error is not None
            and not isinstance(self.error, Mapping)
        ):
            raise TypeError(
                "error must be a mapping or None."
            )

        if self.status == ResponseStatus.APPROVAL_REQUIRED:
            if (
                not isinstance(self.approval_id, str)
                or not self.approval_id.strip()
            ):
                raise ValueError(
                    "approval_id is required when approval is needed."
                )

        elif self.approval_id is not None:
            raise ValueError(
                "approval_id is only allowed for approval-required responses."
            )

        if (
            self.status == ResponseStatus.FAILED
            and self.error is None
        ):
            raise ValueError(
                "A failed response must include error details."
            )

        if (
            self.status != ResponseStatus.FAILED
            and self.error is not None
        ):
            raise ValueError(
                "Error details are only allowed for failed responses."
            )

        object.__setattr__(
            self,
            "data",
            freeze_json_value(self.data),
        )

        if self.error is not None:
            object.__setattr__(
                self,
                "error",
                freeze_json_value(self.error),
            )


# ============================================================
# ToolDefinition
# ============================================================

@dataclass(frozen=True, slots=True)
class ToolDefinition:
    """
    وصف ثابت للأداة.
    يحدد العقد والصلاحيات وسياسة التنفيذ دون احتواء التنفيذ الفعلي.
    """

    tool_id: str
    name: str
    version: str
    description: str
    domain: str

    input_schema: Mapping[str, Any]
    output_schema: Mapping[str, Any]

    required_capabilities: tuple[str, ...] = ()

    execution_policy: ExecutionPolicy = ExecutionPolicy.STANDARD

    def __post_init__(self):
        for name in (
            "tool_id",
            "name",
            "version",
            "description",
            "domain",
        ):
            _require_nonempty_str(
                getattr(self, name),
                name,
            )

        for schema_name in (
            "input_schema",
            "output_schema",
        ):
            schema = getattr(self, schema_name)

            if not isinstance(schema, Mapping):
                raise TypeError(
                    f"{schema_name} must be a mapping."
                )

            Draft202012Validator.check_schema(
                dict(schema)
            )

            object.__setattr__(
                self,
                schema_name,
                freeze_json_value(schema),
            )

        if not isinstance(self.required_capabilities, (tuple, list)):
            raise TypeError(
                "required_capabilities must be a tuple or list of strings."
            )

        capabilities = tuple(self.required_capabilities)

        for capability in capabilities:
            _require_nonempty_str(
                capability,
                "each capability",
            )

        if len(capabilities) != len(set(capabilities)):
            raise ValueError(
                "required_capabilities must not contain duplicates."
            )

        object.__setattr__(
            self,
            "required_capabilities",
            capabilities,
        )

        if not isinstance(
            self.execution_policy,
            ExecutionPolicy,
        ):
            raise TypeError(
                "execution_policy must be an ExecutionPolicy value."
            )


# ============================================================
# ToolInvocation / ToolResult
# ============================================================

@dataclass(frozen=True, slots=True)
class ToolInvocation:
    """نداء واحد لأداة بسياق تنفيذ موثوق."""

    invocation_id: str
    tool_id: str
    context: ExecutionContext
    arguments: Mapping[str, Any]

    def __post_init__(self):
        _require_nonempty_str(
            self.invocation_id,
            "invocation_id",
        )

        _require_nonempty_str(
            self.tool_id,
            "tool_id",
        )

        if not isinstance(
            self.context,
            ExecutionContext,
        ):
            raise TypeError(
                "context must be an ExecutionContext."
            )

        if not isinstance(self.arguments, Mapping):
            raise TypeError(
                "arguments must be a mapping."
            )

        object.__setattr__(
            self,
            "arguments",
            freeze_json_value(self.arguments),
        )


@dataclass(frozen=True, slots=True)
class ToolResult:
    """نتيجة تنفيذ الأداة: نجاح ببيانات أو فشل بخطأ."""

    invocation_id: str
    success: bool

    data: Mapping[str, Any] = field(
        default_factory=dict
    )

    error: Mapping[str, Any] | None = None

    def __post_init__(self):
        _require_nonempty_str(
            self.invocation_id,
            "invocation_id",
        )

        if not isinstance(self.success, bool):
            raise TypeError(
                "success must be a boolean."
            )

        if not isinstance(self.data, Mapping):
            raise TypeError(
                "data must be a mapping."
            )

        if (
            self.error is not None
            and not isinstance(self.error, Mapping)
        ):
            raise TypeError(
                "error must be a mapping or None."
            )

        object.__setattr__(
            self,
            "data",
            freeze_json_value(self.data),
        )

        if self.error is not None:
            object.__setattr__(
                self,
                "error",
                freeze_json_value(self.error),
            )

        if self.success == (self.error is not None):
            raise ValueError(
                "A successful result must not have an error, "
                "and a failed result must have one."
            )
