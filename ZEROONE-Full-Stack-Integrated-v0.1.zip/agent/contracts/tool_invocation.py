﻿from dataclasses import dataclass
from typing import Any, Mapping

from .value_objects import freeze_json_value


@dataclass(frozen=True, slots=True)
class ToolInvocation:
    """
    Immutable request to execute a registered tool.
    """

    invocation_id: str
    request_id: str
    execution_id: str
    tool_id: str
    arguments: Mapping[str, Any]

    def __post_init__(self):
        required_fields = (
            "invocation_id",
            "request_id",
            "execution_id",
            "tool_id",
        )

        for field_name in required_fields:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        if not isinstance(self.arguments, Mapping):
            raise TypeError("arguments must be a mapping.")

        object.__setattr__(
            self,
            "arguments",
            freeze_json_value(self.arguments),
        )
