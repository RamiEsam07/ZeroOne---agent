﻿from zeroone_agent.audit.logger import AuditLogger
from zeroone_agent.domains.clinic.tools import register_clinic_tools
from zeroone_agent.runtime.agent import AgentRuntime
from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.security.approval_repository import SQLiteApprovalRepository
from zeroone_agent.security.policy import PermissionEngine
from zeroone_agent.tools.executor import ToolExecutor
from zeroone_agent.tools.registry import ToolRegistry


def create_clinic_runtime():
    registry = ToolRegistry()
    register_clinic_tools(registry)

    audit = AuditLogger()
    approval_repository = SQLiteApprovalRepository("data/zeroone.db")
    approvals = ApprovalService(repository=approval_repository)

    permissions = PermissionEngine()
    executor = ToolExecutor(registry, permissions, audit)

    runtime = AgentRuntime(
        registry,
        executor,
        audit,
        approvals,
    )

    return runtime
