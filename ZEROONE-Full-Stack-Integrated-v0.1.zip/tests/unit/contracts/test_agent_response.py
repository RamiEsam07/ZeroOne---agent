
import unittest
from dataclasses import FrozenInstanceError
from datetime import datetime, timedelta, timezone

from agent.contracts.agent_response import (
    AgentResponse,
    AgentResponseStatus,
)


class TestAgentResponse(unittest.TestCase):

    def setUp(self):
        self.responded_at = datetime.now(timezone.utc)

        self.base_data = {
            "response_id": "RESP-001",
            "request_id": "REQ-001",
            "execution_id": "EXEC-001",
            "trace_id": "TRACE-001",
            "agent_id": "AGENT-001",
            "agent_version": "0.8.0",
            "status": AgentResponseStatus.COMPLETED,
            "responded_at": self.responded_at,
            "finished_at": self.responded_at - timedelta(seconds=1),
            "message": "Operation completed successfully.",
        }

    def create_response(self, **overrides):
        values = self.base_data.copy()
        values.update(overrides)
        return AgentResponse(**values)

    def test_valid_completed_response(self):
        response = self.create_response()

        self.assertEqual(
            response.status,
            AgentResponseStatus.COMPLETED
        )

        self.assertIsNotNone(response.finished_at)

    def test_valid_approval_required_response(self):
        response = self.create_response(
            status=AgentResponseStatus.APPROVAL_REQUIRED,
            approval_id="APPROVAL-001",
        )

        self.assertEqual(
            response.approval_id,
            "APPROVAL-001"
        )

        self.assertIsNotNone(response.finished_at)

    def test_approval_required_requires_finished_at(self):
        with self.assertRaises(TypeError):
            self.create_response(
                status=AgentResponseStatus.APPROVAL_REQUIRED,
                finished_at=None,
                approval_id="APPROVAL-001",
            )

    def test_approval_required_requires_approval_id(self):
        with self.assertRaises(ValueError):
            self.create_response(
                status=AgentResponseStatus.APPROVAL_REQUIRED
            )

    def test_approval_id_rejected_for_completed_response(self):
        with self.assertRaises(ValueError):
            self.create_response(
                approval_id="APPROVAL-001"
            )

    def test_failed_response_requires_error(self):
        with self.assertRaises(ValueError):
            self.create_response(
                status=AgentResponseStatus.FAILED
            )

    def test_failed_response_with_error_is_valid(self):
        response = self.create_response(
            status=AgentResponseStatus.FAILED,
            error={
                "code": "EXECUTION_ERROR",
                "message": "Execution failed.",
            }
        )

        self.assertEqual(
            response.status,
            AgentResponseStatus.FAILED
        )

        self.assertIsNotNone(response.error)

    def test_non_failed_response_rejects_error(self):
        with self.assertRaises(ValueError):
            self.create_response(
                error={
                    "code": "ERROR",
                    "message": "Unexpected error.",
                }
            )

    def test_invalid_status_is_rejected(self):
        with self.assertRaises((TypeError, ValueError)):
            self.create_response(
                status="invalid_status"
            )

    def test_empty_identity_field_is_rejected(self):
        for field_name in ("request_id", "agent_id"):
            with self.subTest(field=field_name):
                with self.assertRaises(ValueError):
                    self.create_response(
                        **{field_name: ""}
                    )

    def test_empty_message_is_rejected(self):
        with self.assertRaises(ValueError):
            self.create_response(
                message=""
            )

    def test_invalid_data_type_is_rejected(self):
        with self.assertRaises(TypeError):
            self.create_response(
                data=["invalid"]
            )

    def test_invalid_error_type_is_rejected(self):
        with self.assertRaises(TypeError):
            self.create_response(
                status=AgentResponseStatus.FAILED,
                error="invalid error"
            )

    def test_invalid_reason_code_is_rejected(self):
        with self.assertRaises((TypeError, ValueError)):
            self.create_response(
                reason_code=""
            )

    def test_final_response_requires_finished_at(self):
        with self.assertRaises(TypeError):
            self.create_response(
                finished_at=None
            )

    def test_finished_at_cannot_be_after_responded_at(self):
        with self.assertRaises(ValueError):
            self.create_response(
                finished_at=self.responded_at + timedelta(seconds=1)
            )

    def test_naive_finished_at_is_rejected(self):
        with self.assertRaises(ValueError):
            self.create_response(
                finished_at=datetime.now()
            )

    def test_naive_responded_at_is_rejected(self):
        with self.assertRaises(ValueError):
            self.create_response(
                responded_at=datetime.now()
            )

    def test_immutable_response(self):
        response = self.create_response()

        with self.assertRaises(FrozenInstanceError):
            response.message = "Changed message."

    def test_nested_data_is_immutable(self):
        response = self.create_response(
            data={
                "project": {
                    "name": "ZEROONE"
                }
            }
        )

        with self.assertRaises(TypeError):
            response.data["project"]["name"] = "CHANGED"

    def test_data_is_defensively_copied(self):
        original_data = {
            "project": {
                "name": "ZEROONE"
            }
        }

        response = self.create_response(
            data=original_data
        )

        original_data["project"]["name"] = "CHANGED"

        self.assertEqual(
            response.data["project"]["name"],
            "ZEROONE"
        )

    def test_nested_error_is_immutable(self):
        response = self.create_response(
            status=AgentResponseStatus.FAILED,
            error={
                "details": {
                    "code": "ERROR"
                }
            }
        )

        self.assertIsNotNone(response.error)

        with self.assertRaises(TypeError):
            response.error["details"]["code"] = "CHANGED"

    def test_error_is_defensively_copied(self):
        original_error = {
            "details": {
                "code": "ERROR"
            }
        }

        response = self.create_response(
            status=AgentResponseStatus.FAILED,
            error=original_error
        )

        original_error["details"]["code"] = "CHANGED"

        self.assertIsNotNone(response.error)

        self.assertEqual(
            response.error["details"]["code"],
            "ERROR"
        )


if __name__ == "__main__":
    unittest.main()
