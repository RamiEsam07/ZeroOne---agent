
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker

from zeroone_agent.platform.persistence.database import Base
from zeroone_agent.platform.persistence.repository import PlatformRepository
from zeroone_agent.platform.service import create_platform_app


@pytest.fixture
def client(tmp_path, monkeypatch):
    database_path = tmp_path / "service-test.db"

    test_engine = create_engine(
        f"sqlite:///{database_path}",
        connect_args={"check_same_thread": False},
    )

    Base.metadata.create_all(bind=test_engine)

    session_factory = sessionmaker(
        bind=test_engine,
        autoflush=False,
        expire_on_commit=False,
    )

    repository = PlatformRepository(session_factory)

    monkeypatch.setenv(
        "ZEROONE_PLATFORM_ADMIN_KEY",
        "test-platform-admin-key-1234567890",
    )

    app = create_platform_app(repository)

    with TestClient(app) as test_client:
        yield test_client

    test_engine.dispose()


def admin_headers():
    return {
        "X-Platform-Admin-Key": "test-platform-admin-key-1234567890"
    }


def test_health_endpoint(client):
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["database"] == "connected"


def test_admin_endpoint_rejects_missing_key(client):
    response = client.get("/platform/domains")

    assert response.status_code == 401


def test_create_tenant(client):
    response = client.post(
        "/platform/tenants",
        headers=admin_headers(),
        json={
            "tenant_id": "zeroone_test",
            "display_name": "ZEROONE Test Organization",
        },
    )

    assert response.status_code == 201
    assert response.json()["tenant_id"] == "zeroone_test"


def test_register_and_list_domain(client):
    response = client.post(
        "/platform/domains",
        headers=admin_headers(),
        json={
            "domain_id": "clinic",
            "display_name": "Clinic Management",
            "package_version": "1.0.0",
            "description": "Clinic domain package",
            "capabilities": ["appointments"],
            "modules": ["appointments"],
            "settings_schema": {},
        },
    )

    assert response.status_code == 201

    response = client.get(
        "/platform/domains",
        headers=admin_headers(),
    )

    assert response.status_code == 200
    assert len(response.json()["domains"]) == 1
    assert response.json()["domains"][0]["domain_id"] == "clinic"


def test_create_and_get_workspace(client):
    headers = admin_headers()

    tenant_response = client.post(
        "/platform/tenants",
        headers=headers,
        json={
            "tenant_id": "clinic_owner",
            "display_name": "Clinic Owner",
        },
    )
    assert tenant_response.status_code == 201

    domain_response = client.post(
        "/platform/domains",
        headers=headers,
        json={
            "domain_id": "clinic",
            "display_name": "Clinic Management",
            "package_version": "1.0.0",
            "description": "Clinic domain package",
            "capabilities": ["appointments"],
            "modules": ["appointments"],
            "settings_schema": {},
        },
    )
    assert domain_response.status_code == 201

    workspace_response = client.post(
        "/platform/workspaces",
        headers=headers,
        json={
            "tenant_id": "clinic_owner",
            "workspace_id": "main",
            "domain_id": "clinic",
            "display_name": "Main Clinic",
            "enabled_modules": ["appointments"],
            "settings": {},
        },
    )

    assert workspace_response.status_code == 201

    response = client.get(
        "/platform/tenants/clinic_owner/workspaces/main",
        headers=headers,
    )

    assert response.status_code == 200
    assert response.json()["workspace_id"] == "main"
    assert response.json()["tenant_id"] == "clinic_owner"


def test_workspace_cannot_enable_unknown_module(client):
    headers = admin_headers()

    client.post(
        "/platform/tenants",
        headers=headers,
        json={
            "tenant_id": "clinic_owner",
            "display_name": "Clinic Owner",
        },
    )

    client.post(
        "/platform/domains",
        headers=headers,
        json={
            "domain_id": "clinic",
            "display_name": "Clinic Management",
            "package_version": "1.0.0",
            "description": "Clinic domain package",
            "capabilities": [],
            "modules": ["appointments"],
            "settings_schema": {},
        },
    )

    response = client.post(
        "/platform/workspaces",
        headers=headers,
        json={
            "tenant_id": "clinic_owner",
            "workspace_id": "main",
            "domain_id": "clinic",
            "display_name": "Main Clinic",
            "enabled_modules": ["payroll"],
            "settings": {},
        },
    )

    assert response.status_code == 422


def test_audit_endpoint(client):
    headers = admin_headers()

    client.post(
        "/platform/tenants",
        headers=headers,
        json={
            "tenant_id": "audit_test",
            "display_name": "Audit Test",
        },
    )

    response = client.get(
        "/platform/audit?tenant_id=audit_test",
        headers=headers,
    )

    assert response.status_code == 200
    assert len(response.json()["events"]) >= 1
def test_workspace_isolation_between_tenants(client):
    headers = admin_headers()

    # Create two independent tenants.
    for tenant_id, display_name in [
        ("tenant_alpha", "Tenant Alpha"),
        ("tenant_beta", "Tenant Beta"),
    ]:
        response = client.post(
            "/platform/tenants",
            headers=headers,
            json={
                "tenant_id": tenant_id,
                "display_name": display_name,
            },
        )
        assert response.status_code == 201

    # Register the clinic domain.
    domain_response = client.post(
        "/platform/domains",
        headers=headers,
        json={
            "domain_id": "clinic",
            "display_name": "Clinic Management",
            "package_version": "1.0.0",
            "description": "Clinic domain package",
            "capabilities": ["appointments"],
            "modules": ["appointments"],
            "settings_schema": {},
        },
    )
    assert domain_response.status_code == 201

    # Create a workspace for Tenant Alpha.
    workspace_response = client.post(
        "/platform/workspaces",
        headers=headers,
        json={
            "tenant_id": "tenant_alpha",
            "workspace_id": "main",
            "domain_id": "clinic",
            "display_name": "Alpha Main Workspace",
            "enabled_modules": ["appointments"],
            "settings": {},
        },
    )
    assert workspace_response.status_code == 201

    # Tenant Alpha can retrieve its own workspace.
    own_response = client.get(
        "/platform/tenants/tenant_alpha/workspaces/main",
        headers=headers,
    )
    assert own_response.status_code == 200

    # Tenant Beta cannot retrieve Alpha's workspace.
    cross_tenant_response = client.get(
        "/platform/tenants/tenant_beta/workspaces/main",
        headers=headers,
    )
    assert cross_tenant_response.status_code == 404