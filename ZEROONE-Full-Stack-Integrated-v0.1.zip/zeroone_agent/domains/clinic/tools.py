"""أدوات مجال العيادات: عرض المواعيد، وما سيُضاف لاحقًا (تسجيل مريض، إلغاء موعد، إلخ)."""

import json
from pathlib import Path

from zeroone_agent.contracts.models import ToolDefinition

DATA_FILE = Path(__file__).resolve().parents[3] / "data" / "appointments.json"


def _load_appointments() -> list[dict]:
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []

    return data.get("appointments", [])


def view_appointments(args: dict, context) -> dict:
    """يرجع كل المواعيد المطابقة للتاريخ المطلوب."""
    target_date = args["date"]
    appointments = _load_appointments()

    matching = [
        appointment
        for appointment in appointments
        if appointment.get("date") == target_date
    ]

    return {
        "date": target_date,
        "total": len(matching),
        "appointments": matching,
    }


def register_clinic_tools(registry) -> None:
    """يسجل كل أدوات مجال العيادة في سجل الأدوات المُعطى."""

    view_appointments_definition = ToolDefinition(
        tool_id="clinic.view_appointments",
        name="view_appointments",
        version="1.0.0",
        description="عرض مواعيد العيادة في تاريخ محدد",
        domain="clinic",
        input_schema={
            "type": "object",
            "properties": {
                "date": {"type": "string", "format": "date"},
            },
            "required": ["date"],
            "additionalProperties": False,
        },
        output_schema={
            "type": "object",
            "properties": {
                "date": {"type": "string"},
                "total": {"type": "integer"},
                "appointments": {
                    "type": "array",
                    "items": {"type": "object"},
                },
            },
            "required": ["date", "total", "appointments"],
            "additionalProperties": False,
        },
        required_capabilities=("clinic.appointments.read",),
    )

    registry.register(view_appointments_definition, view_appointments)
