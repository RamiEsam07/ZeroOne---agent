﻿from dataclasses import dataclass
from typing import Any, Mapping

from jsonschema import Draft202012Validator

from .value_objects import freeze_json_value


@dataclass(frozen=True, slots=True)
class ToolDefinition:
    """
    Immutable definition of a tool available to an agent.

    Describes the tool contract without containing
    its executable implementation or granting permissions.
    """

    tool_id: str
    name: str
    version: str
    description: str
    domain: str

    input_schema: Mapping[str, Any]
    output_schema: Mapping[str, Any]

    required_capabilities: tuple[str, ...] = ()

    def __post_init__(self):
        required_fields = (
            "tool_id",
            "name",
            "version",
            "description",
            "domain",
        )

        for field_name in required_fields:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        self._validate_schema("input_schema", self.input_schema)
        self._validate_schema("output_schema", self.output_schema)

        if not isinstance(self.required_capabilities, (tuple, list)):
            raise TypeError(
                "required_capabilities must be a tuple or list."
            )

        capabilities = tuple(self.required_capabilities)

        for capability in capabilities:
            if not isinstance(capability, str) or not capability.strip():
                raise ValueError(
                    "Each capability must be a non-empty string."
                )

        if len(capabilities) != len(set(capabilities)):
            raise ValueError(
                "required_capabilities must not contain duplicates."
            )

        object.__setattr__(
            self,
            "input_schema",
            freeze_json_value(self.input_schema),
        )

        object.__setattr__(
            self,
            "output_schema",
            freeze_json_value(self.output_schema),
        )

        object.__setattr__(
            self,
            "required_capabilities",
            capabilities,
        )

    @staticmethod
    def _validate_schema(field_name, schema):
        if not isinstance(schema, Mapping):
            raise TypeError(
                f"{field_name} must be a mapping."
            )

        Draft202012Validator.check_schema(dict(schema))
