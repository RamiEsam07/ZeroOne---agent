"""
سياسة الصلاحيات الخاصة بمجال العيادات.

هذه الطبقة تربط بين "الدور الوظيفي" (receptionist, doctor, clinic_manager)
والصلاحيات الفعلية (capabilities) التي يحتاجها تنفيذ كل أداة.
PermissionEngine في security/policy.py يتحقق من الصلاحيات نفسها،
وهذا الملف فقط يحدد أي الأدوار تملك أي الصلاحيات.
"""

# كل دور ← مجموعة الصلاحيات (capabilities) الممنوحة له
CLINIC_ROLE_CAPABILITIES: dict[str, set[str]] = {
    "receptionist": {
        "clinic.appointments.read",
        "clinic.appointments.write",
        "clinic.patients.register",
    },
    "doctor": {
        "clinic.appointments.read",
        "clinic.patients.records.read",
        "clinic.patients.records.update",
    },
    "clinic_manager": {
        "clinic.appointments.read",
        "clinic.appointments.write",
        "clinic.patients.register",
        "clinic.patients.records.read",
        "clinic.patients.records.update",
        "clinic.reports.revenue",
        "clinic.reports.read",
    },
}

# إجراءات تتطلب اعتماد بشري موثق حتى لو كان الدور يملك الصلاحية الأساسية
CLINIC_APPROVAL_REQUIRED_ACTIONS: set[str] = {
    "clinic.patients.records.delete",
    "clinic.billing.modify",
    "clinic.billing.refund",
}

# إجراءات لا يمكن للوكيل تنفيذها إطلاقًا — إنسان مخوّل فقط
CLINIC_HUMAN_ONLY_ACTIONS: set[str] = {
    "clinic.medical_decision.approve",
    "clinic.financial_report.approve_final",
}


def capabilities_for_role(role: str) -> tuple[str, ...]:
    """يرجع الصلاحيات الممنوحة لدور وظيفي معين، فارغة إذا كان الدور غير معروف."""
    return tuple(sorted(CLINIC_ROLE_CAPABILITIES.get(role, set())))
