"""
محرك الصلاحيات (Permission Engine) على مستوى الأداة.

يعمل بمنطق "صلاحيات" (capabilities): كل أداة تحدد الصلاحيات المطلوبة لتنفيذها،
وكل سياق تنفيذ يحمل الصلاحيات الممنوحة له. إذا كانت هناك صلاحية ناقصة،
يُرفض التنفيذ المباشر ويُطلب اعتماد بشري بدلاً منه.

لربط هذا بأدوار وظيفية (receptionist, doctor, clinic_manager) استخدم
domain_policies لتحويل كل دور إلى مجموعة من الصلاحيات — راجع
zeroone_agent/domains/clinic/policy.py كمثال.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str


class PermissionEngine:
    """يتحقق مما إذا كان سياق التنفيذ يملك الصلاحيات التي تتطلبها أداة معينة."""

    def authorize(self, context, tool_definition) -> PolicyDecision:
        missing = set(tool_definition.required_capabilities) - set(
            context.capabilities
        )

        if missing:
            return PolicyDecision(
                allowed=False,
                reason="صلاحيات ناقصة: " + ", ".join(sorted(missing)),
            )

        return PolicyDecision(allowed=True, reason="مصرّح به.")
