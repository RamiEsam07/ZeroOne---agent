# تشغيل ZEROONE Full-Stack محلياً

## ما الذي يعمل في هذه الحزمة؟

- واجهة ZEROONE العربية RTL على `/`، مقدمة من نفس FastAPI origin.
- تسجيل دخول حسابات العيادة التجريبية.
- عرض المواعيد عبر محرك ZEROONE الحالي.
- حجز وإلغاء المواعيد.
- تسجيل المرضى وعرض القائمة.
- تقرير مواعيد للمدير.
- محادثة الوكيل وطلبات الاعتماد الحالية.
- نقطة تحكم المنصة اختيارية تحت `/control-plane` عند تفعيل `ZEROONE_ENABLE_CONTROL_PLANE=1`.

## التشغيل على Windows

من PowerShell داخل مجلد المشروع:

```powershell
.\scripts\run-fullstack.ps1
```

ثم افتح `http://127.0.0.1:8000`.

حسابات التطوير:
- receptionist / reception123
- doctor / doctor123
- manager / manager123

## واجهات API

- `POST /auth/login`
- `POST /auth/logout`
- `GET /appointments?date=YYYY-MM-DD`
- `POST /actions/book-appointment`
- `POST /actions/cancel-appointment`
- `GET /patients`
- `POST /actions/register-patient`
- `POST /actions/revenue-report`
- `POST /agent/chat`
- `GET /approvals/pending`
- `POST /approvals/{approval_id}/decide`
- `GET /docs`

## حدود هذه النسخة قبل الإنتاج

هذه حزمة تطوير وربط واجهة/API، وليست تصريحاً بالنشر الإنتاجي. تسجيل الدخول الحالي تجريبي، والجلسات داخل الذاكرة، وهوية العيادة أحادية المستأجر، وبيانات المرضى والمواعيد في ملفات JSON محلية. لا تضع بيانات مرضى حقيقية ولا تعرضها للإنترنت قبل استبدال هذه الأجزاء بمخزن PostgreSQL متعدد المستأجرين، ومزود هوية حقيقي، وجلسات آمنة، وسياسات وصول على مستوى كل سجل، وترحيلات ونسخ احتياطي ومراقبة واختبارات أمنية.

قاعدة بيانات PostgreSQL في Compose تخدم طبقة Platform Control Plane الحالية. لا يعني ذلك أن ملفات بيانات العيادة JSON أصبحت مخزنة في PostgreSQL.
