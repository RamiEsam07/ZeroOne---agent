$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Test-Path ".\.venv\Scripts\python.exe")) {
    python -m venv .venv
}
.\.venv\Scripts\python.exe -m pip install -e ".[dev,postgres]"
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }

New-Item -ItemType Directory -Force -Path ".\data" | Out-Null
if (-not (Test-Path ".\data\patients.json")) {
    Set-Content -Path ".\data\patients.json" -Value "{`n  `"patients`": []`n}" -Encoding utf8
}

.\.venv\Scripts\python.exe -m uvicorn zeroone_agent.application.app:app --host 127.0.0.1 --port 8000 --reload
