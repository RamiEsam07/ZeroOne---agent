from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import String, DateTime, ForeignKey, JSON, Index, UniqueConstraint, Text
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

def utcnow(): return datetime.now(timezone.utc)

class TenantRow(Base):
    __tablename__ = "platform_tenants"
    tenant_id: Mapped[str] = mapped_column(String(63), primary_key=True)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)

class DomainRow(Base):
    __tablename__ = "platform_domains"
    domain_id: Mapped[str] = mapped_column(String(63), primary_key=True)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    package_version: Mapped[str] = mapped_column(String(40), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    capabilities: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    modules: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    settings_schema: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

class WorkspaceRow(Base):
    __tablename__ = "platform_workspaces"
    __table_args__ = (UniqueConstraint("tenant_id", "workspace_id", name="uq_workspace_tenant_id"), Index("ix_workspace_tenant", "tenant_id"))
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    workspace_id: Mapped[str] = mapped_column(String(63), nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("platform_tenants.tenant_id", ondelete="RESTRICT"), nullable=False)
    domain_id: Mapped[str] = mapped_column(ForeignKey("platform_domains.domain_id", ondelete="RESTRICT"), nullable=False)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    enabled_modules: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    settings: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)

class AuditEventRow(Base):
    __tablename__ = "platform_audit_events"
    __table_args__ = (Index("ix_platform_audit_tenant_created", "tenant_id", "created_at"),)
    event_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(String(63), nullable=True)
    actor_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(80), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(128), nullable=False)
    outcome: Mapped[str] = mapped_column(String(30), nullable=False)
    details: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)
