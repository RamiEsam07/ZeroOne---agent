
import json
from pathlib import Path
from datetime import datetime
from uuid import uuid4


class AgentMemory:
    """
    Persistent memory and knowledge management
    for ZEROONE agents.
    """

    def __init__(self):
        project_root = Path(__file__).resolve().parents[2]

        self.memory_file = (
            project_root / "data" / "agent_long_term_memory.json"
        )

        self.data = self.load_memory()

    def load_memory(self):
        """Load and validate persistent memory."""

        try:
            with open(
                self.memory_file,
                "r",
                encoding="utf-8"
            ) as file:

                data = json.load(file)

            if not isinstance(data, dict):
                raise ValueError("Memory must be a JSON object.")

            required_categories = [
                "preferences",
                "business_rules",
                "learned_facts",
                "context"
            ]

            memory = data.get("memory")

            if not isinstance(memory, dict):
                raise ValueError("Invalid memory structure.")

            for category in required_categories:
                if not isinstance(memory.get(category), list):
                    raise ValueError(
                        f"Invalid memory category: {category}"
                    )

            return data

        except FileNotFoundError:
            raise RuntimeError("Memory file was not found.")

        except json.JSONDecodeError as error:
            raise RuntimeError(
                f"Invalid JSON memory file: {error}"
            )

    def save_memory(self):
        """Persist memory to disk."""

        try:
            with open(
                self.memory_file,
                "w",
                encoding="utf-8"
            ) as file:

                json.dump(
                    self.data,
                    file,
                    ensure_ascii=False,
                    indent=4
                )

            return {
                "status": "success",
                "message": "Memory saved successfully."
            }

        except OSError as error:
            return {
                "status": "error",
                "message": str(error)
            }

    def add_memory(self, category, content, source):
        """Add a new memory item awaiting human review."""

        if category not in self.data["memory"]:
            return {
                "status": "error",
                "message": "Invalid memory category."
            }

        if not isinstance(content, str) or not content.strip():
            return {
                "status": "error",
                "message": "Memory content cannot be empty."
            }

        if not isinstance(source, str) or not source.strip():
            return {
                "status": "error",
                "message": "Memory source is required."
            }

        memory_item = {
            "id": str(uuid4()),
            "content": content.strip(),
            "source": source.strip(),
            "created_at": datetime.now().astimezone().isoformat(),
            "status": "pending",
            "reviewed_by": None,
            "reviewed_at": None
        }

        self.data["memory"][category].append(memory_item)

        save_result = self.save_memory()

        if save_result["status"] == "error":
            self.data["memory"][category].remove(memory_item)
            return save_result

        return {
            "status": "success",
            "message": "Memory added and awaits review.",
            "memory": memory_item
        }

    def review_memory(self, memory_id, decision, reviewed_by):
        """
        Approve or reject a pending memory item.

        This prototype records reviewer information,
        but does not authenticate the reviewer's identity.
        """

        if decision not in {"approved", "rejected"}:
            return {
                "status": "error",
                "message": "Decision must be approved or rejected."
            }

        if not isinstance(reviewed_by, str) or not reviewed_by.strip():
            return {
                "status": "error",
                "message": "Reviewer identity is required."
            }

        for category_items in self.data["memory"].values():

            for item in category_items:

                if item["id"] == memory_id:

                    if item.get("status") != "pending":
                        return {
                            "status": "error",
                            "message": "Only pending memories can be reviewed."
                        }

                    previous_status = item["status"]
                    previous_reviewer = item.get("reviewed_by")
                    previous_reviewed_at = item.get("reviewed_at")

                    item["status"] = decision
                    item["reviewed_by"] = reviewed_by.strip()
                    item["reviewed_at"] = (
                        datetime.now().astimezone().isoformat()
                    )

                    save_result = self.save_memory()

                    if save_result["status"] == "error":
                        item["status"] = previous_status
                        item["reviewed_by"] = previous_reviewer
                        item["reviewed_at"] = previous_reviewed_at
                        return save_result

                    return {
                        "status": "success",
                        "message": f"Memory {decision}.",
                        "memory": item
                    }

        return {
            "status": "error",
            "message": "Memory item was not found."
        }

    def get_memories(self, category=None):
        """Retrieve memories for administrative review."""

        if category is not None:

            if category not in self.data["memory"]:
                return {
                    "status": "error",
                    "message": "Invalid memory category."
                }

            return self.data["memory"][category]

        return self.data["memory"]

    def get_approved_memories(self, category=None):
        """Retrieve approved knowledge for agent use."""

        if category is not None:

            if category not in self.data["memory"]:
                return {
                    "status": "error",
                    "message": "Invalid memory category."
                }

            categories = {
                category: self.data["memory"][category]
            }

        else:
            categories = self.data["memory"]

        approved = {}

        for name, items in categories.items():
            approved[name] = [
                item for item in items
                if item.get("status") == "approved"
            ]

        return approved
