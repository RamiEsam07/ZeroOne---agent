
from datetime import datetime
from uuid import uuid4

from .request_analyzer import RequestAnalyzer
from .audit_logger import AuditLogger
from .tool_registry import ToolRegistry

from agent.tools.appointment_tools import AppointmentTools


class AgentCore:
    """
    Reusable intelligent agent core.
    """

    def __init__(self, agent_name, domain, version="0.8.0"):
        self.agent_name = agent_name
        self.domain = domain
        self.version = version
        self.status = "ready"

        self.analyzer = RequestAnalyzer(domain)
        self.permission_engine = None
        self.audit_logger = AuditLogger()

        # Initialize tool registry
        self.tool_registry = ToolRegistry()

        # Register domain-specific tools
        self.register_domain_tools()

    def register_domain_tools(self):
        """Register tools based on agent domain."""

        if self.domain == "clinic":

            appointment_tools = AppointmentTools()

            self.tool_registry.register_tool(
                name="view_appointments",
                tool=appointment_tools.view_appointments,
                description="View clinic appointments by date",
                domain="clinic"
            )

    def receive_request(self, request, user_role, user_id=None):

        if not isinstance(request, str) or not request.strip():
            return {
                "status": "rejected",
                "message": "The request cannot be empty."
            }

        if not user_role:
            return {
                "status": "rejected",
                "message": "The user role is required."
            }

        request_context = self.build_context(
            request=request.strip(),
            user_role=user_role,
            user_id=user_id
        )

        # Step 1: Analyze request
        analysis = self.analyzer.analyze(request)
        request_context["analysis"] = analysis

        if analysis["status"] != "analyzed":
            request_context["status"] = analysis["status"]
            self.record_audit_event(request_context)
            return request_context

        # Step 2: Check permissions
        if self.permission_engine is None:
            request_context["status"] = "configuration_error"
            request_context["message"] = (
                "Permission engine is not configured."
            )

            self.record_audit_event(request_context)
            return request_context

        action = analysis["action"]

        allowed, reason = self.permission_engine.check_permission(
            user_role=user_role,
            action=action
        )

        request_context["authorization"] = {
            "allowed": allowed,
            "reason": reason
        }

        if not allowed:
            request_context["status"] = "denied"
            self.record_audit_event(request_context)
            return request_context

        # Step 3: Execute authorized action
        execution_result = self.execute_action(
            action=action,
            target_date=analysis.get("target_date")
        )

        request_context["execution"] = execution_result

        request_context["status"] = (
            "completed"
            if execution_result.get("status") == "success"
            else "execution_failed"
        )

        # Step 4: Record operation
        self.record_audit_event(request_context)

        return request_context

    def execute_action(self, action, target_date=None):
        """Execute an action through the tool registry."""

        tool_entry = self.tool_registry.get_tool(action)

        if tool_entry is None:
            return {
                "status": "unsupported_action",
                "message": f"No registered tool found for: {action}"
            }

        if tool_entry["domain"] != self.domain:
            return {
                "status": "error",
                "message": "Tool domain does not match agent domain."
            }

        tool = tool_entry["tool"]

        if action == "view_appointments":
            return tool(target_date=target_date)

        return {
            "status": "unsupported_action",
            "message": f"Execution arguments are not configured for: {action}"
        }

    def record_audit_event(self, request_context):
        """
        Record a safe summary of the operation.
        Patient details and original request text are excluded.
        """

        analysis = request_context.get("analysis", {})
        authorization = request_context.get("authorization", {})
        execution = request_context.get("execution", {})

        event = {
            "request_id": request_context["request_id"],
            "timestamp": request_context["received_at"],
            "agent_name": request_context["agent_name"],
            "domain": request_context["domain"],
            "version": request_context["version"],
            "user_role": request_context["user_role"],
            "user_id": request_context["user_id"],
            "action": analysis.get("action"),
            "authorization": authorization.get("allowed"),
            "status": request_context["status"],
            "target_date": analysis.get("target_date"),
            "execution_status": execution.get("status"),
            "result_count": execution.get("total")
        }

        return self.audit_logger.log_event(event)

    def build_context(self, request, user_role, user_id=None):

        return {
            "request_id": str(uuid4()),
            "agent_name": self.agent_name,
            "domain": self.domain,
            "version": self.version,
            "request": request,
            "user_role": user_role,
            "user_id": user_id,
            "received_at": datetime.now().isoformat(),
            "status": "received"
        }
