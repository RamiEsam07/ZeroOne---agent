
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from .value_objects import freeze_json_value


class AgentResponseStatus(str, Enum):
    COMPLETED = "completed"
    REJECTED = "rejected"
    DENIED = "denied"
    APPROVAL_REQUIRED = "approval_required"
    FAILED = "failed"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True, slots=True)
class AgentResponse:
    """
    Immutable, validated response contract for ZEROONE Agent Engine.
    """

    # Response identity
    response_id: str
    request_id: str
    execution_id: str
    trace_id: str

    # Agent identity
    agent_id: str
    agent_version: str

    # Response lifecycle
    status: AgentResponseStatus
    responded_at: datetime
    finished_at: datetime

    # Response content
    message: str
    data: Mapping[str, Any] = field(default_factory=dict)
    error: Mapping[str, Any] | None = None
    reason_code: str | None = None

    # Human approval reference
    approval_id: str | None = None

    def __post_init__(self):

        required_strings = (
            "response_id",
            "request_id",
            "execution_id",
            "trace_id",
            "agent_id",
            "agent_version",
            "message",
        )

        for field_name in required_strings:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        if not isinstance(self.status, AgentResponseStatus):
            raise TypeError(
                "status must be an AgentResponseStatus value."
            )

        if not isinstance(self.responded_at, datetime):
            raise TypeError("responded_at must be a datetime.")

        if (
            self.responded_at.tzinfo is None
            or self.responded_at.utcoffset() is None
        ):
            raise ValueError(
                "responded_at must be timezone-aware."
            )

        if not isinstance(self.finished_at, datetime):
            raise TypeError("finished_at must be a datetime.")

        if (
            self.finished_at.tzinfo is None
            or self.finished_at.utcoffset() is None
        ):
            raise ValueError(
                "finished_at must be timezone-aware."
            )

        if self.finished_at > self.responded_at:
            raise ValueError(
                "finished_at cannot be later than responded_at."
            )

        if not isinstance(self.data, Mapping):
            raise TypeError("data must be a mapping.")

        if (
            self.error is not None
            and not isinstance(self.error, Mapping)
        ):
            raise TypeError("error must be a mapping or None.")

        if self.reason_code is not None:
            if (
                not isinstance(self.reason_code, str)
                or not self.reason_code.strip()
            ):
                raise ValueError(
                    "reason_code must be a non-empty string or None."
                )

        if self.status == AgentResponseStatus.APPROVAL_REQUIRED:
            if (
                not isinstance(self.approval_id, str)
                or not self.approval_id.strip()
            ):
                raise ValueError(
                    "approval_id is required when approval is needed."
                )

        elif self.approval_id is not None:
            raise ValueError(
                "approval_id is only allowed for approval-required responses."
            )

        if (
            self.status == AgentResponseStatus.FAILED
            and self.error is None
        ):
            raise ValueError(
                "A failed response must include error details."
            )

        if (
            self.status != AgentResponseStatus.FAILED
            and self.error is not None
        ):
            raise ValueError(
                "Error details are only allowed for failed responses."
            )

        object.__setattr__(
            self,
            "data",
            freeze_json_value(self.data)
        )

        if self.error is not None:
            object.__setattr__(
                self,
                "error",
                freeze_json_value(self.error)
            )
