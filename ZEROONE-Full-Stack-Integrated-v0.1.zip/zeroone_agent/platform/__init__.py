"""Multi-tenant platform primitives for ZEROONE."""
from .registry import DomainManifest, TenantRecord, WorkspaceRecord, PlatformRegistry

__all__ = ["DomainManifest", "TenantRecord", "WorkspaceRecord", "PlatformRegistry"]
