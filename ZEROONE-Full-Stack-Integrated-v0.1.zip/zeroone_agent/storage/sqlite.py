"""
تخزين دائم للأحداث باستخدام SQLite.

مفيد لحفظ سجل التدقيق بشكل دائم عبر عمليات تشغيل متعددة للخادم،
بدون الحاجة لقاعدة بيانات خارجية كاملة في مراحل التطوير المبكرة.
"""

import json
import sqlite3
from pathlib import Path


class SQLiteEventStore:
    """يخزّن أحداثًا (عادة أحداث تدقيق) في ملف SQLite محلي، مفهرسة حسب الجهة."""

    def __init__(self, path: str | Path = "data/zeroone.db"):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)

        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    event_type TEXT,
                    created_at TEXT,
                    event_json TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS ix_audit_tenant ON audit_events(tenant_id)"
            )

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.execute("PRAGMA journal_mode=WAL")
        return connection

    def append_event(self, event: dict) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO audit_events (tenant_id, event_type, created_at, event_json)"
                " VALUES (?, ?, ?, ?)",
                (
                    event.get("tenant_id"),
                    event.get("event_type"),
                    event.get("at"),
                    json.dumps(event, ensure_ascii=False),
                ),
            )

    def list_events(self, tenant_id: str) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT event_json FROM audit_events WHERE tenant_id = ? ORDER BY id",
                (tenant_id,),
            ).fetchall()

        return [json.loads(row[0]) for row in rows]
