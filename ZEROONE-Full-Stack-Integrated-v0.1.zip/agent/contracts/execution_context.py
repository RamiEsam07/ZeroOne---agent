
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True, slots=True)
class ExecutionContext:
    """
    Immutable, trusted context for one agent execution.
    Created internally by the runtime after authentication.
    """

    # Request and execution identity
    request_id: str
    execution_id: str
    trace_id: str

    # Organization and agent identity
    tenant_id: str
    agent_id: str
    agent_version: str
    domain: str

    # Verified caller identity
    principal_id: str
    authentication_method: str

    # Execution boundaries
    created_at: datetime
    deadline: datetime

    # Localization
    locale: str
    timezone: str

    def __post_init__(self):
        required_fields = (
            "request_id",
            "execution_id",
            "trace_id",
            "tenant_id",
            "agent_id",
            "agent_version",
            "domain",
            "principal_id",
            "authentication_method",
            "locale",
            "timezone",
        )

        for field_name in required_fields:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        if not isinstance(self.created_at, datetime):
            raise TypeError("created_at must be a datetime.")

        if not isinstance(self.deadline, datetime):
            raise TypeError("deadline must be a datetime.")

        if (
            self.created_at.tzinfo is None
            or self.created_at.utcoffset() is None
        ):
            raise ValueError("created_at must be timezone-aware.")

        if (
            self.deadline.tzinfo is None
            or self.deadline.utcoffset() is None
        ):
            raise ValueError("deadline must be timezone-aware.")

        if self.deadline <= self.created_at:
            raise ValueError(
                "deadline must be later than created_at."
            )
