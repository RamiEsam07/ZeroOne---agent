
from __future__ import annotations

import os
from logging.config import fileConfig

from alembic import context

from zeroone_agent.platform.persistence.database import Base, build_engine
from zeroone_agent.platform.persistence import models  # noqa: F401


config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Register all ZEROONE platform models.
target_metadata = Base.metadata


def get_database_url() -> str:
    return os.getenv(
        "ZEROONE_DATABASE_URL",
        "sqlite:///./data/zeroone-platform.db",
    )


def run_migrations_offline() -> None:
    """Generate SQL without opening a database connection."""
    context.configure(
        url=get_database_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations using the configured ZEROONE database."""
    engine = build_engine(get_database_url())

    try:
        with engine.connect() as connection:
            context.configure(
                connection=connection,
                target_metadata=target_metadata,
                compare_type=True,
                compare_server_default=True,
            )

            with context.begin_transaction():
                context.run_migrations()
    finally:
        engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
