
import unittest
from dataclasses import FrozenInstanceError

from jsonschema.exceptions import SchemaError

from agent.contracts.tool_definition import ToolDefinition


class TestToolDefinition(unittest.TestCase):

    def setUp(self):
        self.definition = ToolDefinition(
            tool_id="clinic.view_appointments",
            name="view_appointments",
            version="1.0.0",
            description="View clinic appointments by date",
            domain="clinic",
            input_schema={
                "type": "object",
                "properties": {
                    "target_date": {"type": "string"}
                },
                "required": ["target_date"],
                "additionalProperties": False
            },
            output_schema={
                "type": "object",
                "properties": {
                    "status": {"type": "string"},
                    "total": {"type": "integer"}
                },
                "required": ["status", "total"]
            },
            required_capabilities=("appointments.read",)
        )

    def test_valid_definition(self):
        self.assertEqual(self.definition.tool_id, "clinic.view_appointments")
        self.assertEqual(self.definition.domain, "clinic")

    def test_required_string_cannot_be_empty(self):
        with self.assertRaises(ValueError):
            ToolDefinition(
                tool_id="",
                name="test",
                version="1.0.0",
                description="Test",
                domain="test",
                input_schema={"type": "object"},
                output_schema={"type": "object"}
            )

    def test_schema_must_be_a_mapping(self):
        with self.assertRaises(TypeError):
            ToolDefinition(
                tool_id="tool-001",
                name="test",
                version="1.0.0",
                description="Test",
                domain="test",
                input_schema=[],
                output_schema={"type": "object"}
            )

    def test_invalid_json_schema_is_rejected(self):
        with self.assertRaises(SchemaError):
            ToolDefinition(
                tool_id="tool-001",
                name="test",
                version="1.0.0",
                description="Test",
                domain="test",
                input_schema={"type": "invalid-json-type"},
                output_schema={"type": "object"}
            )

    def test_input_schema_is_immutable(self):
        with self.assertRaises(TypeError):
            self.definition.input_schema["type"] = "string"

    def test_nested_schema_is_immutable(self):
        with self.assertRaises(TypeError):
            self.definition.input_schema["properties"]["target_date"]["type"] = "integer"

    def test_definition_is_immutable(self):
        with self.assertRaises(FrozenInstanceError):
            self.definition.name = "changed_name"

    def test_duplicate_capabilities_are_rejected(self):
        with self.assertRaises(ValueError):
            ToolDefinition(
                tool_id="tool-001",
                name="test",
                version="1.0.0",
                description="Test",
                domain="test",
                input_schema={"type": "object"},
                output_schema={"type": "object"},
                required_capabilities=("data.read", "data.read")
            )

    def test_capabilities_are_stored_as_tuple(self):
        definition = ToolDefinition(
            tool_id="tool-002",
            name="test",
            version="1.0.0",
            description="Test",
            domain="test",
            input_schema={"type": "object"},
            output_schema={"type": "object"},
            required_capabilities=["data.read"]
        )
        self.assertIsInstance(definition.required_capabilities, tuple)


if __name__ == "__main__":
    unittest.main()
