﻿import unittest

from agent.core.tool_registry import ToolRegistry
from agent.contracts.tool_definition import ToolDefinition


def sample_handler(target_date):
    return {"date": target_date}


def create_definition(
    tool_id="clinic.view_appointments",
    domain="clinic"
):
    return ToolDefinition(
        tool_id=tool_id,
        name="view_appointments",
        version="1.0.0",
        description="View appointments.",
        domain=domain,
        input_schema={
            "type": "object",
            "properties": {
                "target_date": {"type": "string"}
            },
            "required": ["target_date"],
            "additionalProperties": False
        },
        output_schema={
            "type": "object",
            "properties": {
                "date": {"type": "string"}
            },
            "required": ["date"],
            "additionalProperties": False
        }
    )


class TestToolRegistry(unittest.TestCase):

    def setUp(self):
        self.registry = ToolRegistry()
        self.definition = create_definition()

    def test_register_valid_tool(self):
        self.registry.register_tool(
            definition=self.definition,
            handler=sample_handler
        )

        entry = self.registry.get_tool(
            "clinic.view_appointments"
        )

        self.assertIsNotNone(entry)
        self.assertIs(entry.definition, self.definition)
        self.assertIs(entry.handler, sample_handler)

    def test_duplicate_tool_registration_is_rejected(self):
        self.registry.register_tool(
            self.definition,
            sample_handler
        )

        with self.assertRaises(ValueError):
            self.registry.register_tool(
                self.definition,
                sample_handler
            )

    def test_non_definition_is_rejected(self):
        with self.assertRaises(TypeError):
            self.registry.register_tool(
                definition={"tool_id": "invalid"},
                handler=sample_handler
            )

    def test_non_callable_handler_is_rejected(self):
        with self.assertRaises(TypeError):
            self.registry.register_tool(
                definition=self.definition,
                handler="not_callable"
            )

    def test_unknown_tool_returns_none(self):
        self.assertIsNone(
            self.registry.get_tool("unknown.tool")
        )

    def test_list_tools_returns_registered_tools(self):
        self.registry.register_tool(
            self.definition,
            sample_handler
        )

        tools = self.registry.list_tools()

        self.assertEqual(len(tools), 1)
        self.assertIn("clinic.view_appointments", tools)

    def test_list_tools_filters_by_domain(self):
        self.registry.register_tool(
            self.definition,
            sample_handler
        )

        store_definition = create_definition(
            tool_id="store.view_inventory",
            domain="store"
        )

        self.registry.register_tool(
            store_definition,
            sample_handler
        )

        clinic_tools = self.registry.list_tools(
            domain="clinic"
        )

        self.assertEqual(
            list(clinic_tools.keys()),
            ["clinic.view_appointments"]
        )

    def test_returned_registry_data_cannot_modify_internal_registry(self):
        self.registry.register_tool(
            self.definition,
            sample_handler
        )

        tools = self.registry.list_tools()

        with self.assertRaises(TypeError):
            tools["another.tool"] = tools["clinic.view_appointments"]

        self.assertIsNotNone(
            self.registry.get_tool(
                "clinic.view_appointments"
            )
        )


if __name__ == "__main__":
    unittest.main()
