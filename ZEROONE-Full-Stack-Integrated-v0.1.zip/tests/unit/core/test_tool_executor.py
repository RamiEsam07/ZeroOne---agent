﻿import unittest

from agent.core.tool_executor import ToolExecutor
from agent.core.tool_registry import RegisteredTool
from agent.contracts.tool_definition import ToolDefinition
from agent.contracts.tool_invocation import ToolInvocation
from agent.contracts.tool_result import ToolResult


def sample_handler(target_date):
    return {"date": target_date}


def failing_handler(target_date):
    raise RuntimeError("Database connection failed.")


def create_registered_tool(
    handler=sample_handler,
    output_schema=None
):
    definition = ToolDefinition(
        tool_id="clinic.view_appointments",
        name="view_appointments",
        version="1.0.0",
        description="View appointments.",
        domain="clinic",
        input_schema={
            "type": "object",
            "properties": {
                "target_date": {
                    "type": "string",
                    "format": "date"
                }
            },
            "required": ["target_date"],
            "additionalProperties": False
        },
        output_schema=output_schema or {
            "type": "object",
            "properties": {
                "date": {
                    "type": "string",
                    "format": "date"
                }
            },
            "required": ["date"],
            "additionalProperties": False
        }
    )

    return RegisteredTool(
        definition=definition,
        handler=handler
    )


def create_invocation(arguments):
    return ToolInvocation(
        invocation_id="INV-001",
        request_id="REQ-001",
        execution_id="EXEC-001",
        tool_id="clinic.view_appointments",
        arguments=arguments
    )


class TestToolExecutor(unittest.TestCase):

    def setUp(self):
        self.executor = ToolExecutor()
        self.registered_tool = create_registered_tool()

    def test_valid_execution_returns_tool_result(self):
        invocation = create_invocation({
            "target_date": "2026-11-08"
        })

        result = self.executor.execute(
            self.registered_tool,
            invocation
        )

        self.assertIsInstance(result, ToolResult)
        self.assertEqual(result.status, "success")
        self.assertEqual(result.invocation_id, "INV-001")
        self.assertEqual(
            result.tool_id,
            "clinic.view_appointments"
        )
        self.assertEqual(
            result.output["date"],
            "2026-11-08"
        )
        self.assertIsNone(result.error)

    def test_invalid_input_is_rejected_before_execution(self):
        invocation = create_invocation({
            "target_date": "not-a-date"
        })

        result = self.executor.execute(
            self.registered_tool,
            invocation
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "INPUT_VALIDATION_FAILED"
        )

    def test_additional_input_fields_are_rejected(self):
        invocation = create_invocation({
            "target_date": "2026-11-08",
            "unexpected": True
        })

        result = self.executor.execute(
            self.registered_tool,
            invocation
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "INPUT_VALIDATION_FAILED"
        )

    def test_invalid_output_is_rejected(self):
        registered_tool = create_registered_tool(
            handler=lambda target_date: {
                "unexpected": "invalid"
            }
        )

        invocation = create_invocation({
            "target_date": "2026-11-08"
        })

        result = self.executor.execute(
            registered_tool,
            invocation
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "OUTPUT_VALIDATION_FAILED"
        )

    def test_handler_exception_returns_safe_error(self):
        registered_tool = create_registered_tool(
            handler=failing_handler
        )

        invocation = create_invocation({
            "target_date": "2026-11-08"
        })

        result = self.executor.execute(
            registered_tool,
            invocation
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "TOOL_EXECUTION_FAILED"
        )

    def test_wrong_tool_invocation_is_rejected(self):
        invocation = ToolInvocation(
            invocation_id="INV-002",
            request_id="REQ-001",
            execution_id="EXEC-001",
            tool_id="store.view_inventory",
            arguments={"target_date": "2026-11-08"}
        )

        result = self.executor.execute(
            self.registered_tool,
            invocation
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "TOOL_MISMATCH"
        )

    def test_invalid_invocation_type_is_rejected(self):
        result = self.executor.execute(
            self.registered_tool,
            {"target_date": "2026-11-08"}
        )

        self.assertEqual(result.status, "error")
        self.assertEqual(
            result.error["code"],
            "INVALID_INVOCATION"
        )


if __name__ == "__main__":
    unittest.main()
