from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Barrier
import sqlite3

import pytest

from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.security.approval_repository import SQLiteApprovalRepository


class Context:
    tenant_id = "tenant-a"
    agent_id = "agent-a"
    principal_id = "requester-a"


def test_approval_recovers_after_service_restart_and_keeps_history():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "approvals.db"
        first = ApprovalService(repository=SQLiteApprovalRepository(db))
        record = first.request(Context(), "clinic.billing.refund", {"amount": 250})

        restarted = ApprovalService(repository=SQLiteApprovalRepository(db))
        recovered = restarted.get(record.approval_id, "tenant-a")
        assert recovered.status == "pending"
        assert recovered.payload == {"amount": 250}

        decided = restarted.decide(
            record.approval_id, "tenant-a", "manager-a", True,
            reason="Reviewed and approved",
        )
        assert decided.status == "approved"

        after_second_restart = ApprovalService(
            repository=SQLiteApprovalRepository(db)
        ).get(record.approval_id, "tenant-a")
        assert after_second_restart.status == "approved"
        assert after_second_restart.decided_by == "manager-a"
        assert after_second_restart.decision_reason == "Reviewed and approved"

        history = SQLiteApprovalRepository(db).list_history(
            record.approval_id, "tenant-a"
        )
        assert [event["to_status"] for event in history] == ["pending", "approved"]


def test_approval_repository_enforces_tenant_scope():
    with TemporaryDirectory() as temp:
        service = ApprovalService(
            repository=SQLiteApprovalRepository(Path(temp) / "approvals.db")
        )
        record = service.request(Context(), "clinic.action", {})
        with pytest.raises(KeyError):
            service.get(record.approval_id, "tenant-b")
        with pytest.raises(KeyError):
            service.decide(record.approval_id, "tenant-b", "manager-b", True)


def test_expired_approval_is_persisted_and_cannot_be_decided():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "approvals.db"
        repo = SQLiteApprovalRepository(db)
        service = ApprovalService(repository=repo)
        record = service.request(Context(), "clinic.action", {})

        expired_at = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        # sqlite3.Connection context managers commit/rollback but do not close.
        # Explicit closing is required on Windows before TemporaryDirectory cleanup.
        with closing(sqlite3.connect(db)) as con:
            con.execute(
                "UPDATE approval_records SET expires_at = ? WHERE approval_id = ?",
                (expired_at, record.approval_id),
            )
            con.commit()

        assert service.get(record.approval_id, "tenant-a").status == "expired"
        with pytest.raises(ValueError, match="expired"):
            service.decide(record.approval_id, "tenant-a", "manager-a", True)
        history = repo.list_history(record.approval_id, "tenant-a")
        assert history[-1]["to_status"] == "expired"


def test_concurrent_approval_decisions_are_atomic():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "approvals.db"
        initial = ApprovalService(repository=SQLiteApprovalRepository(db))
        record = initial.request(Context(), "clinic.action", {})
        barrier = Barrier(2)

        class SynchronizedRepository:
            def __init__(self):
                self.inner = SQLiteApprovalRepository(db)

            def get(self, approval_id, tenant_id):
                data = self.inner.get(approval_id, tenant_id)
                barrier.wait(timeout=10)
                return data

            def __getattr__(self, name):
                return getattr(self.inner, name)

        service_a = ApprovalService(repository=SynchronizedRepository())
        service_b = ApprovalService(repository=SynchronizedRepository())

        def decide(service, manager, approved):
            try:
                result = service.decide(
                    record.approval_id, "tenant-a", manager, approved
                )
                return ("success", result.status)
            except ValueError as exc:
                return ("rejected", str(exc))

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(
                lambda args: decide(*args),
                [(service_a, "manager-a", True), (service_b, "manager-b", False)],
            ))

        assert sum(result[0] == "success" for result in results) == 1
        assert sum(result[0] == "rejected" for result in results) == 1
        final = SQLiteApprovalRepository(db).get(record.approval_id, "tenant-a")
        assert final["status"] in {"approved", "rejected"}
        history = SQLiteApprovalRepository(db).list_history(
            record.approval_id, "tenant-a"
        )
        assert len(history) == 2


def test_requester_cannot_approve_own_request():
    service = ApprovalService()
    record = service.request(Context(), "clinic.sensitive.change", {})

    with pytest.raises(PermissionError, match="Self-approval"):
        service.decide(record.approval_id, "tenant-a", "requester-a", True)

    # A requester may still reject/cancel their own pending request.
    rejected = service.decide(record.approval_id, "tenant-a", "requester-a", False)
    assert rejected.status == "rejected"


def test_expiry_is_checked_atomically_during_decision_transition():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "approvals.db"
        inner = SQLiteApprovalRepository(db)
        initial = ApprovalService(repository=inner)
        record = initial.request(Context(), "clinic.sensitive.change", {})

        class ExpiryRaceRepository:
            """Return a fresh pending read, then expire it before the CAS write."""
            def __init__(self):
                self.did_race = False

            def get(self, approval_id, tenant_id):
                data = inner.get(approval_id, tenant_id)
                if not self.did_race and data is not None:
                    self.did_race = True
                    expired_at = (
                        datetime.now(timezone.utc) - timedelta(seconds=1)
                    ).isoformat()
                    with closing(sqlite3.connect(db)) as con:
                        con.execute(
                            "UPDATE approval_records SET expires_at = ? WHERE approval_id = ?",
                            (expired_at, approval_id),
                        )
                        con.commit()
                return data

            def __getattr__(self, name):
                return getattr(inner, name)

        racing_service = ApprovalService(repository=ExpiryRaceRepository())
        with pytest.raises(ValueError, match="expired"):
            racing_service.decide(
                record.approval_id, "tenant-a", "manager-a", True
            )

        final = inner.get(record.approval_id, "tenant-a")
        assert final["status"] == "expired"
        history = inner.list_history(record.approval_id, "tenant-a")
        assert history[-1]["to_status"] == "expired"
        assert all(event["to_status"] != "approved" for event in history)
