from datetime import date, datetime, timezone
import json
from pathlib import Path
from threading import RLock
from secrets import token_urlsafe
from uuid import uuid4

from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from zeroone_agent.application.factory import create_clinic_runtime
from zeroone_agent.contracts.models import AgentRequest, ExecutionContext
from zeroone_agent.domains.clinic.policy import capabilities_for_role
import os


app = FastAPI(
    title="ZEROONE Clinic API",
    description="API layer for the ZEROONE reusable agent engine",
    version="0.3.1",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

bearer_scheme = HTTPBearer(auto_error=False)
runtime = create_clinic_runtime()

# Development workspace data store. Replace with tenant-scoped SQL repositories
# before production deployment; all API access remains behind authenticated routes.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
APPOINTMENTS_FILE = DATA_DIR / "appointments.json"
PATIENTS_FILE = DATA_DIR / "patients.json"
_DATA_LOCK = RLock()


def _read_json(path: Path, key: str) -> list[dict]:
    with _DATA_LOCK:
        if not path.exists():
            return []
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            values = payload.get(key, [])
            return values if isinstance(values, list) else []
        except (json.JSONDecodeError, OSError):
            raise HTTPException(status_code=500, detail="تعذر قراءة بيانات النظام")


def _write_json(path: Path, key: str, values: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with _DATA_LOCK:
        temporary.write_text(
            json.dumps({key: values}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(path)


def _require_role(user: dict, *roles: str) -> None:
    if user.get("role") not in roles:
        raise HTTPException(status_code=403, detail="ليس لديك صلاحية لتنفيذ هذا الإجراء")

# DEMO ONLY: replace this in production with real identity management.
DEMO_USERS = {
    "receptionist": {
        "password": "reception123",
        "role": "receptionist",
        "display_name": "موظف الاستقبال",
    },
    "doctor": {
        "password": "doctor123",
        "role": "doctor",
        "display_name": "الطبيب",
    },
    "manager": {
        "password": "manager123",
        "role": "clinic_manager",
        "display_name": "مدير العيادة",
    },
}

# In-memory demo sessions. They are lost when the API restarts.
sessions = {}

TENANT_ID = "clinic-demo"
AGENT_ID = "zeroone-clinic-agent"
AGENT_VERSION = "0.3.1"


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    extra_context: dict = Field(default_factory=dict)


class ApprovalDecisionRequest(BaseModel):
    approved: bool
    reason: str | None = Field(default=None, max_length=1000)


class AppointmentInput(BaseModel):
    patient_name: str = Field(min_length=2, max_length=160)
    doctor: str = Field(min_length=2, max_length=120)
    date: date
    time: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")


class CancelAppointmentInput(BaseModel):
    appointment_id: str = Field(min_length=1, max_length=80)


class PatientInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    phone: str = Field(min_length=5, max_length=40)
    age: int | None = Field(default=None, ge=0, le=120)
    notes: str = Field(default="", max_length=2000)


class RevenueReportInput(BaseModel):
    date_from: date
    date_to: date


def current_user(credentials: HTTPAuthorizationCredentials | None):
    if credentials is None:
        raise HTTPException(status_code=401, detail="Authentication required")

    token = credentials.credentials
    user = sessions.get(token)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid or expired demo session")

    return user


def build_context(user: dict, request_id: str) -> ExecutionContext:
    return ExecutionContext(
        request_id=request_id,
        execution_id="EXE-" + uuid4().hex,
        trace_id="TRC-" + uuid4().hex,
        tenant_id=TENANT_ID,
        agent_id=AGENT_ID,
        agent_version=AGENT_VERSION,
        domain="clinic",
        principal_id=user["username"],
        capabilities=capabilities_for_role(user["role"]),
        locale="ar",
        timezone_name="Africa/Khartoum",
    )


def run_agent(message: str, user: dict, extra_context: dict | None = None):
    request_id = "REQ-" + uuid4().hex
    context_data = dict(extra_context or {})

    request = AgentRequest(
        request_id=request_id,
        agent_id=AGENT_ID,
        message=message,
        context=context_data,
    )
    context = build_context(user, request_id)

    return runtime.handle(request, context)


def response_payload(response):
    return {
        "request_id": response.request_id,
        "status": response.status.value,
        "message": response.message,
        "data": dict(response.data),
        "error": dict(response.error) if response.error else None,
        "approval_id": response.approval_id,
    }


@app.get("/health", tags=["System"])
def health_check():
    return {
        "status": "ok",
        "service": "zeroone-clinic-api",
        "version": "0.3.1",
    }


@app.post("/auth/login", tags=["Authentication"])
def login(payload: LoginRequest):
    user_record = DEMO_USERS.get(payload.username)

    if user_record is None or payload.password != user_record["password"]:
        raise HTTPException(status_code=401, detail="اسم المستخدم أو كلمة المرور غير صحيحة")

    token = token_urlsafe(32)
    user = {
        "username": payload.username,
        "role": user_record["role"],
        "display_name": user_record["display_name"],
    }
    sessions[token] = user

    return {
        "token": token,
        "username": user["username"],
        "role": user["role"],
        "display_name": user["display_name"],
        "demo_only": True,
    }


@app.get("/appointments", tags=["Clinic"])
def get_appointments(
    target_date: date = Query(alias='date'),
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)

    response = run_agent(
        "اعرض مواعيد العيادة",
        user,
        {"date": target_date.isoformat()},
    )
    payload = response_payload(response)

    if response.status.value != "completed":
        raise HTTPException(
            status_code=403 if response.status.value == "denied" else 400,
            detail=response.message,
        )

    return {
        "appointments": payload["data"].get("appointments", []),
        "date": target_date.isoformat(),
        "total": payload["data"].get("total", 0),
    }


@app.post("/agent/chat", tags=["Agent"])
def agent_chat(
    payload: ChatRequest,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)
    response = run_agent(payload.message, user, payload.extra_context)
    return response_payload(response)


@app.get("/", include_in_schema=False)
def frontend():
    index_file = PROJECT_ROOT / "frontend" / "index.html"
    return FileResponse(index_file)


@app.post("/auth/logout", tags=["Authentication"])
def logout(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    user = current_user(credentials)
    sessions.pop(credentials.credentials, None)
    return {"status": "logged_out"}


@app.post("/actions/book-appointment", tags=["Clinic"])
def book_appointment(
    payload: AppointmentInput,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)
    _require_role(user, "receptionist", "clinic_manager")
    appointments = _read_json(APPOINTMENTS_FILE, "appointments")
    if any(
        item.get("doctor") == payload.doctor
        and item.get("date") == payload.date.isoformat()
        and item.get("time") == payload.time
        and item.get("status") != "cancelled"
        for item in appointments
    ):
        raise HTTPException(status_code=409, detail="هذا الموعد محجوز بالفعل")
    record = {
        "id": "APT-" + uuid4().hex[:12].upper(),
        "patient_name": payload.patient_name.strip(),
        "doctor": payload.doctor.strip(),
        "date": payload.date.isoformat(),
        "time": payload.time,
        "status": "confirmed",
    }
    appointments.append(record)
    _write_json(APPOINTMENTS_FILE, "appointments", appointments)
    return {"status": "completed", "data": record, "message": "تم حجز الموعد"}


@app.post("/actions/cancel-appointment", tags=["Clinic"])
def cancel_appointment(
    payload: CancelAppointmentInput,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)
    _require_role(user, "receptionist", "clinic_manager")
    appointments = _read_json(APPOINTMENTS_FILE, "appointments")
    record = next((item for item in appointments if item.get("id") == payload.appointment_id), None)
    if record is None:
        raise HTTPException(status_code=404, detail="الموعد غير موجود")
    if record.get("status") == "cancelled":
        raise HTTPException(status_code=409, detail="الموعد ملغى مسبقاً")
    record["status"] = "cancelled"
    _write_json(APPOINTMENTS_FILE, "appointments", appointments)
    return {"status": "completed", "data": record, "message": "تم إلغاء الموعد"}


@app.get("/patients", tags=["Clinic"])
def get_patients(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    user = current_user(credentials)
    _require_role(user, "receptionist", "doctor", "clinic_manager")
    return {"patients": _read_json(PATIENTS_FILE, "patients")}


@app.post("/actions/register-patient", tags=["Clinic"])
def register_patient(
    payload: PatientInput,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)
    _require_role(user, "receptionist", "clinic_manager")
    patients = _read_json(PATIENTS_FILE, "patients")
    if any(item.get("phone") == payload.phone.strip() for item in patients):
        raise HTTPException(status_code=409, detail="رقم الهاتف مسجل لمريض آخر")
    record = {
        "id": "PAT-" + uuid4().hex[:12].upper(),
        "name": payload.name.strip(),
        "phone": payload.phone.strip(),
        "age": payload.age,
        "notes": payload.notes.strip(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    patients.append(record)
    _write_json(PATIENTS_FILE, "patients", patients)
    return {"status": "completed", "data": record, "message": "تم تسجيل المريض"}


@app.post("/actions/revenue-report", tags=["Reports"])
def revenue_report(
    payload: RevenueReportInput,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)
    _require_role(user, "clinic_manager")
    if payload.date_from > payload.date_to:
        raise HTTPException(status_code=422, detail="بداية الفترة يجب أن تسبق نهايتها")
    appointments = [
        item for item in _read_json(APPOINTMENTS_FILE, "appointments")
        if payload.date_from.isoformat() <= item.get("date", "") <= payload.date_to.isoformat()
    ]
    return {
        "status": "completed",
        "data": {
            "total_appointments": len(appointments),
            "confirmed": sum(item.get("status") == "confirmed" for item in appointments),
            "cancelled": sum(item.get("status") == "cancelled" for item in appointments),
            "pending": sum(item.get("status") == "pending" for item in appointments),
            "period": {"from": payload.date_from.isoformat(), "to": payload.date_to.isoformat()},
        },
    }


@app.get("/approvals/pending", tags=["Approvals"])
def pending_approvals(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)

    if user["role"] != "clinic_manager":
        raise HTTPException(status_code=403, detail="Manager role required")

    records = runtime.approvals.list_pending(TENANT_ID)

    return {
        "pending": [
            {
                "approval_id": record.approval_id,
                "action": record.action,
                "principal_id": record.principal_id,
                "created_at": record.created_at,
                "status": record.status,
            }
            for record in records
        ]
    }


@app.post("/approvals/{approval_id}/decide", tags=["Approvals"])
def decide_approval(
    approval_id: str,
    payload: ApprovalDecisionRequest,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
):
    user = current_user(credentials)

    if user["role"] != "clinic_manager":
        raise HTTPException(status_code=403, detail="Manager role required")

    try:
        record = runtime.approvals.decide(
            approval_id=approval_id,
            tenant_id=TENANT_ID,
            decided_by=user["username"],
            approved=payload.approved,
            reason=payload.reason,
        )
    except KeyError:
        raise HTTPException(status_code=404, detail="Approval request not found")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return {
        "approval_id": record.approval_id,
        "status": record.status,
        "decided_by": record.decided_by,
        "decided_at": record.decided_at,
        "reason": record.decision_reason,
        "execution_performed": False,
    }


# Optional platform administration control plane; separate from clinic-user identity.
if os.getenv("ZEROONE_ENABLE_CONTROL_PLANE", "0").lower() in {"1", "true", "yes"}:
    from zeroone_agent.platform.service import create_platform_app
    app.mount("/control-plane", create_platform_app())
