﻿from dataclasses import dataclass, field
from typing import Any, Mapping

from .value_objects import freeze_json_value


@dataclass(frozen=True, slots=True)
class ToolResult:
    """
    Immutable result of a tool execution.
    """

    invocation_id: str
    tool_id: str
    status: str

    output: Mapping[str, Any] = field(default_factory=dict)
    error: Mapping[str, Any] | None = None

    def __post_init__(self):
        required_fields = (
            "invocation_id",
            "tool_id",
        )

        for field_name in required_fields:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        if self.status not in ("success", "error"):
            raise ValueError(
                "status must be either 'success' or 'error'."
            )

        if not isinstance(self.output, Mapping):
            raise TypeError("output must be a mapping.")

        if self.error is not None and not isinstance(self.error, Mapping):
            raise TypeError("error must be a mapping or None.")

        if self.status == "success" and self.error is not None:
            raise ValueError(
                "A successful result must not contain an error."
            )

        if self.status == "error" and not self.error:
            raise ValueError(
                "A failed result must contain error details."
            )

        object.__setattr__(
            self,
            "output",
            freeze_json_value(self.output),
        )

        if self.error is not None:
            object.__setattr__(
                self,
                "error",
                freeze_json_value(self.error),
            )
