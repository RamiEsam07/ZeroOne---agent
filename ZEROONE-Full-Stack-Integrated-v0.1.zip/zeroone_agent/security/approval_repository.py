"""
SQLite-backed approval repository.

Each state transition is committed atomically with its immutable history event.
Tenant scoping is enforced in every read and transition query.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Mapping


class SQLiteApprovalRepository:
    def __init__(self, path: str | Path = "data/zeroone.db"):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 15000")
        return connection

    @contextmanager
    def _connection(self):
        connection = self._connect()
        try:
            yield connection
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connection() as con:
            con.execute("PRAGMA journal_mode = WAL")
            con.executescript("""
                CREATE TABLE IF NOT EXISTS approval_records (
                    approval_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    principal_id TEXT NOT NULL,
                    action TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN
                        ('pending','approved','rejected','expired','revoked')),
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    decided_by TEXT,
                    decided_at TEXT,
                    decision_reason TEXT
                );
                CREATE INDEX IF NOT EXISTS ix_approvals_tenant_status
                    ON approval_records(tenant_id, status, created_at);
                CREATE TABLE IF NOT EXISTS approval_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    approval_id TEXT NOT NULL,
                    tenant_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    from_status TEXT,
                    to_status TEXT NOT NULL,
                    actor_id TEXT,
                    reason TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(approval_id) REFERENCES approval_records(approval_id)
                        ON DELETE RESTRICT
                );
                CREATE INDEX IF NOT EXISTS ix_approval_history_tenant
                    ON approval_history(tenant_id, approval_id, id);
            """)
            columns = {
                row["name"]
                for row in con.execute("PRAGMA table_info(approval_records)").fetchall()
            }
            if "decision_reason" not in columns:
                con.execute("ALTER TABLE approval_records ADD COLUMN decision_reason TEXT")

    @staticmethod
    def _record_dict(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["payload"] = json.loads(result.pop("payload_json"))
        return result

    def create(self, record: Any) -> None:
        payload = json.dumps(
            record.payload, ensure_ascii=False, sort_keys=True, allow_nan=False
        )
        with self._connection() as con:
            con.execute("BEGIN IMMEDIATE")
            try:
                con.execute("""
                    INSERT INTO approval_records
                    (approval_id, tenant_id, agent_id, principal_id, action,
                     payload_json, status, created_at, expires_at,
                     decided_by, decided_at, decision_reason)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record.approval_id, record.tenant_id, record.agent_id,
                    record.principal_id, record.action, payload, record.status,
                    record.created_at, record.expires_at, record.decided_by,
                    record.decided_at, getattr(record, "decision_reason", None),
                ))
                con.execute("""
                    INSERT INTO approval_history
                    (approval_id, tenant_id, event_type, from_status, to_status,
                     actor_id, reason, created_at)
                    VALUES (?, ?, 'requested', NULL, 'pending', ?, NULL, ?)
                """, (
                    record.approval_id, record.tenant_id,
                    record.principal_id, record.created_at,
                ))
                con.commit()
            except Exception:
                con.rollback()
                raise

    def get(self, approval_id: str, tenant_id: str) -> dict | None:
        with self._connection() as con:
            row = con.execute("""
                SELECT * FROM approval_records
                WHERE approval_id = ? AND tenant_id = ?
            """, (approval_id, tenant_id)).fetchone()
        return self._record_dict(row) if row else None

    def list_pending(self, tenant_id: str) -> list[dict]:
        with self._connection() as con:
            rows = con.execute("""
                SELECT * FROM approval_records
                WHERE tenant_id = ? AND status = 'pending'
                ORDER BY created_at, approval_id
            """, (tenant_id,)).fetchall()
        return [self._record_dict(row) for row in rows]

    def transition(
        self,
        approval_id: str,
        tenant_id: str,
        expected_status: str,
        new_status: str,
        *,
        actor_id: str | None = None,
        reason: str | None = None,
        decided_at: str | None = None,
        event_type: str | None = None,
        must_be_unexpired_at: str | None = None,
    ) -> bool:
        """Compare-and-set transition; optionally expire stale approvals atomically."""
        with self._connection() as con:
            con.execute("BEGIN IMMEDIATE")
            try:
                row = con.execute("""
                    SELECT status, expires_at FROM approval_records
                    WHERE approval_id = ? AND tenant_id = ?
                """, (approval_id, tenant_id)).fetchone()
                if row is None or row["status"] != expected_status:
                    con.rollback()
                    return False

                # قرار الموافقة/الرفض لا يفوز إذا انتهت الصلاحية بعد
                # قراءة الخدمة للسجل وقبل انتقال الحالة. يجري الحسم داخل
                # نفس معاملة BEGIN IMMEDIATE لمنع سباق الانتهاء.
                if must_be_unexpired_at is not None:
                    from datetime import datetime
                    expires_at = datetime.fromisoformat(row["expires_at"])
                    decision_time = datetime.fromisoformat(must_be_unexpired_at)
                    if decision_time >= expires_at:
                        expired_reason = "Approval request expired"
                        cursor = con.execute("""
                            UPDATE approval_records
                            SET status = 'expired', decided_by = NULL,
                                decided_at = ?, decision_reason = ?
                            WHERE approval_id = ? AND tenant_id = ? AND status = ?
                        """, (
                            must_be_unexpired_at, expired_reason,
                            approval_id, tenant_id, expected_status,
                        ))
                        if cursor.rowcount == 1:
                            con.execute("""
                                INSERT INTO approval_history
                                (approval_id, tenant_id, event_type, from_status, to_status,
                                 actor_id, reason, created_at)
                                VALUES (?, ?, 'expired', ?, 'expired', NULL, ?, ?)
                            """, (
                                approval_id, tenant_id, expected_status,
                                expired_reason, must_be_unexpired_at,
                            ))
                        con.commit()
                        return False

                cursor = con.execute("""
                    UPDATE approval_records
                    SET status = ?, decided_by = ?, decided_at = ?, decision_reason = ?
                    WHERE approval_id = ? AND tenant_id = ? AND status = ?
                """, (
                    new_status, actor_id, decided_at, reason,
                    approval_id, tenant_id, expected_status,
                ))
                if cursor.rowcount != 1:
                    con.rollback()
                    return False

                con.execute("""
                    INSERT INTO approval_history
                    (approval_id, tenant_id, event_type, from_status, to_status,
                     actor_id, reason, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    approval_id, tenant_id, event_type or new_status,
                    expected_status, new_status, actor_id, reason, decided_at,
                ))
                con.commit()
                return True
            except Exception:
                con.rollback()
                raise

    def list_history(self, approval_id: str, tenant_id: str) -> list[dict]:
        with self._connection() as con:
            rows = con.execute("""
                SELECT id, approval_id, tenant_id, event_type, from_status,
                       to_status, actor_id, reason, created_at
                FROM approval_history
                WHERE approval_id = ? AND tenant_id = ?
                ORDER BY id
            """, (approval_id, tenant_id)).fetchall()
        return [dict(row) for row in rows]
