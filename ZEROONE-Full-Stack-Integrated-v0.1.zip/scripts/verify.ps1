$ErrorActionPreference = "Stop"

if (-not (Test-Path ".\.venv\Scripts\python.exe")) {
    Write-Host "Virtual environment not found. Create it first:" -ForegroundColor Yellow
    Write-Host "python -m venv .venv"
    exit 1
}

Write-Host "Compiling Python modules..."
.\.venv\Scripts\python.exe -m compileall -q zeroone_agent

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Running test suite..."
.\.venv\Scripts\python.exe -m pytest -q

exit $LASTEXITCODE
