"""
سجل التدقيق (Audit Log).

يسجل كل حدث مهم يحدث أثناء تنفيذ الوكيل: استلام طلب، رفض صلاحية،
نجاح/فشل تنفيذ أداة، إلخ. هذا السجل هو خط الدفاع الأخير لفهم "ماذا حدث"
عند أي خلاف أو مشكلة — لذلك يُفضّل ألا يُحذف أو يُعدَّل بعد الكتابة.

الوضع الافتراضي: تخزين في الذاكرة (مناسب للتطوير والاختبار).
لتفعيل حفظ دائم على القرص (JSONL)، مرر persist_path عند الإنشاء.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock


class AuditLogger:
    """يسجل أحداث التدقيق في الذاكرة، مع إمكانية حفظ دائم اختياري على القرص."""

    def __init__(self, persist_path: str | Path | None = None):
        self._events: list[dict] = []
        self._lock = RLock()
        self.persist_path = Path(persist_path) if persist_path else None

        if self.persist_path:
            self.persist_path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, context, event_type: str, details: dict) -> dict:
        event = {
            "at": datetime.now(timezone.utc).isoformat(),
            "tenant_id": context.tenant_id,
            "agent_id": context.agent_id,
            "request_id": context.request_id,
            "execution_id": context.execution_id,
            "principal_id": context.principal_id,
            "event_type": event_type,
            "details": dict(details),
        }

        with self._lock:
            self._events.append(event)

            if self.persist_path:
                self._write_to_disk(event)

        return event

    def _write_to_disk(self, event: dict) -> None:
        try:
            with open(self.persist_path, "a", encoding="utf-8") as file:
                file.write(json.dumps(event, ensure_ascii=False) + "\n")
        except OSError:
            # لا نكسر تنفيذ الوكيل بسبب فشل الكتابة على القرص،
            # لكن الحدث يبقى محفوظًا في الذاكرة على الأقل.
            pass

    def list_events(self, tenant_id: str) -> list[dict]:
        with self._lock:
            return [dict(e) for e in self._events if e["tenant_id"] == tenant_id]
