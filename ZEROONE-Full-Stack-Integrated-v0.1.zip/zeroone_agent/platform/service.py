
"""Platform control-plane application factory; never trusts tenant IDs from chat text."""

from __future__ import annotations

import hmac
import os

from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field
from sqlalchemy import text

from .persistence.repository import PlatformRepository


class TenantInput(BaseModel):
    tenant_id: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,62}$")
    display_name: str = Field(min_length=1, max_length=200)


class DomainInput(BaseModel):
    domain_id: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,62}$")
    display_name: str = Field(min_length=1, max_length=200)
    package_version: str = Field(min_length=1, max_length=40)
    description: str = Field(min_length=1, max_length=2000)
    capabilities: list[str] = Field(default_factory=list)
    modules: list[str] = Field(default_factory=list)
    settings_schema: dict = Field(default_factory=dict)


class WorkspaceInput(BaseModel):
    tenant_id: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,62}$")
    workspace_id: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,62}$")
    domain_id: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,62}$")
    display_name: str = Field(min_length=1, max_length=200)
    enabled_modules: list[str] = Field(default_factory=list)
    settings: dict = Field(default_factory=dict)


def create_platform_app(
    repository: PlatformRepository | None = None,
) -> FastAPI:
    repo = repository or PlatformRepository()

    # The application and repository must use the same database.
    db_engine = repo.database_engine

    app = FastAPI(
        title="ZEROONE Platform Control Plane",
        version="0.1.0",
    )

    def require_admin(
        x_platform_admin_key: str | None = Header(default=None),
    ):
        expected = os.getenv("ZEROONE_PLATFORM_ADMIN_KEY", "")

        if len(expected) < 32:
            raise HTTPException(
                status_code=503,
                detail="Platform admin key is not configured securely.",
            )

        if (
            not x_platform_admin_key
            or not hmac.compare_digest(x_platform_admin_key, expected)
        ):
            raise HTTPException(
                status_code=401,
                detail="Platform administrator authentication required.",
            )

    @app.get("/health")
    def health():
        try:
            with db_engine.connect() as connection:
                connection.execute(text("SELECT 1"))

            return {
                "status": "ok",
                "service": "zeroone-platform",
                "database": "connected",
            }

        except Exception:
            raise HTTPException(
                status_code=503,
                detail="Database unavailable.",
            )

    @app.post(
        "/platform/tenants",
        dependencies=[Depends(require_admin)],
        status_code=201,
    )
    def create_tenant(payload: TenantInput):
        try:
            return repo.create_tenant(
                payload.tenant_id,
                payload.display_name,
            )
        except Exception as exc:
            if "unique" in str(exc).lower() or "duplicate" in str(exc).lower():
                raise HTTPException(409, "Tenant already exists.")
            raise

    @app.post(
        "/platform/domains",
        dependencies=[Depends(require_admin)],
        status_code=201,
    )
    def register_domain(payload: DomainInput):
        try:
            return repo.register_domain(**payload.model_dump())
        except Exception as exc:
            if "unique" in str(exc).lower() or "duplicate" in str(exc).lower():
                raise HTTPException(409, "Domain already exists.")
            raise

    @app.get(
        "/platform/domains",
        dependencies=[Depends(require_admin)],
    )
    def list_domains():
        return {"domains": repo.list_domains()}

    @app.post(
        "/platform/workspaces",
        dependencies=[Depends(require_admin)],
        status_code=201,
    )
    def create_workspace(payload: WorkspaceInput):
        try:
            return repo.create_workspace(**payload.model_dump())

        except LookupError as exc:
            raise HTTPException(404, str(exc))

        except PermissionError as exc:
            raise HTTPException(403, str(exc))

        except ValueError as exc:
            raise HTTPException(422, str(exc))

        except Exception as exc:
            if "unique" in str(exc).lower() or "duplicate" in str(exc).lower():
                raise HTTPException(
                    409,
                    "Workspace already exists for this tenant.",
                )
            raise

    @app.get(
        "/platform/tenants/{tenant_id}/workspaces/{workspace_id}",
        dependencies=[Depends(require_admin)],
    )
    def get_workspace(tenant_id: str, workspace_id: str):
        try:
            return repo.get_workspace(
                authenticated_tenant_id=tenant_id,
                workspace_id=workspace_id,
            )
        except LookupError:
            raise HTTPException(404, "Workspace not found.")

    @app.get(
        "/platform/audit",
        dependencies=[Depends(require_admin)],
    )
    def audit(
        tenant_id: str | None = None,
        limit: int = 100,
    ):
        if not 1 <= limit <= 500:
            raise HTTPException(
                422,
                "limit must be between 1 and 500",
            )

        return {
            "events": repo.list_audit_events(
                tenant_id=tenant_id,
                limit=limit,
            )
        }

    return app


app = create_platform_app()
