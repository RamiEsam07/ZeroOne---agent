import pytest

from zeroone_agent.platform import (
    DomainManifest,
    PlatformRegistry,
    TenantRecord,
    WorkspaceRecord,
)


@pytest.fixture
def registry():
    value = PlatformRegistry()
    value.register_domain(DomainManifest(
        domain_id="store", display_name="Store", package_version="1.0.0",
        description="Retail operations", modules=("pos", "inventory", "purchases"),
    ))
    value.register_domain(DomainManifest(
        domain_id="clinic", display_name="Clinic", package_version="1.0.0",
        description="Clinic operations", modules=("appointments", "patients"),
    ))
    value.register_tenant(TenantRecord("tenant_a", "Tenant A"))
    value.register_tenant(TenantRecord("tenant_b", "Tenant B"))
    return value


def test_tenant_can_create_domain_workspace(registry):
    registry.create_workspace(WorkspaceRecord(
        "main", "tenant_a", "store", "Main Store", ("pos", "inventory")
    ))
    workspace = registry.get_workspace(authenticated_tenant_id="tenant_a", workspace_id="main")
    assert workspace.domain_id == "store"
    assert registry.get_domain_for_workspace(authenticated_tenant_id="tenant_a", workspace_id="main").display_name == "Store"


def test_same_workspace_id_is_isolated_by_tenant(registry):
    registry.create_workspace(WorkspaceRecord("main", "tenant_a", "store", "A Store", ("pos",)))
    registry.create_workspace(WorkspaceRecord("main", "tenant_b", "clinic", "B Clinic", ("patients",)))
    assert registry.get_workspace(authenticated_tenant_id="tenant_a", workspace_id="main").domain_id == "store"
    assert registry.get_workspace(authenticated_tenant_id="tenant_b", workspace_id="main").domain_id == "clinic"


def test_cross_tenant_lookup_does_not_disclose_workspace(registry):
    registry.create_workspace(WorkspaceRecord("private", "tenant_a", "store", "Private"))
    with pytest.raises(KeyError, match="Workspace not found"):
        registry.get_workspace(authenticated_tenant_id="tenant_b", workspace_id="private")


def test_unknown_domain_is_rejected(registry):
    with pytest.raises(KeyError, match="Unknown domain"):
        registry.create_workspace(WorkspaceRecord("x", "tenant_a", "school", "School"))


def test_domain_module_mismatch_is_rejected(registry):
    with pytest.raises(ValueError, match="not supported"):
        registry.create_workspace(WorkspaceRecord("x", "tenant_a", "store", "Store", ("patients",)))


def test_duplicate_workspace_within_tenant_is_rejected(registry):
    workspace = WorkspaceRecord("main", "tenant_a", "store", "Store")
    registry.create_workspace(workspace)
    with pytest.raises(ValueError, match="already exists"):
        registry.create_workspace(workspace)


def test_inactive_tenant_cannot_create_workspace(registry):
    registry.register_tenant(TenantRecord("tenant_c", "Suspended", status="suspended"))
    with pytest.raises(PermissionError):
        registry.create_workspace(WorkspaceRecord("x", "tenant_c", "store", "Store"))
