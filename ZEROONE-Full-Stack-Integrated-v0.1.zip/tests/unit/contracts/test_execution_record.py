
from dataclasses import FrozenInstanceError
from datetime import datetime, timezone

import pytest

from zeroone_agent.contracts.models import (
    ExecutionRecord,
    ExecutionStatus,
    calculate_operation_hash,
)


def make_record(**overrides):
    values = {
        "execution_id": "EXE-001",
        "approval_id": "APR-001",
        "tenant_id": "tenant-a",
        "agent_id": "agent-a",
        "domain": "clinic",
        "principal_id": "requester-a",
        "tool_id": "clinic.billing.refund",
        "tool_version": "1.2.0",
        "schema_version": "1.0",
        "arguments": {"patient_id": "P-001", "amount": 250},
        "idempotency_key": "IDEMP-001",
        "status": ExecutionStatus.NOT_STARTED,
        "created_at": datetime.now(timezone.utc),
    }

    values.update(overrides)

    operation_data = {
        key: values[key]
        for key in (
            "approval_id",
            "tenant_id",
            "agent_id",
            "domain",
            "principal_id",
            "tool_id",
            "tool_version",
            "schema_version",
            "arguments",
        )
    }

    values.setdefault(
        "operation_hash",
        calculate_operation_hash(operation_data),
    )

    return ExecutionRecord(**values)


def test_execution_record_valid_creation():
    record = make_record()

    assert record.execution_id == "EXE-001"
    assert record.status == ExecutionStatus.NOT_STARTED
    assert record.tool_version == "1.2.0"
    assert record.schema_version == "1.0"


def test_execution_record_is_immutable():
    record = make_record()

    with pytest.raises(FrozenInstanceError):
        record.status = ExecutionStatus.EXECUTING


def test_execution_record_arguments_are_deeply_immutable():
    record = make_record(
        arguments={"operation": {"amount": 250}}
    )

    with pytest.raises(TypeError):
        record.arguments["operation"]["amount"] = 500


def test_execution_record_defensively_copies_arguments():
    arguments = {"operation": {"amount": 250}}
    record = make_record(arguments=arguments)

    arguments["operation"]["amount"] = 500

    assert record.arguments["operation"]["amount"] == 250


@pytest.mark.parametrize(
    "field",
    [
        "execution_id",
        "approval_id",
        "tenant_id",
        "agent_id",
        "domain",
        "principal_id",
        "tool_id",
        "tool_version",
        "schema_version",
        "idempotency_key",
    ],
)
def test_execution_record_rejects_empty_required_fields(field):
    with pytest.raises(ValueError):
        make_record(**{field: ""})


def test_execution_record_rejects_invalid_status():
    with pytest.raises(TypeError):
        make_record(status="not_started")


def test_execution_record_rejects_naive_created_at():
    with pytest.raises(ValueError):
        make_record(created_at=datetime.now())


def test_execution_record_rejects_invalid_arguments_type():
    with pytest.raises(TypeError):
        make_record(arguments=["invalid"])


def test_execution_record_rejects_non_finite_arguments():
    with pytest.raises(ValueError):
        make_record(arguments={"amount": float("nan")})


def test_operation_hash_is_stable_across_mapping_key_order():
    first = calculate_operation_hash({
        "tenant_id": "tenant-a",
        "agent_id": "agent-a",
        "domain": "clinic",
        "tool_id": "clinic.billing.refund",
        "tool_version": "1.2.0",
        "schema_version": "1.0",
        "arguments": {"amount": 250, "patient_id": "P-001"},
    })

    second = calculate_operation_hash({
        "arguments": {"patient_id": "P-001", "amount": 250},
        "schema_version": "1.0",
        "tool_version": "1.2.0",
        "tool_id": "clinic.billing.refund",
        "domain": "clinic",
        "agent_id": "agent-a",
        "tenant_id": "tenant-a",
    })

    assert first == second


def test_operation_hash_changes_when_operation_changes():
    original = {
        "tenant_id": "tenant-a",
        "agent_id": "agent-a",
        "domain": "clinic",
        "tool_id": "clinic.billing.refund",
        "tool_version": "1.2.0",
        "schema_version": "1.0",
        "arguments": {"amount": 250},
    }

    changed = {
        **original,
        "arguments": {"amount": 500},
    }

    assert calculate_operation_hash(original) != calculate_operation_hash(changed)


def test_execution_record_rejects_tampered_operation_hash():
    with pytest.raises(ValueError):
        make_record(operation_hash="0" * 64)


def test_execution_record_rejects_invalid_hash_format():
    with pytest.raises(ValueError):
        make_record(operation_hash="not-a-sha256-hash")


def test_execution_record_rejects_none_operation_hash():
    with pytest.raises(TypeError):
        make_record(operation_hash=None)
