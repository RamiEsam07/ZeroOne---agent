﻿from jsonschema import Draft202012Validator, FormatChecker

from agent.contracts.tool_invocation import ToolInvocation
from agent.contracts.tool_result import ToolResult
from agent.core.tool_registry import RegisteredTool


class ToolExecutor:
    """
    Executes registered tools through validated contracts.
    """

    def execute(
        self,
        registered_tool: RegisteredTool,
        invocation: ToolInvocation
    ) -> ToolResult:

        if not isinstance(registered_tool, RegisteredTool):
            return self._error(
                invocation,
                "INVALID_TOOL",
                "Registered tool is invalid."
            )

        if not isinstance(invocation, ToolInvocation):
            return self._error(
                None,
                "INVALID_INVOCATION",
                "Tool invocation is invalid."
            )

        definition = registered_tool.definition

        if invocation.tool_id != definition.tool_id:
            return self._error(
                invocation,
                "TOOL_MISMATCH",
                "Invocation tool does not match registered tool."
            )

        input_validator = Draft202012Validator(
            dict(definition.input_schema),
            format_checker=FormatChecker()
        )

        input_errors = sorted(
            input_validator.iter_errors(dict(invocation.arguments)),
            key=lambda error: list(error.path)
        )

        if input_errors:
            return self._error(
                invocation,
                "INPUT_VALIDATION_FAILED",
                "Tool input does not match its schema."
            )

        try:
            output = registered_tool.handler(
                **dict(invocation.arguments)
            )

        except Exception:
            return self._error(
                invocation,
                "TOOL_EXECUTION_FAILED",
                "Tool execution failed."
            )

        if not isinstance(output, dict):
            return self._error(
                invocation,
                "OUTPUT_VALIDATION_FAILED",
                "Tool output must be an object."
            )

        output_validator = Draft202012Validator(
            dict(definition.output_schema),
            format_checker=FormatChecker()
        )

        output_errors = sorted(
            output_validator.iter_errors(output),
            key=lambda error: list(error.path)
        )

        if output_errors:
            return self._error(
                invocation,
                "OUTPUT_VALIDATION_FAILED",
                "Tool output does not match its schema."
            )

        return ToolResult(
            invocation_id=invocation.invocation_id,
            tool_id=invocation.tool_id,
            status="success",
            output=output
        )

    @staticmethod
    def _error(
        invocation,
        code,
        message
    ) -> ToolResult:

        return ToolResult(
            invocation_id=(
                invocation.invocation_id
                if isinstance(invocation, ToolInvocation)
                else "UNKNOWN"
            ),
            tool_id=(
                invocation.tool_id
                if isinstance(invocation, ToolInvocation)
                else "unknown"
            ),
            status="error",
            error={
                "code": code,
                "message": message
            }
        )
