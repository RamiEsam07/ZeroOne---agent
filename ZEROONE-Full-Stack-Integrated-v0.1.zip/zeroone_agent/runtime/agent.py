
"""محرك تشغيل الوكيل (Agent Runtime).

تدفق الطلب:
استلام ← تحليل ← التحقق من السياسة والصلاحيات
← تنفيذ أو طلب موافقة أو رفض ← تسجيل ← استجابة.
"""

from datetime import datetime, timezone
from uuid import uuid4

from zeroone_agent.contracts.models import (
    AgentResponse,
    ExecutionPolicy,
    ResponseStatus,
    ToolInvocation,
)
from zeroone_agent.runtime.analyzer import RuleBasedAnalyzer


class AgentRuntime:
    """ينسق بين المحلل والأدوات والصلاحيات والتدقيق والموافقات."""

    def __init__(self, registry, executor, audit, approvals, analyzer=None):
        self.registry = registry
        self.executor = executor
        self.audit = audit
        self.approvals = approvals
        self.analyzer = analyzer or RuleBasedAnalyzer()

    def handle(self, request, context) -> AgentResponse:
        started_at = datetime.now(timezone.utc)

        self.audit.record(
            context,
            "request.received",
            {"message": request.message},
        )

        try:
            analysis = self.analyzer.analyze(
                request.message,
                dict(request.context),
            )

            if analysis.intent == "clarification":
                return self._respond(
                    request,
                    ResponseStatus.COMPLETED,
                    analysis.message_for_user or "يرجى توضيح طلبك أكثر.",
                    started_at,
                )

            if analysis.intent == "unknown" or not analysis.tool_id:
                return self._respond(
                    request,
                    ResponseStatus.COMPLETED,
                    analysis.message_for_user
                    or "لم أتمكن من تحديد الإجراء المطلوب.",
                    started_at,
                )

            try:
                tool = self.registry.get(analysis.tool_id)
            except KeyError:
                self.audit.record(
                    context,
                    "tool.not_found",
                    {"tool_id": analysis.tool_id},
                )
                return self._respond(
                    request,
                    ResponseStatus.FAILED,
                    "الأداة المطلوبة غير متاحة.",
                    started_at,
                    error={
                        "code": "UNKNOWN_TOOL",
                        "message": "Requested tool is not registered.",
                    },
                )

            policy = tool.definition.execution_policy

            # السياسة الأولى: الإجراءات البشرية لا ينفذها الوكيل.
            if policy == ExecutionPolicy.HUMAN_ONLY:
                self.audit.record(
                    context,
                    "tool.human_only_denied",
                    {"tool_id": analysis.tool_id},
                )
                return self._respond(
                    request,
                    ResponseStatus.DENIED,
                    "هذا الإجراء مخصص للتنفيذ البشري ولا يمكن للوكيل تنفيذه.",
                    started_at,
                )

            # التحقق من صلاحيات المستخدم قبل التنفيذ أو طلب الموافقة.
            missing_capabilities = (
                set(tool.definition.required_capabilities)
                - set(context.capabilities)
            )

            if missing_capabilities:
                self.audit.record(
                    context,
                    "tool.permission_denied",
                    {
                        "tool_id": analysis.tool_id,
                        "missing_capabilities": sorted(missing_capabilities),
                    },
                )
                return self._respond(
                    request,
                    ResponseStatus.DENIED,
                    "لا تملك الصلاحيات اللازمة لتنفيذ هذا الإجراء.",
                    started_at,
                    data={
                        "error": {
                            "code": "PERMISSION_DENIED",
                            "message": "Required capabilities are missing.",
                        }
                    },
                )

            # السياسة الثانية: يتطلب موافقة صريحة قبل التنفيذ.
            if policy == ExecutionPolicy.APPROVAL_REQUIRED:
                approval = self.approvals.request(
                    context,
                    analysis.tool_id,
                    analysis.arguments or {},
                )

                self.audit.record(
                    context,
                    "tool.approval_requested",
                    {
                        "tool_id": analysis.tool_id,
                        "approval_id": approval.approval_id,
                    },
                )

                return self._respond(
                    request,
                    ResponseStatus.APPROVAL_REQUIRED,
                    "يتطلب هذا الإجراء موافقة مسؤول مخوّل قبل تنفيذه.",
                    started_at,
                    approval_id=approval.approval_id,
                )

            # السياسة الافتراضية: التنفيذ بعد اجتياز الصلاحيات.
            invocation = ToolInvocation(
                "INV-" + uuid4().hex,
                analysis.tool_id,
                context,
                analysis.arguments or {},
            )

            result = self.executor.execute(invocation)

            if result.success:
                return self._respond(
                    request,
                    ResponseStatus.COMPLETED,
                    "تم تنفيذ الطلب بنجاح.",
                    started_at,
                    data=dict(result.data),
                )

            return self._respond(
                request,
                ResponseStatus.DENIED,
                result.error["message"],
                started_at,
                data={"error": dict(result.error)},
            )

        except Exception:
            self.audit.record(
                context,
                "request.failed",
                {"reason": "internal_error"},
            )

            return self._respond(
                request,
                ResponseStatus.FAILED,
                "حدث خطأ أثناء معالجة الطلب.",
                started_at,
                error={
                    "code": "REQUEST_FAILED",
                    "message": "Request processing failed",
                },
            )

    def _respond(
        self,
        request,
        status: ResponseStatus,
        message: str,
        started_at: datetime,
        data=None,
        error=None,
        approval_id=None,
    ) -> AgentResponse:
        now = datetime.now(timezone.utc)

        return AgentResponse(
            request_id=request.request_id,
            agent_id=request.agent_id,
            status=status,
            message=message,
            responded_at=now,
            finished_at=now,
            data=data or {},
            error=error,
            approval_id=approval_id,
        )
