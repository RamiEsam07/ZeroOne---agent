
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping
from .value_objects import freeze_json_value

@dataclass(frozen=True, slots=True)
class AgentRequest:
    """
    Represents an incoming request submitted to an agent.

    This object contains untrusted request data.
    Authentication and tenant resolution happen separately.
    """

    request_id: str
    agent_id: str
    message: str
    received_at: datetime

    context: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        required_fields = (
            "request_id",
            "agent_id",
            "message",
        )

        for field_name in required_fields:
            value = getattr(self, field_name)

            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"{field_name} must be a non-empty string."
                )

        if not isinstance(self.received_at, datetime):
            raise TypeError("received_at must be a datetime.")

        if (
            self.received_at.tzinfo is None
            or self.received_at.utcoffset() is None
        ):
            raise ValueError(
                "received_at must be timezone-aware."
            )

        if not isinstance(self.context, Mapping):
            raise TypeError("context must be a mapping.")

        object.__setattr__(
            self,
            "context",
            freeze_json_value(self.context)
        )
