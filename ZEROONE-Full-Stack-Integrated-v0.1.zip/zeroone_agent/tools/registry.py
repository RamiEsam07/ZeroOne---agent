"""سجل مركزي لإدارة أدوات الوكيل المتاحة."""

from dataclasses import dataclass
from typing import Callable

from zeroone_agent.contracts.models import ToolDefinition


@dataclass(frozen=True)
class RegisteredTool:
    definition: ToolDefinition
    handler: Callable


class ToolRegistry:
    """يحتفظ بكل الأدوات المسجلة، مفهرسة بمعرف الأداة (tool_id)."""

    def __init__(self):
        self._tools: dict[str, RegisteredTool] = {}

    def register(self, definition: ToolDefinition, handler: Callable) -> None:
        if definition.tool_id in self._tools:
            raise ValueError(f"Duplicate tool_id: {definition.tool_id}")

        if not callable(handler):
            raise TypeError("handler must be callable.")

        self._tools[definition.tool_id] = RegisteredTool(definition, handler)

    def get(self, tool_id: str) -> RegisteredTool:
        if tool_id not in self._tools:
            raise KeyError(f"Unknown tool: {tool_id}")
        return self._tools[tool_id]

    def list_tools(self, domain: str | None = None) -> list[ToolDefinition]:
        return [
            entry.definition
            for entry in self._tools.values()
            if domain is None or entry.definition.domain == domain
        ]
