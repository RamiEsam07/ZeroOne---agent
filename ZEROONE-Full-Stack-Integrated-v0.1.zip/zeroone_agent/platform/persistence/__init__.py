"""Durable persistence adapters for the ZEROONE platform control plane."""
