from datetime import datetime, timedelta, timezone
from contextlib import closing
import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory
from concurrent.futures import ThreadPoolExecutor

import pytest

from zeroone_agent.contracts.models import ExecutionRecord, ExecutionStatus
from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.security.approval_repository import SQLiteApprovalRepository
from zeroone_agent.security.execution_repository import SQLiteExecutionRepository


class Context:
    tenant_id = "tenant-a"
    agent_id = "agent-a"
    principal_id = "requester-a"


def _approved_operation(db: Path):
    approvals = ApprovalService(repository=SQLiteApprovalRepository(db))
    approval = approvals.request(Context(), "clinic.billing.refund", {"amount": 250})
    approvals.decide(approval.approval_id, "tenant-a", "manager-a", True)
    record = ExecutionRecord(
        execution_id="EXE-001", approval_id=approval.approval_id,
        tenant_id="tenant-a", agent_id="agent-a", domain="clinic",
        principal_id="requester-a", tool_id="clinic.billing.refund",
        tool_version="1.0.0", schema_version="1.0.0",
        arguments={"amount": 250}, idempotency_key="idem-001",
        status=ExecutionStatus.NOT_STARTED,
    )
    return approvals, approval, record


def test_execution_is_bound_to_exact_approved_operation_and_persists():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, approval, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        created = repo.create_for_approved_operation(record)
        assert created["status"] == "not_started"
        assert created["operation_hash"] == record.operation_hash
        assert repo.claim(record.execution_id, "tenant-a", actor_id="system")
        assert repo.get(record.execution_id, "tenant-a")["status"] == "executing"
        restarted = SQLiteExecutionRepository(db)
        assert restarted.get(record.execution_id, "tenant-a")["approval_id"] == approval.approval_id


def test_execution_creation_rejects_changed_arguments_or_wrong_identity():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, _, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        changed = ExecutionRecord(
            execution_id="EXE-002", approval_id=record.approval_id,
            tenant_id=record.tenant_id, agent_id=record.agent_id,
            domain=record.domain, principal_id=record.principal_id,
            tool_id=record.tool_id, tool_version=record.tool_version,
            schema_version=record.schema_version, arguments={"amount": 251},
            idempotency_key="idem-002", status=ExecutionStatus.NOT_STARTED,
        )
        with pytest.raises(PermissionError, match="arguments"):
            repo.create_for_approved_operation(changed)


def test_execution_can_only_be_claimed_once_even_concurrently():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, _, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        repo.create_for_approved_operation(record)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(
                lambda _: repo.claim(record.execution_id, "tenant-a", actor_id="worker"),
                range(2),
            ))
        assert sorted(results) == [False, True]


def test_unknown_outcome_cannot_be_reclaimed_or_retried():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, _, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        repo.create_for_approved_operation(record)
        assert repo.claim(record.execution_id, "tenant-a", actor_id="worker")
        assert repo.transition(
            record.execution_id, "tenant-a", ExecutionStatus.EXECUTING,
            ExecutionStatus.OUTCOME_UNKNOWN, actor_id="worker",
            reason="process interrupted during external side effect",
        )
        assert not repo.claim(record.execution_id, "tenant-a", actor_id="worker-2")
        with pytest.raises(ValueError, match="Illegal execution transition"):
            repo.transition(
                record.execution_id, "tenant-a", ExecutionStatus.OUTCOME_UNKNOWN,
                ExecutionStatus.EXECUTING, actor_id="worker-2", reason="retry",
            )
        assert repo.transition(
            record.execution_id, "tenant-a", ExecutionStatus.OUTCOME_UNKNOWN,
            ExecutionStatus.UNDER_REVIEW, actor_id="manager",
            reason="manual review opened",
        )


def test_execution_tenant_isolation_and_idempotency_uniqueness():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, _, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        repo.create_for_approved_operation(record)
        assert repo.get(record.execution_id, "tenant-b") is None
        with pytest.raises(sqlite3.IntegrityError):
            repo.create_for_approved_operation(record)


def test_expired_approved_operation_cannot_be_claimed():
    with TemporaryDirectory() as temp:
        db = Path(temp) / "zeroone.db"
        _, approval, record = _approved_operation(db)
        repo = SQLiteExecutionRepository(db)
        repo.create_for_approved_operation(record)
        expired = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
        with closing(sqlite3.connect(db)) as con:
            con.execute(
                "UPDATE approval_records SET expires_at = ? WHERE approval_id = ?",
                (expired, approval.approval_id),
            )
            con.commit()
        assert not repo.claim(record.execution_id, "tenant-a", actor_id="worker")
        assert repo.get(record.execution_id, "tenant-a")["status"] == "not_started"
