﻿from agent.contracts.tool_definition import ToolDefinition


VIEW_APPOINTMENTS_DEFINITION = ToolDefinition(
    tool_id="clinic.view_appointments",
    name="view_appointments",
    version="1.0.0",
    description="View clinic appointments for a specific date.",
    domain="clinic",

    input_schema={
        "type": "object",
        "properties": {
            "target_date": {
                "type": "string",
                "format": "date",
                "description": "Appointment date in ISO format."
            }
        },
        "additionalProperties": False
    },

    output_schema={
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "status": {"const": "success"},
                    "date": {"type": "string", "format": "date"},
                    "total": {"type": "integer", "minimum": 0},
                    "appointments": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "patient_name": {"type": "string"},
                                "doctor": {"type": "string"},
                                "date": {"type": "string", "format": "date"},
                                "time": {"type": "string"},
                                "status": {"type": "string"}
                            },
                            "required": [
                                "id",
                                "patient_name",
                                "doctor",
                                "date",
                                "time",
                                "status"
                            ],
                            "additionalProperties": False
                        }
                    }
                },
                "required": [
                    "status",
                    "date",
                    "total",
                    "appointments"
                ],
                "additionalProperties": False
            },
            {
                "type": "object",
                "properties": {
                    "status": {"const": "error"},
                    "message": {"type": "string"}
                },
                "required": ["status", "message"],
                "additionalProperties": False
            }
        ]
    },

    required_capabilities=("clinic.appointments.read",)
)
