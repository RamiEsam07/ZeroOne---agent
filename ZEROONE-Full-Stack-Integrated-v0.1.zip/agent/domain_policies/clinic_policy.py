
CLINIC_ROLE_PERMISSIONS = {
    "receptionist": {
        "view_appointments",
        "register_patient",
        "cancel_appointment"
    },

    "doctor": {
        "view_appointments",
        "view_patient_records",
        "update_medical_record"
    },

    "clinic_manager": {
        "view_appointments",
        "register_patient",
        "cancel_appointment",
        "view_patient_records",
        "update_medical_record",
        "prepare_revenue_report",
        "view_clinic_reports"
    }
}


CLINIC_APPROVAL_REQUIRED_ACTIONS = {
    "delete_patient_record",
    "modify_billing_records",
    "issue_refund"
}


CLINIC_HUMAN_ONLY_ACTIONS = {
    "approve_medical_decision",
    "approve_final_financial_report"
}


def get_clinic_permissions():
    """
    Return the complete permission configuration for the clinic.
    """

    return {
        "role_permissions": CLINIC_ROLE_PERMISSIONS,
        "approval_required_actions": CLINIC_APPROVAL_REQUIRED_ACTIONS,
        "human_only_actions": CLINIC_HUMAN_ONLY_ACTIONS
    }
