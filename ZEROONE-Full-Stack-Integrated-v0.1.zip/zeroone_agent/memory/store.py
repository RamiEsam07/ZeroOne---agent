"""
الذاكرة طويلة المدى للوكيل (Long-Term Memory).

كل معلومة جديدة يتعلمها الوكيل تُحفظ بحالة "pending" ولا تُستخدم فعليًا
حتى يعتمدها إنسان مخوّل. هذا يمنع الوكيل من "تعليم نفسه" معلومات خاطئة
أو ضارة بدون رقابة — نفس مبدأ "الوكيل يقترح، الإنسان يعتمد" في بقية النظام.

الوضع الافتراضي: تخزين في الذاكرة (مناسب للاختبار).
لتفعيل حفظ دائم، مرر persist_path عند الإنشاء.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from uuid import uuid4

MEMORY_CATEGORIES = ("preferences", "business_rules", "learned_facts", "context")


class MemoryStore:
    """يخزن معلومات مكتسبة لكل (tenant, agent)، بعزل كامل بين الجهات، مع موافقة بشرية."""

    def __init__(self, persist_path: str | Path | None = None):
        self._items: list[dict] = []
        self._lock = RLock()
        self.persist_path = Path(persist_path) if persist_path else None

        if self.persist_path and self.persist_path.exists():
            self._load_from_disk()
        elif self.persist_path:
            self.persist_path.parent.mkdir(parents=True, exist_ok=True)

    def _load_from_disk(self) -> None:
        try:
            with open(self.persist_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            self._items = data.get("items", [])
        except (json.JSONDecodeError, OSError):
            self._items = []

    def _save_to_disk(self) -> None:
        if not self.persist_path:
            return
        try:
            with open(self.persist_path, "w", encoding="utf-8") as file:
                json.dump({"items": self._items}, file, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def add(
        self,
        tenant_id: str,
        agent_id: str,
        content: str,
        category: str = "learned_facts",
        source: str = "agent",
    ) -> dict:
        """يضيف عنصر ذاكرة جديد بحالة 'pending' — لا يُستخدم حتى يُعتمد."""
        if not content.strip():
            raise ValueError("content is required.")

        if category not in MEMORY_CATEGORIES:
            raise ValueError(f"Invalid category: {category}")

        item = {
            "memory_id": "MEM-" + uuid4().hex,
            "tenant_id": tenant_id,
            "agent_id": agent_id,
            "content": content.strip(),
            "category": category,
            "source": source,
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "reviewed_by": None,
            "reviewed_at": None,
        }

        with self._lock:
            self._items.append(item)
            self._save_to_disk()

        return dict(item)

    def review(self, memory_id: str, decision: str, reviewed_by: str) -> dict:
        """يعتمد أو يرفض عنصر ذاكرة معلّق (pending)."""
        if decision not in {"approved", "rejected"}:
            raise ValueError("decision must be 'approved' or 'rejected'.")

        if not reviewed_by.strip():
            raise ValueError("reviewed_by is required.")

        with self._lock:
            for item in self._items:
                if item["memory_id"] != memory_id:
                    continue

                if item["status"] != "pending":
                    raise ValueError("Only pending memories can be reviewed.")

                item["status"] = decision
                item["reviewed_by"] = reviewed_by.strip()
                item["reviewed_at"] = datetime.now(timezone.utc).isoformat()

                self._save_to_disk()
                return dict(item)

            raise KeyError(f"Memory item not found: {memory_id}")

    def search(
        self,
        tenant_id: str,
        agent_id: str,
        query: str = "",
        approved_only: bool = True,
    ) -> list[dict]:
        """يبحث في الذاكرة، مقتصرًا افتراضيًا على العناصر المعتمدة فقط."""
        normalized_query = query.casefold()

        with self._lock:
            return [
                dict(item)
                for item in self._items
                if item["tenant_id"] == tenant_id
                and item["agent_id"] == agent_id
                and normalized_query in item["content"].casefold()
                and (not approved_only or item["status"] == "approved")
            ]

    def list_pending(self, tenant_id: str, agent_id: str) -> list[dict]:
        """يرجع كل العناصر المعلّقة بانتظار مراجعة بشرية — للوحة تحكم المراجعة."""
        with self._lock:
            return [
                dict(item)
                for item in self._items
                if item["tenant_id"] == tenant_id
                and item["agent_id"] == agent_id
                and item["status"] == "pending"
            ]
