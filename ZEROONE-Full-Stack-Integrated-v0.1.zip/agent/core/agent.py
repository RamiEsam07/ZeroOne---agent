
import re
import json
from pathlib import Path
from datetime import datetime
from permission_engine import PermissionEngine


class ZeroOneAgent:

    def __init__(self):
        self.name = "ZEROONE Smart Agent"
        self.version = "0.4.1"
        self.status = "ready"

        self.memory_file = (
            Path(__file__).resolve().parents[2]
            / "data"
            / "agent_memory.json"
        )

        self.constitution = {}
        self.permission_engine = PermissionEngine()

    def introduce(self):
        print("=" * 45)
        print(self.name)
        print(f"Version: {self.version}")
        print(f"Status: {self.status}")
        print("=" * 45)

    def load_constitution(self):
        constitution_file = (
            Path(__file__).resolve().parents[2]
            / "data"
            / "agent_constitution.json"
        )

        with open(constitution_file, "r", encoding="utf-8") as file:
            self.constitution = json.load(file)

        print("\nConstitution loaded successfully.")
        print(f"Agent mission: {self.constitution['mission']}")

    def receive_request(self):
        print("\nZEROONE Agent is listening...")

        request = input("Enter your request: ")

        if not request.strip():
            print("No request received.")
            return

        analysis = self.analyze_request(request)

        action_map = {
            "create_project": "create_project_record",
            "financial_purchase": "execute_financial_purchase"
        }

        action = action_map.get(
            analysis["request_type"],
            "unknown_action"
        )

        allowed, reason = self.permission_engine.check_permission(action)

        print("\n--- PERMISSION CHECK ---")
        print(f"Proposed action: {action}")
        print(f"Permission: {'ALLOWED' if allowed else 'DENIED'}")
        print(f"Reason: {reason}")

        analysis["proposed_action"] = action
        analysis["permission"] = "ALLOWED" if allowed else "DENIED"
        analysis["permission_reason"] = reason

        self.save_memory(analysis)

    def analyze_request(self, request):
        print("\n--- REQUEST ANALYSIS ---")

        if "شراء" in request or "اشتر" in request:
            request_type = "financial_purchase"

        elif "مشروع" in request:
            request_type = "create_project"

        else:
            request_type = "unknown"

        duration = re.search(r"(\d+)\s*يوم", request)

        analysis = {
            "original_request": request,
            "request_type": request_type,
            "duration_days": int(duration.group(1)) if duration else None
        }

        print(f"Request type: {analysis['request_type']}")
        print(f"Duration: {analysis['duration_days']}")

        return analysis

    def save_memory(self, analysis):
        with open(self.memory_file, "r", encoding="utf-8") as file:
            memory = json.load(file)

        analysis["saved_at"] = datetime.now().isoformat(timespec="seconds")

        memory["requests"].append(analysis)

        with open(self.memory_file, "w", encoding="utf-8") as file:
            json.dump(memory, file, ensure_ascii=False, indent=4)

        print("\nRequest saved to agent memory successfully.")

    def show_memory(self):
        with open(self.memory_file, "r", encoding="utf-8") as file:
            memory = json.load(file)

        requests = memory["requests"]

        print("\n--- AGENT MEMORY ---")
        print(f"Total requests: {len(requests)}")

        for index, request in enumerate(requests, start=1):
            print(f"\nRequest {index}:")
            print(request["original_request"])
            print(f"Type: {request['request_type']}")
            print(f"Permission: {request.get('permission', 'NOT RECORDED')}")


if __name__ == "__main__":
    agent = ZeroOneAgent()

    agent.introduce()
    agent.load_constitution()
    agent.receive_request()
    agent.show_memory()
