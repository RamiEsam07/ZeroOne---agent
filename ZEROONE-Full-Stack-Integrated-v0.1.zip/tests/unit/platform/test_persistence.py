from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from zeroone_agent.platform.persistence.database import Base
from zeroone_agent.platform.persistence.repository import PlatformRepository

def make_repo(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'platform.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    return PlatformRepository(sessionmaker(bind=engine, expire_on_commit=False))

def test_platform_records_survive_repository_restart_and_isolate_tenants(tmp_path):
    repo = make_repo(tmp_path)
    repo.register_domain(domain_id="store", display_name="Store", package_version="1.0", description="Retail", capabilities=["sales"], modules=["pos", "inventory"], settings_schema={})
    repo.create_tenant("client_a", "Client A")
    repo.create_tenant("client_b", "Client B")
    repo.create_workspace(tenant_id="client_a", workspace_id="main", domain_id="store", display_name="A Store", enabled_modules=["pos"], settings={})
    repo.create_workspace(tenant_id="client_b", workspace_id="main", domain_id="store", display_name="B Store", enabled_modules=["inventory"], settings={})
    reopened = PlatformRepository(repo._sessions)
    assert reopened.get_workspace(authenticated_tenant_id="client_a", workspace_id="main")["display_name"] == "A Store"
    assert reopened.get_workspace(authenticated_tenant_id="client_b", workspace_id="main")["display_name"] == "B Store"
    assert len(reopened.list_audit_events(tenant_id="client_a")) == 2

def test_reject_unknown_modules_and_inactive_tenant(tmp_path):
    repo = make_repo(tmp_path)
    repo.register_domain(domain_id="clinic", display_name="Clinic", package_version="1", description="Healthcare", capabilities=[], modules=["appointments"], settings_schema={})
    repo.create_tenant("clinic_a", "Clinic A")
    try:
        repo.create_workspace(tenant_id="clinic_a", workspace_id="main", domain_id="clinic", display_name="Clinic", enabled_modules=["pos"], settings={})
    except ValueError as exc:
        assert "Unsupported" in str(exc)
    else: assert False, "unknown module must be rejected"
