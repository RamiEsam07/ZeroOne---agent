"""Durable, tenant-scoped execution lifecycle backed by SQLite.

An execution may be claimed only once, and only for the exact approved
operation. An uncertain outcome is terminal for automatic execution: this
repository deliberately exposes no retry/reclaim path for it.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from zeroone_agent.contracts.models import (
    ExecutionRecord, ExecutionStatus, calculate_operation_hash, thaw_json_value,
)


_ALLOWED_TRANSITIONS = {
    ExecutionStatus.NOT_STARTED: {
        ExecutionStatus.EXECUTING,
    },
    ExecutionStatus.EXECUTING: {
        ExecutionStatus.EXECUTED,
        ExecutionStatus.FAILED,
        ExecutionStatus.OUTCOME_UNKNOWN,
    },
    ExecutionStatus.OUTCOME_UNKNOWN: {
        ExecutionStatus.UNDER_REVIEW,
    },
    ExecutionStatus.EXECUTED: set(),
    ExecutionStatus.FAILED: set(),
    ExecutionStatus.UNDER_REVIEW: set(),
}


class SQLiteExecutionRepository:
    """Persists exact operation identity, status transitions, and history."""

    def __init__(self, path: str | Path = "data/zeroone.db"):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        con.execute("PRAGMA busy_timeout = 15000")
        return con

    @contextmanager
    def _connection(self):
        con = self._connect()
        try:
            yield con
        finally:
            con.close()

    def _initialize(self) -> None:
        with self._connection() as con:
            con.execute("PRAGMA journal_mode = WAL")
            con.executescript("""
                CREATE TABLE IF NOT EXISTS execution_records (
                    execution_id TEXT PRIMARY KEY,
                    approval_id TEXT NOT NULL UNIQUE,
                    tenant_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    domain TEXT NOT NULL,
                    principal_id TEXT NOT NULL,
                    tool_id TEXT NOT NULL,
                    tool_version TEXT NOT NULL,
                    schema_version TEXT NOT NULL,
                    arguments_json TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    operation_hash TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN
                        ('not_started','executing','executed','failed','outcome_unknown','under_review')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(tenant_id, idempotency_key),
                    FOREIGN KEY(approval_id) REFERENCES approval_records(approval_id)
                        ON DELETE RESTRICT
                );
                CREATE INDEX IF NOT EXISTS ix_execution_tenant_status
                    ON execution_records(tenant_id, status, created_at);
                CREATE TABLE IF NOT EXISTS execution_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    execution_id TEXT NOT NULL,
                    tenant_id TEXT NOT NULL,
                    from_status TEXT,
                    to_status TEXT NOT NULL,
                    actor_id TEXT,
                    reason TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(execution_id) REFERENCES execution_records(execution_id)
                        ON DELETE RESTRICT
                );
                CREATE INDEX IF NOT EXISTS ix_execution_history_tenant
                    ON execution_history(tenant_id, execution_id, id);
            """)

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["arguments"] = json.loads(item.pop("arguments_json"))
        return item

    def create_for_approved_operation(self, record: ExecutionRecord) -> dict[str, Any]:
        """Create once, only when approval exactly matches the operation."""
        if not isinstance(record, ExecutionRecord):
            raise TypeError("record must be an ExecutionRecord")
        if record.status is not ExecutionStatus.NOT_STARTED:
            raise ValueError("New executions must start as NOT_STARTED")
        args_json = json.dumps(
            thaw_json_value(record.arguments), ensure_ascii=False, sort_keys=True,
            separators=(",", ":"), allow_nan=False,
        )
        now = datetime.now(timezone.utc).isoformat()
        with self._connection() as con:
            con.execute("BEGIN IMMEDIATE")
            try:
                approval = con.execute("""
                    SELECT tenant_id, agent_id, principal_id, action, payload_json,
                           status, expires_at
                    FROM approval_records WHERE approval_id = ?
                """, (record.approval_id,)).fetchone()
                if approval is None:
                    raise KeyError("Approval not found")
                if approval["tenant_id"] != record.tenant_id:
                    raise PermissionError("Approval tenant mismatch")
                if approval["status"] != "approved":
                    raise ValueError("Execution requires an approved request")
                if (approval["agent_id"] != record.agent_id
                        or approval["principal_id"] != record.principal_id
                        or approval["action"] != record.tool_id):
                    raise PermissionError("Approval identity or action mismatch")
                approved_payload = json.loads(approval["payload_json"])
                if approved_payload != json.loads(args_json):
                    raise PermissionError("Approved arguments do not match execution arguments")
                if datetime.fromisoformat(approval["expires_at"]) <= datetime.now(timezone.utc):
                    raise ValueError("Approval has expired")

                con.execute("""
                    INSERT INTO execution_records
                    (execution_id, approval_id, tenant_id, agent_id, domain,
                     principal_id, tool_id, tool_version, schema_version,
                     arguments_json, idempotency_key, operation_hash, status,
                     created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record.execution_id, record.approval_id, record.tenant_id,
                    record.agent_id, record.domain, record.principal_id,
                    record.tool_id, record.tool_version, record.schema_version,
                    args_json, record.idempotency_key, record.operation_hash,
                    record.status.value, record.created_at.isoformat(), now,
                ))
                con.execute("""
                    INSERT INTO execution_history
                    (execution_id, tenant_id, from_status, to_status, actor_id, reason, created_at)
                    VALUES (?, ?, NULL, ?, ?, ?, ?)
                """, (record.execution_id, record.tenant_id,
                      record.status.value, record.principal_id, "execution_record_created", now))
                con.commit()
            except Exception:
                con.rollback()
                raise
        return self.get(record.execution_id, record.tenant_id)

    def get(self, execution_id: str, tenant_id: str) -> dict[str, Any] | None:
        with self._connection() as con:
            row = con.execute("""
                SELECT * FROM execution_records
                WHERE execution_id = ? AND tenant_id = ?
            """, (execution_id, tenant_id)).fetchone()
        return self._row_to_dict(row) if row else None

    def claim(self, execution_id: str, tenant_id: str, *, actor_id: str) -> bool:
        """Atomically claim NOT_STARTED -> EXECUTING; never reclaims a prior run."""
        if not isinstance(actor_id, str) or not actor_id.strip():
            raise ValueError("actor_id is required")
        now = datetime.now(timezone.utc).isoformat()
        with self._connection() as con:
            con.execute("BEGIN IMMEDIATE")
            try:
                row = con.execute("""
                    SELECT e.status, e.approval_id, e.tenant_id, e.agent_id,
                           e.domain, e.principal_id, e.tool_id, e.tool_version,
                           e.schema_version, e.arguments_json, e.operation_hash,
                           a.status AS approval_status,
                           a.tenant_id AS approval_tenant, a.agent_id AS approval_agent,
                           a.principal_id AS approval_principal, a.action AS approval_action,
                           a.payload_json AS approval_payload, a.expires_at
                    FROM execution_records e
                    JOIN approval_records a ON a.approval_id = e.approval_id
                    WHERE e.execution_id = ? AND e.tenant_id = ?
                """, (execution_id, tenant_id)).fetchone()
                if row is None or row["status"] != ExecutionStatus.NOT_STARTED.value:
                    con.rollback()
                    return False
                if row["approval_status"] != "approved":
                    con.rollback()
                    return False
                if (row["approval_tenant"] != tenant_id
                        or row["approval_tenant"] != row["tenant_id"]
                        or row["approval_agent"] != row["agent_id"]
                        or row["approval_principal"] != row["principal_id"]
                        or row["approval_action"] != row["tool_id"]
                        or json.loads(row["approval_payload"]) != json.loads(row["arguments_json"])):
                    con.rollback()
                    return False
                expected_hash = calculate_operation_hash({
                    "approval_id": row["approval_id"],
                    "tenant_id": row["tenant_id"],
                    "agent_id": row["agent_id"],
                    "domain": row["domain"],
                    "principal_id": row["principal_id"],
                    "tool_id": row["tool_id"],
                    "tool_version": row["tool_version"],
                    "schema_version": row["schema_version"],
                    "arguments": json.loads(row["arguments_json"]),
                })
                if expected_hash != row["operation_hash"]:
                    con.rollback()
                    return False
                if datetime.fromisoformat(row["expires_at"]) <= datetime.now(timezone.utc):
                    con.rollback()
                    return False
                cursor = con.execute("""
                    UPDATE execution_records SET status = ?, updated_at = ?
                    WHERE execution_id = ? AND tenant_id = ? AND status = ?
                """, (ExecutionStatus.EXECUTING.value, now, execution_id,
                      tenant_id, ExecutionStatus.NOT_STARTED.value))
                if cursor.rowcount != 1:
                    con.rollback()
                    return False
                con.execute("""
                    INSERT INTO execution_history
                    (execution_id, tenant_id, from_status, to_status, actor_id, reason, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (execution_id, tenant_id, ExecutionStatus.NOT_STARTED.value,
                      ExecutionStatus.EXECUTING.value, actor_id,
                      "atomic_execution_claim", now))
                con.commit()
                return True
            except Exception:
                con.rollback()
                raise

    def transition(self, execution_id: str, tenant_id: str,
                   expected: ExecutionStatus, target: ExecutionStatus,
                   *, actor_id: str, reason: str) -> bool:
        if target not in _ALLOWED_TRANSITIONS.get(expected, set()):
            raise ValueError(f"Illegal execution transition: {expected.value} -> {target.value}")
        if not actor_id or not actor_id.strip():
            raise ValueError("actor_id is required")
        if not reason or not reason.strip():
            raise ValueError("reason is required")
        now = datetime.now(timezone.utc).isoformat()
        with self._connection() as con:
            con.execute("BEGIN IMMEDIATE")
            try:
                cursor = con.execute("""
                    UPDATE execution_records SET status = ?, updated_at = ?
                    WHERE execution_id = ? AND tenant_id = ? AND status = ?
                """, (target.value, now, execution_id, tenant_id, expected.value))
                if cursor.rowcount != 1:
                    con.rollback()
                    return False
                con.execute("""
                    INSERT INTO execution_history
                    (execution_id, tenant_id, from_status, to_status, actor_id, reason, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (execution_id, tenant_id, expected.value, target.value,
                      actor_id, reason, now))
                con.commit()
                return True
            except Exception:
                con.rollback()
                raise

    def list_history(self, execution_id: str, tenant_id: str) -> list[dict[str, Any]]:
        with self._connection() as con:
            rows = con.execute("""
                SELECT id, execution_id, tenant_id, from_status, to_status,
                       actor_id, reason, created_at
                FROM execution_history
                WHERE execution_id = ? AND tenant_id = ? ORDER BY id
            """, (execution_id, tenant_id)).fetchall()
        return [dict(row) for row in rows]
