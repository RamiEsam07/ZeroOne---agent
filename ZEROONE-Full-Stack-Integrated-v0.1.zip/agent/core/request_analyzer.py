
import re
from datetime import date, timedelta


class RequestAnalyzer:
    """
    Analyzes user requests and extracts actions and dates.
    """

    def __init__(self, domain):
        self.domain = domain

        self.action_patterns = {
            "clinic": {
                "view_appointments": [
                    r"مواعيد",
                    r"جدول العياده",
                    r"جدول اليوم",
                    r"الحجوزات",
                    r"المواعيد المحجوزه",
                    r"المرضي الحاجزين",
                    r"عرض المواعيد",
                    r"اعرض المواعيد",
                    r"وريني المواعيد",
                    r"كم عدد المواعيد"
                ],

                "register_patient": [
                    r"تسجيل مريض",
                    r"مريض جديد",
                    r"اضف مريض",
                    r"اضافه مريض"
                ],

                "cancel_appointment": [
                    r"الغاء الموعد",
                    r"الغي الموعد"
                ],

                "prepare_revenue_report": [
                    r"تقرير الايرادات",
                    r"ايرادات العياده"
                ]
            }
        }

        self.months = {
            "يناير": 1,
            "فبراير": 2,
            "مارس": 3,
            "ابريل": 4,
            "مايو": 5,
            "يونيو": 6,
            "يوليو": 7,
            "اغسطس": 8,
            "سبتمبر": 9,
            "اكتوبر": 10,
            "نوفمبر": 11,
            "ديسمبر": 12
        }

    def normalize_text(self, text):
        text = text.strip().lower()

        replacements = {
            "أ": "ا",
            "إ": "ا",
            "آ": "ا",
            "ى": "ي",
            "ة": "ه"
        }

        for old, new in replacements.items():
            text = text.replace(old, new)

        text = re.sub(r"[؟?،,!.؛;]", " ", text)
        text = re.sub(r"\s+", " ", text)

        return text.strip()

    def extract_target_date(self, request):
        """
        Extract a target date from the user's request.
        Defaults to today when no date is specified.
        """

        normalized = self.normalize_text(request)
        today = date.today()

        if "بكره" in normalized or "غدا" in normalized:
            return (today + timedelta(days=1)).isoformat()

        if "اليوم" in normalized:
            return today.isoformat()

        # Match ISO date: YYYY-MM-DD
        iso_match = re.search(
            r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b",
            normalized
        )

        if iso_match:
            year, month, day = map(int, iso_match.groups())

            try:
                return date(year, month, day).isoformat()
            except ValueError:
                return None

        # Match numeric date: DD/MM/YYYY
        numeric_match = re.search(
            r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b",
            normalized
        )

        if numeric_match:
            day, month, year = map(int, numeric_match.groups())

            try:
                return date(year, month, day).isoformat()
            except ValueError:
                return None

        # Match Arabic month name, e.g. 10 نوفمبر
        for month_name, month_number in self.months.items():
            match = re.search(
                rf"\b(\d{{1,2}})\s+{month_name}\b",
                normalized
            )

            if match:
                day = int(match.group(1))

                try:
                    return date(
                        today.year,
                        month_number,
                        day
                    ).isoformat()
                except ValueError:
                    return None

        return today.isoformat()

    def analyze(self, request):
        """
        Identify the requested action and extract its date.
        """

        if self.domain not in self.action_patterns:
            return {
                "status": "unsupported_domain",
                "domain": self.domain,
                "message": "This domain is not supported."
            }

        normalized_request = self.normalize_text(request)

        for action, patterns in self.action_patterns[self.domain].items():

            for pattern in patterns:

                if pattern in normalized_request:
                    target_date = None

                    if action == "view_appointments":
                        target_date = self.extract_target_date(request)

                        if target_date is None:
                            return {
                                "status": "invalid_date",
                                "domain": self.domain,
                                "message": "The requested date is invalid."
                            }

                    return {
                        "status": "analyzed",
                        "domain": self.domain,
                        "action": action,
                        "target_date": target_date,
                        "original_request": request,
                        "normalized_request": normalized_request,
                        "analysis_method": "pattern_based"
                    }

        return {
            "status": "unrecognized",
            "domain": self.domain,
            "original_request": request,
            "normalized_request": normalized_request,
            "message": "The requested action could not be identified."
        }
