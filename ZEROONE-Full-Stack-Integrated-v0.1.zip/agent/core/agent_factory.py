
from .agent_core import AgentCore
from .permission_engine import PermissionEngine
from ..domain_policies.clinic_policy import get_clinic_permissions


def create_agent(domain):
    """
    Create an intelligent agent configured for a business domain.
    """

    if domain == "clinic":
        policy = get_clinic_permissions()

        permission_engine = PermissionEngine(
            role_permissions=policy["role_permissions"],
            approval_required_actions=policy["approval_required_actions"],
            human_only_actions=policy["human_only_actions"]
        )

        agent = AgentCore(
            agent_name="ZEROONE Clinic Agent",
            domain="clinic"
        )

        agent.permission_engine = permission_engine

        return agent

    raise ValueError(f"Unsupported domain: {domain}")
