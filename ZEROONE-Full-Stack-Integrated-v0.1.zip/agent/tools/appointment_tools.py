import json
from pathlib import Path
from datetime import date


class AppointmentTools:
    """
    Tools for managing clinic appointments.
    """

    def __init__(self):
        project_root = Path(__file__).resolve().parents[2]

        self.data_file = (
            project_root / "data" / "appointments.json"
        )

    def view_appointments(self, target_date=None):
        """
        Read appointments for a specific date.
        """

        if target_date is None:
            target_date = date.today().isoformat()

        try:
            with open(self.data_file, "r", encoding="utf-8") as file:
                data = json.load(file)

        except FileNotFoundError:
            return {
                "status": "error",
                "message": "Appointments data file was not found."
            }

        except json.JSONDecodeError:
            return {
                "status": "error",
                "message": "Appointments data file contains invalid JSON."
            }

        appointments = data.get("appointments", [])

        results = [
            appointment
            for appointment in appointments
            if appointment.get("date") == target_date
        ]

        return {
            "status": "success",
            "date": target_date,
            "total": len(results),
            "appointments": results
        }