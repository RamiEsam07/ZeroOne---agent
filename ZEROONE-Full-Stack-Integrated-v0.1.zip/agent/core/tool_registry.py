﻿from dataclasses import dataclass
from types import MappingProxyType
from typing import Callable, Mapping

from agent.contracts.tool_definition import ToolDefinition


@dataclass(frozen=True, slots=True)
class RegisteredTool:
    """
    A tool definition paired with its executable handler.
    """

    definition: ToolDefinition
    handler: Callable


class ToolRegistry:
    """
    Central registry for tool definitions and their handlers.
    """

    def __init__(self):
        self._tools: dict[str, RegisteredTool] = {}

    def register_tool(
        self,
        definition: ToolDefinition,
        handler: Callable
    ) -> None:
        if not isinstance(definition, ToolDefinition):
            raise TypeError(
                "definition must be a ToolDefinition."
            )

        if not callable(handler):
            raise TypeError(
                "handler must be callable."
            )

        tool_id = definition.tool_id

        if tool_id in self._tools:
            raise ValueError(
                f"Tool already registered: {tool_id}"
            )

        self._tools[tool_id] = RegisteredTool(
            definition=definition,
            handler=handler
        )

    def get_tool(self, tool_id: str) -> RegisteredTool | None:
        if not isinstance(tool_id, str):
            return None

        return self._tools.get(tool_id)

    def list_tools(
        self,
        domain: str | None = None
    ) -> Mapping[str, RegisteredTool]:

        if domain is not None and (
            not isinstance(domain, str) or not domain.strip()
        ):
            raise ValueError(
                "domain must be a non-empty string or None."
            )

        if domain is None:
            selected = dict(self._tools)
        else:
            selected = {
                tool_id: entry
                for tool_id, entry in self._tools.items()
                if entry.definition.domain == domain
            }

        return MappingProxyType(selected)
