"""Clinic request analyzer."""

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class Analysis:
    """Result of analyzing a user request."""
    intent: str
    tool_id: str | None = None
    arguments: dict | None = None
    message_for_user: str | None = None


class RequestAnalyzer(ABC):
    """Interface implemented by request analyzers."""

    @abstractmethod
    def analyze(self, message: str, context: dict) -> Analysis:
        raise NotImplementedError


CLINIC_ACTION_PATTERNS = {
    "clinic.view_appointments": [
        r"\u0645\u0648\u0627\u0639\u064a\u062f",
        r"\u062c\u062f\u0648\u0644 \u0627\u0644\u0639\u064a\u0627\u062f\u0629",
        r"\u062c\u062f\u0648\u0644 \u0627\u0644\u064a\u0648\u0645",
        r"\u0627\u0644\u062d\u062c\u0648\u0632\u0627\u062a",
        r"\u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f \u0627\u0644\u0645\u062d\u062c\u0648\u0632\u0629",
        r"\u0627\u0644\u0645\u0631\u0636\u0649 \u0627\u0644\u062d\u0627\u062c\u0632\u064a\u0646",
        r"\u0639\u0631\u0636 \u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f",
        r"\u0627\u0639\u0631\u0636 \u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f",
        r"\u0648\u0631\u064a\u0646\u064a \u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f",
        r"\u0643\u0645 \u0639\u062f\u062f \u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f",
        r"show appointments",
        r"view appointments",
        r"appointments",
    ],
    "clinic.register_patient": [
        r"\u062a\u0633\u062c\u064a\u0644 \u0645\u0631\u064a\u0636",
        r"\u0645\u0631\u064a\u0636 \u062c\u062f\u064a\u062f",
        r"\u0627\u0636\u0641 \u0645\u0631\u064a\u0636",
        r"\u0627\u0636\u0627\u0641\u0629 \u0645\u0631\u064a\u0636",
    ],
    "clinic.cancel_appointment": [
        r"\u0627\u0644\u063a\u0627\u0621 \u0627\u0644\u0645\u0648\u0639\u062f",
        r"\u0627\u0644\u063a\u064a \u0627\u0644\u0645\u0648\u0639\u062f",
    ],
    "clinic.prepare_revenue_report": [
        r"\u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u0627\u064a\u0631\u0627\u062f\u0627\u062a",
        r"\u0627\u064a\u0631\u0627\u062f\u0627\u062a \u0627\u0644\u0639\u064a\u0627\u062f\u0629",
    ],
}

ARABIC_MONTHS = {
    "\u064a\u0646\u0627\u064a\u0631": 1,
    "\u0641\u0628\u0631\u0627\u064a\u0631": 2,
    "\u0645\u0627\u0631\u0633": 3,
    "\u0627\u0628\u0631\u064a\u0644": 4,
    "\u0645\u0627\u064a\u0648": 5,
    "\u064a\u0648\u0646\u064a\u0648": 6,
    "\u064a\u0648\u0644\u064a\u0648": 7,
    "\u0627\u063a\u0633\u0637\u0633": 8,
    "\u0633\u0628\u062a\u0645\u0628\u0631": 9,
    "\u0627\u0643\u062a\u0648\u0628\u0631": 10,
    "\u0646\u0648\u0641\u0645\u0628\u0631": 11,
    "\u062f\u064a\u0633\u0645\u0628\u0631": 12,
}

_ARABIC_NORMALIZE_MAP = {
    "\u0623": "\u0627",
    "\u0625": "\u0627",
    "\u0622": "\u0627",
    "\u0649": "\u064a",
}


def normalize_arabic_text(text: str) -> str:
    if not isinstance(text, str):
        raise TypeError("message must be a string.")

    text = text.strip().lower()
    for old, new in _ARABIC_NORMALIZE_MAP.items():
        text = text.replace(old, new)

    text = re.sub(r"[\u061f?\u060c,!.\u061b;:]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_target_date(message: str) -> str | None:
    normalized = normalize_arabic_text(message)
    today = date.today()

    if "\u0628\u0643\u0631\u0647" in normalized or "\u063a\u062f\u0627" in normalized:
        return (today + timedelta(days=1)).isoformat()

    if "\u0627\u0644\u064a\u0648\u0645" in normalized:
        return today.isoformat()

    match = re.search(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", normalized)
    if match:
        year, month, day = map(int, match.groups())
        try:
            return date(year, month, day).isoformat()
        except ValueError:
            return None

    match = re.search(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", normalized)
    if match:
        day, month, year = map(int, match.groups())
        try:
            return date(year, month, day).isoformat()
        except ValueError:
            return None

    for month_name, month_number in ARABIC_MONTHS.items():
        match = re.search(rf"\b(\d{{1,2}})\s+{month_name}\b", normalized)
        if match:
            try:
                return date(today.year, month_number, int(match.group(1))).isoformat()
            except ValueError:
                return None

    return today.isoformat()


class RuleBasedAnalyzer(RequestAnalyzer):
    def __init__(self, domain: str = "clinic"):
        self.domain = domain
        self._patterns = {"clinic": CLINIC_ACTION_PATTERNS}

    def analyze(self, message: str, context: dict) -> Analysis:
        if not isinstance(context, dict):
            return Analysis(
                intent="clarification",
                message_for_user="\u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0637\u0644\u0628 \u063a\u064a\u0631 \u0635\u0627\u0644\u062d\u0629.",
            )

        domain_patterns = self._patterns.get(self.domain)
        if domain_patterns is None:
            return Analysis(
                intent="unknown",
                message_for_user="\u0647\u0630\u0627 \u0627\u0644\u0645\u062c\u0627\u0644 \u063a\u064a\u0631 \u0645\u062f\u0639\u0648\u0645 \u062d\u0627\u0644\u064a\u0627.",
            )

        normalized = normalize_arabic_text(message)

        for tool_id, patterns in domain_patterns.items():
            for pattern in patterns:
                if not re.search(pattern, normalized):
                    continue

                arguments = {}
                if tool_id == "clinic.view_appointments":
                    target_date = context.get("date") or extract_target_date(message)
                    if target_date is None:
                        return Analysis(
                            intent="clarification",
                            message_for_user="\u0627\u0644\u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u063a\u064a\u0631 \u0635\u0627\u0644\u062d\u060c \u064a\u0631\u062c\u0649 \u062a\u0648\u0636\u064a\u062d\u0647.",
                        )
                    arguments["date"] = target_date

                return Analysis(
                    intent="action",
                    tool_id=tool_id,
                    arguments=arguments,
                )

        return Analysis(
            intent="unknown",
            message_for_user="\u0644\u0645 \u0623\u062a\u0645\u0643\u0646 \u0645\u0646 \u062a\u062d\u062f\u064a\u062f \u0627\u0644\u0625\u062c\u0631\u0627\u0621 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u060c \u064a\u0631\u062c\u0649 \u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u0635\u064a\u0627\u063a\u0629."
        )
