"""SQLAlchemy database configuration for SQLite development and PostgreSQL deployment."""
from __future__ import annotations
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

class Base(DeclarativeBase):
    pass

def build_engine(database_url: str | None = None):
    url = database_url or os.getenv("ZEROONE_DATABASE_URL", "sqlite:///./data/zeroone-platform.db")
    options = {"pool_pre_ping": True}
    if url.startswith("sqlite"):
        options["connect_args"] = {"check_same_thread": False, "timeout": 30}
        if url in {"sqlite://", "sqlite:///:memory:"}:
            options["poolclass"] = __import__("sqlalchemy.pool", fromlist=["StaticPool"]).StaticPool
    return create_engine(url, **options)

engine = build_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
