# ZEROONE Agent

محرك وكيل ذكي قابل لإعادة الاستخدام عبر مجالات أعمال متعددة (عيادات، متاجر، شركات) —
مبني على مبدأ **"الوكيل يحلل ويقترح، الإنسان المخوّل يعتمد"**.

> هذه نسخة مطوّرة من المشروع، وتضم: الهيكلة المعمارية
> والاختبارات الكاملة من نسخة "starter"، مع المنطق الأعمق (تحليل عربي
> غني، أدوار وظيفية، ذاكرة بموافقة بشرية) من النسخة التطويرية الأصلية.
> لا شيء من الشغل السابق ضاع — تم دمج كل جزء مفيد من الاثنين.

## التثبيت

```bash
python -m venv .venv

# على Windows (PowerShell):
.venv\Scripts\Activate.ps1
# على macOS/Linux:
source .venv/bin/activate

pip install -e ".[dev]"
```

## التشغيل

```bash
python examples/clinic_demo.py
```

## الاختبارات

```bash
python -m pytest -q
```

نتيجة التحقق بعد المرحلة الثالثة (2026-11-14): `146 passed, 2 subtests passed`.

هذه النتيجة لا تعني اكتمال جميع متطلبات الإنتاج؛ راجع `docs/RELEASE_STATUS.md` و`docs/IMPLEMENTATION_MATRIX.md`.

## هيكل المشروع

```
zeroone_agent/
├── __init__.py              ← يصدّر الواجهات العامة
├── constitution.py           ← يحمّل دستور الوكيل من data/agent_constitution.json
├── contracts/
│   └── models.py              ← AgentRequest, ExecutionContext, AgentResponse, ToolDefinition...
├── runtime/
│   ├── agent.py                ← AgentRuntime: ينسّق التدفق الكامل
│   └── analyzer.py             ← RuleBasedAnalyzer: تحليل نص عربي بـ regex حتمي
├── security/
│   ├── policy.py                ← PermissionEngine: تحقق من الصلاحيات على مستوى الأداة
│   ├── approvals.py             ← ApprovalService: طلبات اعتماد بشري مع انتهاء صلاحية
│   ├── approval_repository.py   ← تخزين الموافقات وتاريخها في SQLite
│   └── execution_repository.py  ← سجل التنفيذ والحجز الذري وتاريخ الحالات
├── tools/
│   ├── registry.py               ← ToolRegistry: تسجيل الأدوات
│   └── executor.py               ← ToolExecutor: تنفيذ آمن مع تحقق من المخططات
├── audit/
│   └── logger.py                  ← AuditLogger: سجل كل حدث (في الذاكرة + JSONL اختياري)
├── storage/
│   └── sqlite.py                   ← SQLiteEventStore: تخزين دائم اختياري
├── memory/
│   └── store.py                     ← MemoryStore: ذاكرة طويلة المدى بموافقة بشرية
└── domains/
    └── clinic/
        ├── tools.py                   ← أدوات العيادة (عرض المواعيد، إلخ)
        └── policy.py                   ← ربط الأدوار الوظيفية بالصلاحيات

tests/
├── test_engine.py              ← اختبارات end-to-end للتدفق الكامل
└── test_contracts.py            ← اختبارات تفصيلية لطبقة العقود

data/
├── agent_constitution.json       ← المبادئ التأسيسية للوكيل
├── agent_long_term_memory.json    ← ذاكرة تجريبية محفوظة من استخدام سابق
└── appointments.json               ← بيانات مواعيد تجريبية (بتاريخ اليوم)

docs/
├── ARCHITECTURE.md                   ← شرح تدفق الطلب وكيفية إضافة مجال جديد
└── SECURITY.md                        ← قائمة تحصين أمني قبل الإنتاج الحقيقي
```

## مثال سريع

```python
from zeroone_agent.audit.logger import AuditLogger
from zeroone_agent.contracts.models import AgentRequest, ExecutionContext
from zeroone_agent.domains.clinic.policy import capabilities_for_role
from zeroone_agent.domains.clinic.tools import register_clinic_tools
from zeroone_agent.runtime.agent import AgentRuntime
from zeroone_agent.security.approvals import ApprovalService
from zeroone_agent.security.policy import PermissionEngine
from zeroone_agent.tools.executor import ToolExecutor
from zeroone_agent.tools.registry import ToolRegistry

registry = ToolRegistry()
register_clinic_tools(registry)

audit = AuditLogger()
executor = ToolExecutor(registry, PermissionEngine(), audit)
runtime = AgentRuntime(registry, executor, audit, ApprovalService())

context = ExecutionContext(
    request_id="REQ-1", execution_id="EX-1", trace_id="TR-1",
    tenant_id="clinic-demo", agent_id="clinic-agent", agent_version="1.0",
    domain="clinic", principal_id="receptionist-1",
    capabilities=capabilities_for_role("receptionist"),
)

request = AgentRequest(
    request_id="REQ-1", agent_id="clinic-agent",
    message="اعرض المواعيد", context={"date": "2026-11-08"},
)

response = runtime.handle(request, context)
print(response.status.value, response.message, dict(response.data))
```

## إضافة مجال عمل جديد (متجر، شركة، إلخ)

راجع القسم المخصص في `docs/ARCHITECTURE.md` — الخطوات مختصرة ومباشرة
(أداة جديدة + سياسة أدوار جديدة + أنماط تحليل نص جديدة).

## ما الذي تغيّر عن النسختين السابقتين

- **من نسخة starter:** الهيكلة الكاملة (`contracts/`, `runtime/`, `security/`, إلخ)،
  اختبارات end-to-end شغّالة، `pyproject.toml` صحيح، نظام `capabilities`.
- **من النسخة التطويرية الأصلية:** محلل النصوص الغني (عشرات أنماط regex بالعربي
  بدل كلمة مفتاحية واحدة)، نظام أدوار وظيفية كامل (`receptionist`/`doctor`/`clinic_manager`)،
  ذاكرة طويلة المدى بموافقة بشرية حقيقية، قراءة بيانات المواعيد من ملف JSON حقيقي
  بدل بيانات مكتوبة داخل الكود، دستور الوكيل مربوط فعليًا بالكود.
- **جديد في هذا الدمج:** انتهاء صلاحية تلقائي لطلبات الاعتماد، خيار حفظ دائم
  لسجل التدقيق والذاكرة طويلة المدى على القرص، اختبارات إضافية لتغطية حالات حافة.

## الموافقات والتنفيذ الدائم

راجع `docs/APPROVALS.md`. تستخدم العيادة SQLite لتخزين الموافقات. أضيف مستودع مستقل لسجل التنفيذ يربط العملية بالموافقة الدقيقة، ويمنع الحجز المكرر ذرياً، ويحفظ تاريخ الحالات. لكنه لم يُربط بعد بمسار `AgentRuntime`؛ لذلك لا يعني اعتماد الطلب أن الأداة ستُنفذ تلقائياً. كما أن إعادة التحقق من صلاحيات المستخدم والسياسة وإصدارات الأداة ضمن منسق تنفيذ متكامل ما تزال مطلوبة.

## حالة التنفيذ

راجع `docs/RELEASE_STATUS.md` لمعرفة ما اكتمل وما يزال مطلوبًا للوصول إلى نظام ZEROONE التشغيلي الكامل. هذه النسخة أساس هندسي مُختبر وليست منتجًا أمنيًا معتمدًا أو منصة تشغيل مكتملة.

## خطوات لاحقة موصى بها قبل أي استخدام إنتاجي حقيقي

راجع `docs/SECURITY.md` بالتفصيل. أهم نقطتين فوريتين:

1. **المحلل الحالي (`RuleBasedAnalyzer`) حتمي بالكامل وليس نموذج ذكاء اصطناعي.**
   هذا مقصود للأمان والقابلية للاختبار. لإضافة تحليل بالذكاء الاصطناعي، اكتب
   محلل جديد يطبّق نفس واجهة `RequestAnalyzer` مع تحقق صارم من المخرجات.
2. **مسار استئناف التنفيذ بعد الموافقة لم يكتمل بعد.** يوجد مستودع تنفيذ دائم
   كأساس معماري، لكنه غير مربوط بعد بالمنفذ والمحرك. لا تنفذ الأداة لمجرد أن
   الموافقة أصبحت `approved`؛ يجب أن يكتمل منسق التنفيذ والتحقق من الصلاحيات
   والسياسة الحالية قبل أي استئناف.

## ZEROONE Platform — Database & Server Foundation

The platform control plane now includes SQLAlchemy persistence for tenants, domain manifests, workspaces, and audit events. SQLite is the local test/development default; PostgreSQL 16 is the intended server database. A FastAPI control-plane entrypoint is available at `zeroone_agent.platform.service:app`.

See `docs/platform/DATABASE_SERVER_FOUNDATION_AR.md` for local setup, PostgreSQL/Docker deployment configuration, security boundaries, and the remaining production hardening requirements. The admin-key guard is a bootstrap protection only; it is not the final user identity and RBAC system.
