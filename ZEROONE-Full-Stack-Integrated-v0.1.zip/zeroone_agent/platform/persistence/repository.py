
from __future__ import annotations

from uuid import uuid4

from sqlalchemy import select, desc

from .models import TenantRow, DomainRow, WorkspaceRow, AuditEventRow
from .database import SessionLocal


class PlatformRepository:
    """Transactional persistence. Tenant-scoped reads always require tenant_id."""

    def __init__(self, session_factory=SessionLocal):
        self._sessions = session_factory

    @property
    def database_engine(self):
        """Return the database engine bound to this repository."""
        bind = self._sessions.kw.get("bind")

        if bind is None:
            raise RuntimeError(
                "PlatformRepository requires a session factory with a bound engine."
            )

        return bind

    def create_tenant(self, tenant_id: str, display_name: str):
        with self._sessions.begin() as s:
            row = TenantRow(
                tenant_id=tenant_id,
                display_name=display_name,
                status="active",
            )
            s.add(row)
            s.flush()

            self._audit(
                s, tenant_id, "platform-admin",
                "tenant.created", "tenant", tenant_id, "success"
            )

            return {
                "tenant_id": row.tenant_id,
                "display_name": row.display_name,
                "status": row.status,
            }

    def register_domain(
        self, *, domain_id, display_name, package_version,
        description, capabilities, modules, settings_schema
    ):
        with self._sessions.begin() as s:
            row = DomainRow(
                domain_id=domain_id,
                display_name=display_name,
                package_version=package_version,
                description=description,
                capabilities=capabilities,
                modules=modules,
                settings_schema=settings_schema,
            )
            s.add(row)
            s.flush()

            self._audit(
                s, None, "platform-admin",
                "domain.registered", "domain", domain_id, "success"
            )

            return {
                "domain_id": row.domain_id,
                "display_name": row.display_name,
                "modules": row.modules,
            }

    def create_workspace(
        self, *, tenant_id, workspace_id, domain_id,
        display_name, enabled_modules, settings
    ):
        with self._sessions.begin() as s:
            tenant = s.get(TenantRow, tenant_id)
            domain = s.get(DomainRow, domain_id)

            if tenant is None:
                raise LookupError("Tenant not found.")

            if tenant.status != "active":
                raise PermissionError("Tenant is not active.")

            if domain is None:
                raise LookupError("Domain not found.")

            unknown = set(enabled_modules) - set(domain.modules)

            if unknown:
                raise ValueError(
                    f"Unsupported domain modules: {sorted(unknown)}"
                )

            row = WorkspaceRow(
                tenant_id=tenant_id,
                workspace_id=workspace_id,
                domain_id=domain_id,
                display_name=display_name,
                enabled_modules=enabled_modules,
                settings=settings,
            )
            s.add(row)
            s.flush()

            self._audit(
                s, tenant_id, "platform-admin",
                "workspace.created", "workspace", workspace_id, "success"
            )

            return self._workspace_dict(row)

    def get_workspace(
        self, *, authenticated_tenant_id: str, workspace_id: str
    ):
        with self._sessions() as s:
            row = s.scalar(
                select(WorkspaceRow).where(
                    WorkspaceRow.tenant_id == authenticated_tenant_id,
                    WorkspaceRow.workspace_id == workspace_id,
                )
            )

            if row is None:
                raise LookupError("Workspace not found.")

            return self._workspace_dict(row)

    def list_domains(self):
        with self._sessions() as s:
            return [
                {
                    "domain_id": r.domain_id,
                    "display_name": r.display_name,
                    "package_version": r.package_version,
                    "description": r.description,
                    "capabilities": r.capabilities,
                    "modules": r.modules,
                    "settings_schema": r.settings_schema,
                }
                for r in s.scalars(
                    select(DomainRow).order_by(DomainRow.domain_id)
                )
            ]

    def list_audit_events(
        self, *, tenant_id: str | None = None, limit: int = 100
    ):
        with self._sessions() as s:
            q = select(AuditEventRow)

            if tenant_id is not None:
                q = q.where(AuditEventRow.tenant_id == tenant_id)

            rows = s.scalars(
                q.order_by(desc(AuditEventRow.created_at)).limit(limit)
            ).all()

            return [
                {
                    "event_id": r.event_id,
                    "tenant_id": r.tenant_id,
                    "actor_id": r.actor_id,
                    "event_type": r.event_type,
                    "resource_type": r.resource_type,
                    "resource_id": r.resource_id,
                    "outcome": r.outcome,
                    "details": r.details,
                    "created_at": r.created_at.isoformat(),
                }
                for r in rows
            ]

    @staticmethod
    def _workspace_dict(r):
        return {
            "workspace_id": r.workspace_id,
            "tenant_id": r.tenant_id,
            "domain_id": r.domain_id,
            "display_name": r.display_name,
            "enabled_modules": r.enabled_modules,
            "settings": r.settings,
            "created_at": r.created_at.isoformat(),
        }

    @staticmethod
    def _audit(
        s, tenant_id, actor_id, event_type,
        resource_type, resource_id, outcome
    ):
        s.add(
            AuditEventRow(
                event_id=uuid4().hex,
                tenant_id=tenant_id,
                actor_id=actor_id,
                event_type=event_type,
                resource_type=resource_type,
                resource_id=resource_id,
                outcome=outcome,
                details={},
            )
        )
