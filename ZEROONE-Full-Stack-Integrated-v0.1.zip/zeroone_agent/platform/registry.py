"""Validated in-process registry for tenant workspaces and domain packages.

This is a configuration/control-plane foundation, not the production persistence
or authentication layer. Callers must supply tenant identity from a trusted
authentication boundary, never from free-form request text.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Mapping
import re

_SLUG = re.compile(r"^[a-z][a-z0-9_-]{0,62}$")


def _identifier(value: str, field_name: str) -> str:
    if not isinstance(value, str) or not _SLUG.fullmatch(value):
        raise ValueError(f"{field_name} must be a valid lowercase slug.")
    return value


@dataclass(frozen=True, slots=True)
class DomainManifest:
    domain_id: str
    display_name: str
    package_version: str
    description: str
    capabilities: tuple[str, ...] = ()
    modules: tuple[str, ...] = ()
    settings_schema: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _identifier(self.domain_id, "domain_id")
        for name in ("display_name", "package_version", "description"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be non-empty.")
        for field_name in ("capabilities", "modules"):
            values = getattr(self, field_name)
            if not isinstance(values, (tuple, list)):
                raise TypeError(f"{field_name} must be a tuple or list.")
            normalized = tuple(values)
            if any(not isinstance(v, str) or not v.strip() for v in normalized):
                raise ValueError(f"{field_name} entries must be non-empty strings.")
            if len(normalized) != len(set(normalized)):
                raise ValueError(f"{field_name} must not contain duplicates.")
            object.__setattr__(self, field_name, normalized)
        if not isinstance(self.settings_schema, Mapping):
            raise TypeError("settings_schema must be a mapping.")
        object.__setattr__(self, "settings_schema", MappingProxyType(dict(self.settings_schema)))


@dataclass(frozen=True, slots=True)
class TenantRecord:
    tenant_id: str
    display_name: str
    status: str = "active"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        _identifier(self.tenant_id, "tenant_id")
        if not isinstance(self.display_name, str) or not self.display_name.strip():
            raise ValueError("display_name must be non-empty.")
        if self.status not in {"active", "suspended", "closed"}:
            raise ValueError("Unsupported tenant status.")
        if self.created_at.tzinfo is None or self.created_at.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware.")


@dataclass(frozen=True, slots=True)
class WorkspaceRecord:
    workspace_id: str
    tenant_id: str
    domain_id: str
    display_name: str
    enabled_modules: tuple[str, ...] = ()
    settings: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _identifier(self.workspace_id, "workspace_id")
        _identifier(self.tenant_id, "tenant_id")
        _identifier(self.domain_id, "domain_id")
        if not isinstance(self.display_name, str) or not self.display_name.strip():
            raise ValueError("display_name must be non-empty.")
        if not isinstance(self.enabled_modules, (tuple, list)):
            raise TypeError("enabled_modules must be a tuple or list.")
        modules = tuple(self.enabled_modules)
        if any(not isinstance(x, str) or not x.strip() for x in modules):
            raise ValueError("enabled_modules entries must be non-empty strings.")
        if len(modules) != len(set(modules)):
            raise ValueError("enabled_modules must not contain duplicates.")
        object.__setattr__(self, "enabled_modules", modules)
        if not isinstance(self.settings, Mapping):
            raise TypeError("settings must be a mapping.")
        object.__setattr__(self, "settings", MappingProxyType(dict(self.settings)))


class PlatformRegistry:
    """Registers domain packages and tenant-specific workspaces.

    Workspaces are addressed by (tenant_id, workspace_id); duplicate workspace
    IDs across different tenants are therefore safe and intentionally allowed.
    """

    def __init__(self) -> None:
        self._domains: dict[str, DomainManifest] = {}
        self._tenants: dict[str, TenantRecord] = {}
        self._workspaces: dict[tuple[str, str], WorkspaceRecord] = {}

    def register_domain(self, manifest: DomainManifest) -> None:
        if not isinstance(manifest, DomainManifest):
            raise TypeError("manifest must be a DomainManifest.")
        if manifest.domain_id in self._domains:
            raise ValueError(f"Domain already registered: {manifest.domain_id}")
        self._domains[manifest.domain_id] = manifest

    def register_tenant(self, tenant: TenantRecord) -> None:
        if not isinstance(tenant, TenantRecord):
            raise TypeError("tenant must be a TenantRecord.")
        if tenant.tenant_id in self._tenants:
            raise ValueError(f"Tenant already registered: {tenant.tenant_id}")
        self._tenants[tenant.tenant_id] = tenant

    def create_workspace(self, workspace: WorkspaceRecord) -> None:
        if not isinstance(workspace, WorkspaceRecord):
            raise TypeError("workspace must be a WorkspaceRecord.")
        tenant = self._tenants.get(workspace.tenant_id)
        if tenant is None:
            raise KeyError(f"Unknown tenant: {workspace.tenant_id}")
        if tenant.status != "active":
            raise PermissionError("Cannot create a workspace for an inactive tenant.")
        domain = self._domains.get(workspace.domain_id)
        if domain is None:
            raise KeyError(f"Unknown domain: {workspace.domain_id}")
        unknown_modules = set(workspace.enabled_modules) - set(domain.modules)
        if unknown_modules:
            raise ValueError(f"Modules not supported by domain: {sorted(unknown_modules)}")
        key = (workspace.tenant_id, workspace.workspace_id)
        if key in self._workspaces:
            raise ValueError(f"Workspace already exists for tenant: {workspace.workspace_id}")
        self._workspaces[key] = workspace

    def get_workspace(self, *, authenticated_tenant_id: str, workspace_id: str) -> WorkspaceRecord:
        """Resolve workspace only within the authenticated tenant boundary."""
        _identifier(authenticated_tenant_id, "authenticated_tenant_id")
        _identifier(workspace_id, "workspace_id")
        key = (authenticated_tenant_id, workspace_id)
        try:
            return self._workspaces[key]
        except KeyError:
            # Do not reveal whether another tenant owns this workspace ID.
            raise KeyError("Workspace not found.") from None

    def get_domain_for_workspace(self, *, authenticated_tenant_id: str, workspace_id: str) -> DomainManifest:
        workspace = self.get_workspace(
            authenticated_tenant_id=authenticated_tenant_id,
            workspace_id=workspace_id,
        )
        return self._domains[workspace.domain_id]

    def list_domains(self) -> tuple[DomainManifest, ...]:
        return tuple(self._domains[key] for key in sorted(self._domains))
