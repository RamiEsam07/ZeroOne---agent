import unittest

from agent.contracts.value_objects import freeze_json_value


class TestFreezeJsonValue(unittest.TestCase):

    def test_nested_mapping_is_immutable(self):
        original = {
            "user": {
                "role": "receptionist"
            }
        }

        frozen = freeze_json_value(original)

        with self.assertRaises(TypeError):
            frozen["user"]["role"] = "admin"

    def test_nested_list_is_immutable(self):
        original = {
            "permissions": ["view_appointments"]
        }

        frozen = freeze_json_value(original)

        self.assertIsInstance(
            frozen["permissions"],
            tuple
        )

        with self.assertRaises(AttributeError):
            frozen["permissions"].append("delete_records")

    def test_original_data_is_not_modified(self):
        original = {
            "settings": {
                "language": "ar"
            }
        }

        freeze_json_value(original)

        original["settings"]["language"] = "en"

        self.assertEqual(
            original["settings"]["language"],
            "en"
        )

    def test_unsupported_type_is_rejected(self):
        with self.assertRaises(TypeError):
            freeze_json_value({"value": {1, 2, 3}})

    def test_non_finite_float_is_rejected(self):
        with self.assertRaises(ValueError):
            freeze_json_value({"value": float("nan")})

    def test_valid_json_values_are_preserved(self):
        original = {
            "name": "ZEROONE",
            "active": True,
            "version": 1,
            "score": 9.5,
            "metadata": None
        }

        frozen = freeze_json_value(original)

        self.assertEqual(frozen["name"], "ZEROONE")
        self.assertEqual(frozen["active"], True)
        self.assertEqual(frozen["version"], 1)
        self.assertEqual(frozen["score"], 9.5)
        self.assertIsNone(frozen["metadata"])


if __name__ == "__main__":
    unittest.main()
    